# Go live on Hostinger VPS: step by step

Total time is about 30 minutes, plus up to 30 minutes waiting for your domain to point at the server.

---

## Step 1: Buy the VPS

1. On hostinger.in choose **VPS Hosting → KVM 2** and pay. UPI is fine.
2. In the setup wizard:
   - **Location:** India (Mumbai)
   - **Operating system:** choose **"Plain OS" → Ubuntu 24.04**. Don't choose a control panel template.
   - **Root password:** create a strong password and **keep it private**. Don't share it with anyone, including in chats.
3. When it's ready, open **hPanel → VPS → Overview** and note the **IP address** (e.g. `82.25.xx.xx`).

## Step 2: Buy the domain and point it to the server

1. Buy a domain, e.g. `pushpawater.in`, from Hostinger (**Domains**) or GoDaddy.
2. Open the domain's **DNS settings** (Hostinger: **Domains → your domain → DNS / Nameservers**) and add two records:

   | Type | Name | Points to | TTL |
   |---|---|---|---|
   | A | `@` | your VPS IP | 300 |
   | A | `www` | your VPS IP | 300 |

   Delete any existing `A` record for `@` that points somewhere else, such as a "parked" page.
3. It can take 5–30 minutes to take effect. You can carry on with the next steps meanwhile.

## Step 3: Upload the app (from your Windows PC)

Open **PowerShell** on your PC and run this, replacing `YOUR_SERVER_IP` with your VPS IP:

```bash
scp C:\Users\SBhattacharya\claude\aqualeaf-deploy.zip root@YOUR_SERVER_IP:/root/
```

- The first time, it asks "Are you sure you want to continue connecting?". Type `yes`.
- Then type your **root password**. Nothing appears on screen while you type; that's normal.

## Step 4: Log in to the server

In the same PowerShell window:

```bash
ssh root@YOUR_SERVER_IP
```

Enter the root password again. You're now typing commands on the server: the prompt changes to something like `root@srv123:~#`.

## Step 5: Run the setup (one command)

Copy and paste this whole line into the server window:

```bash
apt-get update -y && apt-get install -y unzip && unzip -o aqualeaf-deploy.zip && cd aqualeaf && bash scripts/setup-server.sh
```

It asks one question, **your domain** (type `pushpawater.in`, without `https://`), and then automatically:
- installs Docker
- turns on the firewall (only web and SSH allowed)
- creates a secret key and saves your settings
- builds and starts the site with **free automatic HTTPS**

When it finishes you'll see **"✔ AquaLeaf is running!"**.

## Step 6: Open your site and secure it

1. Go to `https://pushpawater.in`.
   - If you see a security warning, the DNS from Step 2 hasn't updated yet. Wait 10–20 minutes and refresh; HTTPS switches on by itself.
2. Admin: `https://pushpawater.in/login?role=admin` with `admin@aqualeaf.local` / `admin123`.
   **You'll be asked to set a new password straight away.**
3. In admin, set up your real business:
   - **Settings:** business name, address, phone, email, GST number, delivery charge, referral amounts
   - **Areas & time slots:** your PIN codes and delivery slots
   - **Products:** real prices and can deposits
   - **Staff & agents:** edit or replace the demo agents (Ravi, Sunil) with your real delivery staff, each with a temporary password
4. On each delivery agent's phone: open `https://pushpawater.in/login?role=agent`, tap **Install app**,
   then in the 🔔 bell turn on **Get alerts even when the app is closed**.

---

## Everyday commands (on the server, inside the `aqualeaf` folder)

Log in to the server first, then go to the app folder:

```bash
ssh root@YOUR_SERVER_IP
```
```bash
cd aqualeaf
```

Then use whichever you need:

| What | Command |
|---|---|
| Check the site is running | `docker compose ps` |
| See the app's logs | `docker compose logs -f app` (press Ctrl+C to exit) |
| Restart | `docker compose restart` |
| Stop | `docker compose down` |

**Updating to a new version:** upload the new zip (Step 3), then run:

```bash
cd /root && unzip -o aqualeaf-deploy.zip && cd aqualeaf && bash scripts/setup-server.sh
```

Your data and settings are kept.

## Backups

- **Automatic:** a copy is made every day on the server (last 14 days kept).
- **Your job, weekly:** admin → Settings → **Download backup now**, and save the file to Google Drive.
- Also consider turning on **Hostinger's weekly VPS backups** in hPanel.

## Adding SMS later (customer OTP login and messages)

1. Sign up at MSG91 and complete the **DLT registration** (required in India; takes a few days).
2. On the server, open the settings file:
   ```bash
   nano /root/aqualeaf/.env
   ```
   Fill in `SMS_PROVIDER=msg91`, `MSG91_AUTH_KEY` and the template IDs. Save with Ctrl+O, Enter, then exit with Ctrl+X.
3. Restart the app:
   ```bash
   cd /root/aqualeaf && docker compose up -d
   ```

Until SMS is set up, customers can still book and track. Only the "My account" login is switched off.
