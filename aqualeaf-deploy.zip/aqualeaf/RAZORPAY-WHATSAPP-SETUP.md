# Connecting Razorpay and WhatsApp

Until these are connected, the site works in **test mode**:
- "Pay & book" opens a built-in test payment page, and no money is taken.
- WhatsApp messages are printed in the server log instead of being sent.
- Customer login codes appear on screen.

Add the keys below to the server's `.env` file (`/root/aqualeaf/.env` on the VPS), then restart the app:

```bash
cd /root/aqualeaf && docker compose up -d
```

Keep all keys private. Never paste them into chats or emails.

---

## 1. Razorpay (online payment, full amount at booking)

1. Sign up at **dashboard.razorpay.com**. Business KYC is needed for live payments; test mode works straight away.
2. Go to **Account & Settings → API Keys → Generate key**. Start with **Test Mode** keys; their ID starts `rzp_test_`.
3. Go to **Account & Settings → Webhooks → Add new webhook**:
   - **URL:** `https://YOUR-DOMAIN/api/payments/razorpay/webhook`
   - **Secret:** make up a long random string and keep it
   - **Event:** tick `payment_link.paid`
4. Put these in `.env`:
   ```
   RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
   RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxx
   RAZORPAY_WEBHOOK_SECRET=the-secret-you-chose
   PUBLIC_URL=https://YOUR-DOMAIN
   ```
5. Restart the app. Admin → **Payments** should now show "🟡 Razorpay test mode". Make a test booking: Razorpay's test
   page offers dummy UPI and cards. After paying you land back on the tracking page with "Payment received".
6. When KYC is approved, generate **Live Mode** keys (`rzp_live_`), add a live-mode webhook in the same way, and
   swap the keys in `.env`.

**How it works:**
- The customer books, the site creates a **Razorpay Payment Link** for the full amount (all deliveries plus the
  can deposit), and the customer pays.
- Razorpay sends them back and also notifies the server by webhook. The booking is marked **Paid**, and the admin
  gets "New paid booking".
- Admin confirms the booking and assigns a delivery person, and the deliveries are scheduled.
- Payment links expire after 3 days. A customer can always pay later from the tracking page or My account
  ("Pay now"), and the admin can resend the link from the booking.

**Refunds:** when a paid booking is cancelled, admin shows **"Refund due"**. Issue the refund in the Razorpay
dashboard (Payments → the payment → Refund), then click **Record refund** in admin so the reports stay correct.

---

## 2. WhatsApp (Meta WhatsApp Cloud API)

1. Go to **business.facebook.com** and create a Meta Business account, then complete business verification.
2. Go to **developers.facebook.com → My Apps → Create app → Business**, and add the **WhatsApp** product.
3. In **WhatsApp → API Setup**:
   - Add and verify your business phone number. It must not already be used on the WhatsApp app.
   - Note the **Phone number ID**.
   - Create a **permanent access token**: Business Settings → System users → Add, give it the WhatsApp permissions,
     then Generate token.
4. In **WhatsApp Manager → Message templates**, create these templates (language: English) and wait for approval.
   Approval usually takes minutes to a few hours.

   | Template name | Category | Body text (copy exactly; `{{n}}` are variables) |
   |---|---|---|
   | `aq_booking_confirmed` | Utility | Hi {{1}}, your booking {{2}} is confirmed and paid ({{3}}). Plan: {{4}}. Track it here: {{5}} |
   | `aq_payment_link` | Utility | Hi {{1}}, please complete the payment of {{2}} for your water booking {{3}} here: {{4}} |
   | `aq_out_for_delivery` | Utility | Hi {{1}}, your water delivery {{2}} is on the way with {{3}} ({{4}}). |
   | `aq_delivered` | Utility | Hi {{1}}, your delivery {{2}} is complete. View your bill: {{3}} |
   | `aq_login_code` | Authentication | (Meta's fixed text) Choose "Copy code" as the button type. |
   | `aq_staff_alert` | Utility | {{1}}: {{2}} |

5. Put these in `.env`:
   ```
   WHATSAPP_TOKEN=EAAG...your-permanent-token
   WHATSAPP_PHONE_NUMBER_ID=123456789012345
   WHATSAPP_LANG=en
   ```
6. Restart the app.

**What gets sent:**
- **Customers:** the payment link, booking confirmed (with tracking link), out for delivery (with the delivery
  person's name and phone), delivered (with the bill link), and login codes for My account.
- **Staff alerts** go to the phone number saved on each staff account (Admin → Staff): new paid bookings, new tasks,
  skipped or paused or cancelled deliveries, and low ratings.

**Different template names?** Set them in `.env`, e.g. `WHATSAPP_TPL_DELIVERED=my_delivered_template`.

**Using Interakt, AiSensy, WATI or another partner** instead of Meta directly: most offer the same Cloud API.
If yours needs a different API, only `server/whatsapp.js` needs changing.

**Costs (Meta, India, approximate):** utility messages cost about ₹0.13 each, and authentication (login code)
messages about ₹0.12 each. Customer-initiated chats are free within 24 hours.

---

## 3. Optional SMS fallback

If WhatsApp isn't connected but SMS is (MSG91 or Twilio settings in `.env.example`), the same messages and login
codes go out by SMS instead.
