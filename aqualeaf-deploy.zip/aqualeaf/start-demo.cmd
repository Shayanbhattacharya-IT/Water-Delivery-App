@echo off
rem Double-click to start the client demo. Add -Reset to refresh the demo data for today.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-demo.ps1" %*
pause
