// Builds a separate DEMO database full of realistic sample data (customers, subscriptions, deliveries, bills,
// cans, ratings, cash handovers, coupons, areas) so a client demo doesn't start from empty screens.
//
//   node scripts/seed-demo.js [demo-data-dir]      (default: ./demo-data — the folder is wiped and rebuilt)
//
// Dates are relative to today, so re-run it on the morning of a demo. Never point it at your real data folder.
const fs = require('fs');
const path = require('path');

const dir = path.resolve(process.argv[2] || path.join(__dirname, '..', 'demo-data'));
if (fs.existsSync(path.join(dir, 'aqualeaf.db')) && !fs.existsSync(path.join(dir, '.demo'))) {
  console.error(`Refusing to wipe ${dir}: it does not look like a demo folder (no .demo marker).`);
  process.exit(1);
}
fs.rmSync(dir, { recursive: true, force: true });
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, '.demo'), 'This folder holds demo data and may be wiped by scripts/seed-demo.js\n');
process.env.DATA_DIR = dir;

const sch = require('../server/schedule');
const auth = require('../server/auth');
const { one, all, run, round2, randomCode } = require('../server/util');
const B = require('../server/booking');
const { notify } = require('../server/notify');

// Deterministic pseudo-random numbers so every demo looks the same.
let seed = 42;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };

const today = sch.today();
const ADMIN = 1, RAVI = 2, SUNIL = 3;
const PASSWORDS = { admin: 'AquaDemo@2026', agent: 'AgentDemo@2026' };

// ---- staff: known demo passwords, no forced change (so the demo isn't interrupted)
run('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE role = ?', auth.hashPassword(PASSWORDS.admin), 'admin');
run('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE role = ?', auth.hashPassword(PASSWORDS.agent), 'agent');

// ---- delivery areas & coupons
const AREAS = [['700016', 'Park Street', 0, 0], ['700019', 'Ballygunge', 10, 0], ['700029', 'Gariahat', 10, 100], ['700091', 'Salt Lake', 20, 150]];
for (const [pin, name, charge, min] of AREAS) run('INSERT INTO service_areas (pincode, name, delivery_charge, min_order) VALUES (?, ?, ?, ?)', pin, name, charge, min);
run(`INSERT INTO coupons (code, description, type, value, scope, per_customer_limit) VALUES ('WELCOME10', '10% off your first delivery', 'percent', 10, 'first', 1)`);
run(`INSERT INTO coupons (code, description, type, value, scope, per_customer_limit, max_discount) VALUES ('MONSOON20', '₹20 off every delivery this season', 'flat', 20, 'all', 0, 0)`);

const slot = (id) => one('SELECT * FROM time_slots WHERE id = ?', id);
const product = (id) => one('SELECT * FROM products WHERE id = ?', id);

// Products (water only): 1 20L can · 2 1L bottles ×12 · 3 500ml bottles ×24 · 4 10L box · 5 15L cool jar · 6 5L jar
// [name, phone, address, line, pin, plan, startOffsetDays, items [[productId, qty]], slotId, agent, coupon, state]
// state: (default) paid & scheduled · 'to-confirm' paid, waiting for admin · 'unpaid' booking started but not paid
const CUSTOMERS = [
  ['Priya Sen', '9830011111', '14/2 Gariahat Road, Ballygunge, Kolkata', 'Lane 3', '700019', 'daily', -20, [[1, 1]], 1, RAVI],
  ['Amit Roy', '9830022222', '22 Park Street, Kolkata', 'Lane 1', '700016', 'alternate', -18, [[1, 2]], 2, RAVI],
  ['Neha Das', '9830033333', 'BD-117, Sector 1, Salt Lake, Kolkata', 'Block BD', '700091', 'alternate', -21, [[1, 3], [2, 1]], 4, SUNIL, 'MONSOON20'],
  ['Rahul Gupta', '9830044444', '8 Hindustan Park, Gariahat, Kolkata', 'Lane 2', '700029', 'daily', -14, [[6, 3]], 3, SUNIL],
  ['Sneha Iyer', '9830055555', '5 Camac Street, Park Street, Kolkata', 'Lane 4', '700016', 'daily', -10, [[1, 1]], 2, RAVI, 'WELCOME10'],
  ['Arjun Mehta', '9830066666', '31 Ballygunge Circular Road, Kolkata', 'Lane 6', '700019', 'alternate', -16, [[5, 2]], 5, SUNIL],
  ['Rohan Bose', '9830077777', '12 Rashbehari Avenue, Gariahat, Kolkata', 'Lane 5', '700029', 'alternate', -12, [[1, 2]], 1, SUNIL, 'REFERRAL:9830011111'],
  ['Kavya Nair', '9830088888', 'CK-45, Sector 2, Salt Lake, Kolkata', 'Block CK', '700091', 'once', 0, [[3, 2], [4, 1]], 6, RAVI],
  ['Ishita Banerjee', '9830099999', '9 Middleton Row, Park Street, Kolkata', 'Lane 2', '700016', 'daily', 1, [[1, 2]], 2, null, null, 'to-confirm'],
  ['Vikram Singh', '9830010101', '27 Hazra Road, Ballygunge, Kolkata', 'Lane 8', '700019', 'daily', 1, [[1, 1]], 1, null, null, 'unpaid'],
];

const bookingIds = [];
for (const [name, phone, address, line, pin, freq, offset, items, slotId, agent, code, state] of CUSTOMERS) {
  const start = sch.addDays(today, offset);
  const end = sch.defaultEndDate(freq, start);
  const count = sch.occurrences(freq, start, end).length;
  const s = slot(slotId);
  const lines = items.map(([pid, qty]) => { const p = product(pid); return { product_id: p.id, name: p.name, unit: p.unit, price: p.price, quantity: qty, returnable: p.returnable, deposit: p.deposit }; });
  const subtotal = round2(lines.reduce((t, l) => t + l.price * l.quantity, 0));
  const area = AREAS.find((a) => a[0] === pin);
  let coupon = { code: '', discount: 0, scope: 'first', referred_by: null };
  if (code?.startsWith('REFERRAL:')) {
    const ref = one('SELECT * FROM customers WHERE phone = ?', code.split(':')[1]);
    coupon = { code: ref.referral_code, discount: 50, scope: 'first', referred_by: ref.id };
  } else if (code === 'WELCOME10') coupon = { code, discount: round2(subtotal * 0.1), scope: 'first', referred_by: null };
  else if (code === 'MONSOON20') coupon = { code, discount: 20, scope: 'all', referred_by: null };
  const perDelivery = round2(subtotal + area[2]);
  const deposit = round2(lines.filter((l) => l.returnable).reduce((t, l) => t + l.quantity * l.deposit, 0));
  const total = round2(perDelivery * count - (coupon.scope === 'all' ? coupon.discount * count : coupon.discount) + deposit);

  const id = B.createBooking({
    name, phone, email: `${name.split(' ')[0].toLowerCase()}@example.com`, address, line_no: line, pincode: pin, frequency: freq,
    start_date: start, end_date: end, delivery_time: s.start_time, slot_id: s.id, items: lines,
    amount: perDelivery, delivery_charge: area[2], coupon_code: coupon.code, discount: coupon.discount,
    discount_scope: coupon.scope, referred_by: coupon.referred_by, notes: rnd() < 0.3 ? 'Please call before arriving' : '',
    total, deposit,
  });
  const created = `${sch.addDays(start, -1)} 18:${String(10 + Math.floor(rnd() * 40)).padStart(2, '0')}:00`;
  run('UPDATE bookings SET created_at = ? WHERE id = ?', created, id);
  run('UPDATE customers SET created_at = ?, updated_at = ? WHERE phone = ? AND created_at > ?', created, created, phone, created);
  if (state === 'unpaid') continue;

  // Paid through Razorpay (records can deposits too); back-date the payment to just after booking.
  B.markPaid(id, { amount: total, reference: `pay_DEMO${randomCode(10)}` });
  run('UPDATE bookings SET paid_at = ? WHERE id = ?', created.replace(/:\d\d$/, ':55'), id);
  if (state === 'to-confirm') continue;

  // Confirm with the full schedule — including past dates, so the demo has history.
  const b = one('SELECT * FROM bookings WHERE id = ?', id);
  sch.occurrences(freq, b.start_date, b.end_date).forEach((dt, i) => {
    const discount = b.discount_scope === 'all' || i === 0 ? b.discount : 0;
    run('INSERT INTO deliveries (booking_id, seq, scheduled_date, scheduled_time, slot_id, agent_id, amount) VALUES (?, ?, ?, ?, ?, ?, ?)',
      id, i + 1, dt, b.delivery_time, b.slot_id, agent, round2(b.amount_per_delivery - discount));
  });
  run("UPDATE bookings SET status = 'confirmed', agent_id = ?, confirmed_at = ? WHERE id = ?",
    agent, `${sch.addDays(b.start_date, -1)} 19:05:00`, id);
  bookingIds.push(id);
}

// ---- play out every past delivery in date order (cans, failures, ratings)
const addMin = (t, m) => { const [h, mm] = t.split(':').map(Number); const x = h * 60 + mm + m; return `${String(Math.floor(x / 60)).padStart(2, '0')}:${String(x % 60).padStart(2, '0')}`; };
const COMMENTS = ['Always on time 👍', 'Very polite delivery person', 'Cans were clean and sealed', 'Quick delivery, thanks!', '', '', ''];
const past = all("SELECT * FROM deliveries WHERE scheduled_date < ? AND status = 'scheduled' ORDER BY scheduled_date, scheduled_time, id", today);
for (const d of past) {
  if (rnd() < 0.05) { B.failDelivery(d, rnd() < 0.5 ? 'Customer not available' : 'Customer asked to reschedule'); continue; }
  B.markDelivered(d, {});
  const at = `${d.scheduled_date} ${addMin(d.scheduled_time, 25 + Math.floor(rnd() * 50))}:00`;
  run(`UPDATE deliveries SET delivered_at = ?, started_at = ?, invoice_no = ? WHERE id = ?`, at, at,
    `INV-${d.scheduled_date.slice(0, 7).replace('-', '')}-${String(d.id).padStart(6, '0')}`, d.id);
  run('UPDATE container_moves SET created_at = ? WHERE delivery_id = ?', at, d.id);
  if (rnd() < 0.55) {
    const b = one('SELECT customer_id FROM bookings WHERE id = ?', d.booking_id);
    const r = rnd();
    const rating = r < 0.07 ? 2 : r < 0.2 ? 3 : r < 0.5 ? 4 : 5;
    run('INSERT INTO ratings (delivery_id, booking_id, customer_id, agent_id, rating, comment, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      d.id, d.booking_id, b.customer_id, d.agent_id, rating, rating <= 2 ? 'Came 40 minutes late' : COMMENTS[Math.floor(rnd() * COMMENTS.length)], at);
  }
}

// ---- today: early slots done, Sneha's delivery on the way, the rest scheduled
for (const d of all("SELECT d.*, b.name FROM deliveries d JOIN bookings b ON b.id = d.booking_id WHERE d.scheduled_date = ? AND d.status = 'scheduled'", today)) {
  if (d.name === 'Sneha Iyer') B.startDelivery(d);
  else if (d.scheduled_time <= '06:00') {
    B.markDelivered(d, {});
    const at = `${today} ${addMin(d.scheduled_time, 35)}:00`;
    run('UPDATE deliveries SET delivered_at = ?, started_at = ? WHERE id = ?', at, at, d.id);
  }
}
for (const id of bookingIds) B.refreshBookingStatus(id);

// ---- a staff notification for the agent (paid-booking alerts for admin were created by markPaid)
notify([RAVI], 'New task assigned: ' + one("SELECT booking_no FROM bookings WHERE name = 'Kavya Nair'").booking_no,
  'Kavya Nair, CK-45, Sector 2, Salt Lake · One time delivery today 18:00–20:00', `/agent?date=${today}`);

// ---- summary
const n = (sql, ...p) => one(sql, ...p).n;
console.log(`Demo database ready in ${dir}`);
console.log(`  customers ${n('SELECT COUNT(*) n FROM customers')}, bookings ${n('SELECT COUNT(*) n FROM bookings')} (${n("SELECT COUNT(*) n FROM bookings WHERE status='pending'")} pending),`
  + ` delivered ${n("SELECT COUNT(*) n FROM deliveries WHERE status='delivered'")}, today ${n('SELECT COUNT(*) n FROM deliveries WHERE scheduled_date = ?', today)},`
  + ` ratings ${n('SELECT COUNT(*) n FROM ratings')}, cans out ${n('SELECT COALESCE(SUM(held),0) n FROM customer_containers')}`);
console.log(`  Sneha's tracking ID (out for delivery): ${one("SELECT tracking_id FROM bookings WHERE name = 'Sneha Iyer'").tracking_id}`);
console.log('  Logins are listed in DEMO.md');
