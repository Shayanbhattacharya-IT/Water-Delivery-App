#!/usr/bin/env bash
# One-shot setup for a fresh Ubuntu 22.04/24.04 VPS (e.g. Hostinger KVM 2).
# Run from the project folder as root:   bash scripts/setup-server.sh
# Safe to run again later (e.g. after uploading a new version) — it keeps your .env and data.
set -euo pipefail

cd "$(dirname "$0")/.."
APP_DIR="$(pwd)"
green() { printf '\033[1;32m%s\033[0m\n' "$*"; }
yellow() { printf '\033[1;33m%s\033[0m\n' "$*"; }
red() { printf '\033[1;31m%s\033[0m\n' "$*"; }

if [ "$(id -u)" -ne 0 ]; then red "Please run as root (log in with: ssh root@YOUR_SERVER_IP)"; exit 1; fi

green "==> 1/5  Updating the server and installing basics"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y ca-certificates curl ufw openssl dnsutils

green "==> 2/5  Installing Docker"
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker

green "==> 3/5  Firewall: allowing SSH, HTTP and HTTPS only"
ufw allow OpenSSH >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw --force enable >/dev/null

green "==> 4/5  Settings (.env)"
if [ ! -f .env ]; then
  cp .env.example .env
  read -rp "Your domain, without https:// (e.g. pushpawater.in): " DOMAIN
  DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN#http://}"; DOMAIN="${DOMAIN%%/*}"
  SECRET="$(openssl rand -hex 48)"
  sed -i "s|^DOMAIN=.*|DOMAIN=${DOMAIN}|" .env
  sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=https://${DOMAIN}|" .env
  sed -i "s|^SESSION_SECRET=.*|SESSION_SECRET=${SECRET}|" .env
  chmod 600 .env
  echo "Saved settings to $APP_DIR/.env (SMS settings can be added there later)."
else
  echo "Keeping existing .env"
fi
DOMAIN="$(grep -E '^DOMAIN=' .env | cut -d= -f2)"

# HTTPS certificates only work once the domain points at this server.
SERVER_IP="$(curl -fsS https://api.ipify.org || true)"
DNS_IP="$(dig +short "$DOMAIN" A | tail -n1 || true)"
if [ -n "$SERVER_IP" ] && [ "$DNS_IP" != "$SERVER_IP" ]; then
  yellow "WARNING: $DOMAIN points to '${DNS_IP:-nothing}', but this server is $SERVER_IP."
  yellow "Set an A record for $DOMAIN (and www) to $SERVER_IP in your domain's DNS settings."
  yellow "The site will start now; HTTPS begins working automatically once DNS is updated (5-30 min)."
fi

green "==> 5/5  Building and starting the site (first time takes 2-4 minutes)"
docker compose up -d --build

sleep 5
if docker compose exec -T app wget -qO- http://127.0.0.1:3000/healthz >/dev/null 2>&1; then
  green ""
  green "✔ AquaLeaf is running!"
  green "  Open:   https://${DOMAIN}"
  green "  Admin:  https://${DOMAIN}/login?role=admin   (admin@aqualeaf.local / admin123 — you must change it at first login)"
  echo  "  Logs:   docker compose logs -f app"
  echo  "  Update: upload the new version, then run this script again"
else
  red "The app did not answer yet. Check with:  docker compose logs app"
fi
