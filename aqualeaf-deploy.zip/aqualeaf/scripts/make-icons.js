// Generates the PWA / app icons (PNG) with no dependencies: `node scripts/make-icons.js`
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const CRC = new Uint32Array(256).map((_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
const crc32 = (buf) => { let c = 0xffffffff; for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(size, pixel) {
  const raw = Buffer.alloc(size * (size * 4 + 1));
  const S = 4; // 4×4 supersampling for smooth edges
  for (let y = 0; y < size; y++) {
    raw[y * (size * 4 + 1)] = 0;
    for (let x = 0; x < size; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let sy = 0; sy < S; sy++) for (let sx = 0; sx < S; sx++) {
        const [pr, pg, pb, pa] = pixel((x + (sx + 0.5) / S) / size, (y + (sy + 0.5) / S) / size);
        r += pr * pa; g += pg * pa; b += pb * pa; a += pa;
      }
      const o = y * (size * 4 + 1) + 1 + x * 4;
      raw[o] = a ? r / a : 0; raw[o + 1] = a ? g / a : 0; raw[o + 2] = a ? b / a : 0; raw[o + 3] = (a / (S * S)) * 255;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// Water drop (circle + tapered top) and a leaf, scaled by `s` around the centre.
function inDrop(u, v, s) {
  const cx = 0.5, cy = 0.5 + 0.1 * s, r = 0.25 * s, top = 0.5 - 0.33 * s;
  if ((u - cx) ** 2 + (v - cy) ** 2 <= r * r) return true;
  if (v < top || v > cy) return false;
  const t = (v - top) / (cy - top);
  return Math.abs(u - cx) <= r * Math.sin((t * Math.PI) / 2) ** 1.2;
}
function inLeaf(u, v, s) {
  const cx = 0.5 + 0.16 * s, cy = 0.5 + 0.2 * s, ang = -0.75;
  const du = u - cx, dv = v - cy;
  const x = du * Math.cos(ang) - dv * Math.sin(ang), y = du * Math.sin(ang) + dv * Math.cos(ang);
  return (x / (0.15 * s)) ** 2 + (y / (0.065 * s)) ** 2 <= 1;
}
const BLUE_TOP = [31, 143, 214], BLUE_BOT = [11, 58, 91], WHITE = [255, 255, 255], GREEN = [52, 168, 83];
const mix = (a, b, t) => a.map((c, i) => c + (b[i] - c) * t);

function appIcon(scale) {
  return (u, v) => {
    if (inLeaf(u, v, scale)) return [...GREEN, 1];
    if (inDrop(u, v, scale)) return [...WHITE, 1];
    return [...mix(BLUE_TOP, BLUE_BOT, v), 1];
  };
}
// Monochrome badge for Android's status bar (white shape on transparent).
const badge = (u, v) => (inDrop(u, v, 1.25) ? [255, 255, 255, 1] : [0, 0, 0, 0]);

const out = path.join(__dirname, '..', 'public', 'icons');
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'icon-192.png'), png(192, appIcon(1)));
fs.writeFileSync(path.join(out, 'icon-512.png'), png(512, appIcon(1)));
fs.writeFileSync(path.join(out, 'maskable-512.png'), png(512, appIcon(0.78)));
fs.writeFileSync(path.join(out, 'apple-touch-icon.png'), png(180, appIcon(0.9)));
fs.writeFileSync(path.join(out, 'badge-96.png'), png(96, badge));
console.log('icons written to', out);
