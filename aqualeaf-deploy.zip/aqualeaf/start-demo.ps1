# Starts the client demo (demo server + public Cloudflare link) as independent background processes,
# so it keeps running after this window closes. Prints the public link and saves it to demo-link.txt.
#   start-demo.cmd            start (or restart) the demo
#   start-demo.cmd -Reset     also rebuild the demo data dated for today (recommended on the morning of a demo)
param([switch]$Reset)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$logs = Join-Path $root 'demo-logs'
New-Item -ItemType Directory -Force $logs | Out-Null

& (Join-Path $root 'stop-demo.ps1') -Quiet
if ($Reset) { node (Join-Path $root 'scripts\seed-demo.js') 2>&1 | Where-Object { $_ -notmatch 'ECONNREFUSED' } | Out-Host }

# Hidden background processes that keep running after this window closes.
function Start-Detached([string]$command) {
  Start-Process -FilePath "$env:SystemRoot\System32\cmd.exe" -ArgumentList "/c $command" -WorkingDirectory $root -WindowStyle Hidden | Out-Null
}
$node = (Get-Command node).Source
Start-Detached "`"`"$node`" --env-file=demo.env server.js > `"$logs\server.log`" 2>&1`""

$up = $false
for ($i = 0; $i -lt 30 -and -not $up; $i++) {
  try { Invoke-WebRequest -UseBasicParsing http://localhost:3100/healthz -TimeoutSec 2 | Out-Null; $up = $true } catch { Start-Sleep 1 }
}
if (-not $up) { Write-Host "Demo server did not start - see $logs\server.log" -ForegroundColor Red; exit 1 }

Remove-Item "$logs\tunnel.log" -ErrorAction SilentlyContinue
Start-Detached "`"`"$root\tools\cloudflared\cloudflared.exe`" tunnel --no-autoupdate --url http://localhost:3100 > `"$logs\tunnel.log`" 2>&1`""

$url = $null
for ($i = 0; $i -lt 60 -and -not $url; $i++) {
  Start-Sleep 1
  if (Test-Path "$logs\tunnel.log") {
    $m = Select-String -Path "$logs\tunnel.log" -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' | Select-Object -First 1
    if ($m) { $url = $m.Matches[0].Value }
  }
}
if (-not $url) { Write-Host "Public link did not start - see $logs\tunnel.log" -ForegroundColor Red; exit 1 }
Set-Content (Join-Path $root 'demo-link.txt') $url
Write-Host ""
Write-Host "Demo is live: $url" -ForegroundColor Green
Write-Host "(saved in demo-link.txt; it can take ~30 seconds before the link answers everywhere)"
