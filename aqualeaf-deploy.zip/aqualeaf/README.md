# AquaLeaf — Drinking Water Delivery

An online shop for drinking water (cans, bottles, jars), with:
- prepaid bookings for **one-time, alternate-day and daily** plans
- **Razorpay** online payment and **WhatsApp** updates
- an admin dashboard and a delivery-agent app with push alerts
- customer accounts, empty-can tracking, coupons and referrals, invoices and reports

## Run it locally

Requires **Node.js 22.13+**. It uses Node's built-in SQLite, so there's no database to install.

```bash
npm install
npm start
```

Open http://localhost:3000. Data is stored in `data/aqualeaf.db`, and daily backups go to `data/backups/`.
- **To go live:** see [GO-LIVE-HOSTINGER.md](GO-LIVE-HOSTINGER.md) or [DEPLOY.md](DEPLOY.md).
- **To connect payments and WhatsApp:** see [RAZORPAY-WHATSAPP-SETUP.md](RAZORPAY-WHATSAPP-SETUP.md).

| Page | URL | Who |
|---|---|---|
| Shop | `/` | Customers |
| Book & pay | `/book` (optional `?plan=daily`, `?code=COUPON`) | Customers |
| Booking status, bills and rating | `/track` | Customers |
| My account (login code on WhatsApp) | `/account` | Customers |
| Admin | `/admin` (login at `/login?role=admin`) | Owner and office |
| Delivery agent app | `/agent` (login at `/login?role=agent`, installable) | Agents |

### First login
The first run creates `admin@aqualeaf.local` / `admin123` and two demo agents (`ravi@…`, `sunil@…` / `agent123`).
**Each account must choose a new password at first login.**

### Test mode (until Razorpay and WhatsApp are connected)
- "Pay & book" opens a built-in **test payment page**. No money is taken.
- WhatsApp messages are printed in the server log.
- Customer login codes are shown on screen.

## Features

**Customers**
- Pick products and quantities, then enter name, contact number, email, address, PIN code and line/lane number.
- Plan: **one time, alternate days or daily**, with a **time slot** (full or too-late slots are blocked).
- Coupon or referral code.
- The total for the whole plan (plus any refundable can deposit) is **paid upfront with Razorpay**: UPI, cards,
  net banking or wallets.
- **My account:**
  - Bookings, bills, cans and deposits, and the referral code.
  - **Skip** a delivery or **pause** a date range; prepaid deliveries **move to the end of the plan**.
  - Cancel; the unused amount is refunded by the office.
- **Booking page:** payment status (with "Pay now" if not completed), schedule, delivery person, bills, and
  **star ratings**.

**Admin**
- **Dashboard:**
  - Paid today and this month.
  - Bookings awaiting payment, and paid bookings to confirm.
  - Refunds due, cans out, rating.
- **Bookings:** confirm a paid booking and assign a delivery person, which schedules the deliveries. Also reassign,
  cancel (shows the refund due), resend the payment link, and record a refund.
- **Deliveries:** reassign, reschedule, mark as delivered.
- **Payments:** Razorpay payments received, bookings awaiting payment, refunds to issue.
- **Customers**, **cans and deposits**, **billing statements**.
- **Reports:** by product, agent, plan, area and day, with CSV export.
- **Ratings**, **coupons and referrals**, **areas and time slots**, **products**, **staff**, **settings** and
  backups.

**Delivery agents**
- Installable app (PWA) with **push notifications that arrive even when the app is closed**, and an alert chime.
- Each day's deliveries show directions, the line/lane number, notes, and cans to give and empties to collect.
  Orders are prepaid, so **no cash is handled**.
- Start delivery (the customer gets a WhatsApp update), mark Delivered (which creates the invoice), or mark Not
  delivered (pick a reason).

## Notifications

| Event | Staff (🔔 bell, push, WhatsApp) | Customer (WhatsApp) |
|---|---|---|
| Booking created | — | Payment link |
| Payment received | All admins: "New paid booking" | Booking confirmed and paid, with tracking link |
| Booking confirmed or reassigned | The delivery person (and the previous one) | — |
| Out for delivery | — | Delivery person's name and phone |
| Delivered | — | Bill link |
| Customer skips, pauses or cancels | Admins and the delivery person | — |
| Not delivered / 1–2★ rating | All admins | — |
| My account login | — | 6-digit login code |

## Configuration

See [.env.example](.env.example). Key settings:
- `PORT`, `DATA_DIR`, `SESSION_SECRET`, `PUBLIC_URL`
- `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`
- `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`
- optional SMS fallback (`SMS_PROVIDER`)
- `BACKUP_DIR`, `BACKUP_KEEP_DAYS`, `TRUST_PROXY`, `FORCE_HTTPS`

## Project layout

```
server.js                 app setup, security headers, routes
server/db.js              schema + migrations + first-run data
server/booking.js         pricing, slots, coupons/referrals, prepaid booking & delivery lifecycle, cans
server/payments.js        payment links (Razorpay or built-in test page)
server/razorpay.js        Razorpay Payment Links API + signature checks
server/whatsapp.js        Meta WhatsApp Cloud API (template messages)
server/messaging.js       customer messages: WhatsApp → SMS fallback
server/notify.js          staff notifications: in-app + Web Push + WhatsApp
server/routes/*.js        public, staff, agent, admin, customer APIs
public/                   pages (HTML/CSS/JS), service worker, manifest, icons
android-agent/            optional Capacitor Android app for agents
Dockerfile, docker-compose.yml, Caddyfile, render.yaml
```
