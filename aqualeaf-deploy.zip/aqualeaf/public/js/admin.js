// Admin dashboard: single page with hash-based views.
let ME = null;
let AGENTS = [];

const VIEWS = {
  dashboard: { title: 'Dashboard', render: renderDashboard },
  bookings: { title: 'Bookings', render: renderBookings },
  deliveries: { title: 'Deliveries', render: renderDeliveries },
  payments: { title: 'Payments (Razorpay)', render: renderPayments },
  customers: { title: 'Customers', render: renderCustomers },
  cans: { title: 'Cans & deposits', render: renderCans },
  billing: { title: 'Billing', render: renderBilling },
  reports: { title: 'Reports', render: renderReports },
  ratings: { title: 'Customer ratings', render: renderRatings },
  coupons: { title: 'Coupons & referrals', render: renderCoupons },
  areas: { title: 'Delivery areas & time slots', render: renderAreas },
  products: { title: 'Products', render: renderProducts },
  staff: { title: 'Staff & delivery agents', render: renderStaff },
  settings: { title: 'Settings', render: renderSettings },
};

const view = () => $('#view');
const setActions = (html = '') => { $('#viewActions').innerHTML = html; };
const agentOptions = (selected) => AGENTS.filter((a) => a.role === 'agent' && a.active)
  .map((a) => `<option value="${a.id}" ${a.id === selected ? 'selected' : ''}>${esc(a.name)}</option>`).join('');
const statCard = (label, value, sub = '') => `<div class="card stat"><span class="label">${label}</span><span class="value">${value}</span>${sub ? `<span class="sub">${sub}</span>` : ''}</div>`;

async function loadAgents() { AGENTS = await api('/api/admin/users'); }

async function route() {
  const name = (location.hash.slice(1).split('?')[0]) || 'dashboard';
  const v = VIEWS[name] || VIEWS.dashboard;
  $$('.sidebar [data-view]').forEach((a) => a.classList.toggle('active', a.dataset.view === name));
  $('#sidebar').classList.remove('open');
  $('#viewTitle').textContent = v.title;
  setActions();
  view().innerHTML = '<div class="empty">Loading…</div>';
  view().onclick = null;
  try { await v.render(); } catch (e) {
    if (e.status === 401) return location.replace('/login?role=admin');
    if (e.code === 'change_password') return requirePasswordChange(() => location.reload());
    view().innerHTML = `<div class="alert error">${esc(e.message)}</div>`;
  }
}

async function refreshPendingCount() {
  try {
    const n = (await api('/api/admin/bookings?status=pending')).filter((b) => b.payment_status !== 'unpaid').length;
    $('#pendingCount').textContent = n;
    $('#pendingCount').classList.toggle('hidden', !n);
  } catch { /* ignore */ }
}

// ------------------------------------------------------------------ dashboard
async function renderDashboard() {
  const s = await api('/api/admin/stats');
  setActions('<button class="btn green" data-new-booking>+ New booking</button>');
  const td = s.todayDeliveries;
  const days = Array.from({ length: 7 }, (_, i) => todayStr(i - 6));
  const byDay = Object.fromEntries(s.last7.map((r) => [r.date, r]));
  const maxBilled = Math.max(1, ...s.last7.map((r) => r.billed));
  view().innerHTML = `
    ${s.pendingBookings ? `<div class="alert warn" style="margin-bottom:16px">🔔 <strong>${s.pendingBookings}</strong> paid booking${s.pendingBookings > 1 ? 's are' : ' is'} waiting for confirmation. <a href="#bookings?status=pending">Review now →</a></div>` : ''}
    ${s.toRefund ? `<div class="alert error" style="margin-bottom:16px">↩ <strong>${s.toRefund}</strong> cancelled paid booking${s.toRefund > 1 ? 's need' : ' needs'} a refund. <a href="#payments">See payments →</a></div>` : ''}
    <div class="grid grid-4">
      ${statCard("Today's deliveries", td.total || 0, `${td.delivered || 0} delivered · ${td.onroute || 0} on the way · ${td.scheduled || 0} pending`)}
      ${statCard('Paid today', money(s.paidToday.amount), `${s.paidToday.n} payment${s.paidToday.n === 1 ? '' : 's'} via Razorpay`)}
      ${statCard('This month', money(s.month.paid - s.month.refunded), `${s.month.n} paid bookings · ${s.monthDelivered} deliveries`)}
      ${statCard('Awaiting payment', `<a href="#payments">${s.awaitingPayment}</a>`, 'Bookings started but not paid')}
      ${statCard('To confirm', s.pendingBookings, 'Paid, needs a delivery person')}
      ${statCard('Active subscriptions', s.activeSubscriptions, `${s.customers} customers`)}
      ${statCard('Cans with customers', `<a href="#cans">${s.cansOut}</a>`)}
      ${statCard('Customer rating', s.rating.n ? `★ ${s.rating.avg}` : '—', s.rating.n ? `${s.rating.n} ratings` : `Failed today: ${td.failed || 0}`)}
    </div>
    <div class="grid grid-2" style="margin-top:16px">
      <div class="card"><h3>Payments received — last 7 days</h3>
        <div class="chart">${days.map((d) => {
          const r = byDay[d] || { billed: 0, bookings: 0 };
          return `<div class="col" title="${fmtDate(d)}: ${money(r.billed)} · ${r.bookings} payments"><span>${r.billed ? Math.round(r.billed) : ''}</span>
            <div class="b" style="height:${(r.billed / maxBilled) * 100}%"></div><span>${fmtDate(d).split(' ').slice(0, 2).join(' ')}</span></div>`;
        }).join('')}</div>
      </div>
      <div class="card"><h3>Low stock</h3>
        ${s.lowStock.length ? s.lowStock.map((p) => `<div class="summary-row"><span>${esc(p.name)}</span><span class="badge b-${p.stock ? 'pending' : 'failed'}">${p.stock} left</span></div>`).join('')
          : '<p class="muted">All products are well stocked.</p>'}
      </div>
    </div>
    <div class="card" style="margin-top:16px"><div class="row between"><h3>Recent bookings</h3><a href="#bookings">View all →</a></div>
      ${bookingTable(s.recent, true)}
    </div>`;
}

function bookingTable(rows, compact = false) {
  if (!rows.length) return '<div class="empty">No bookings found.</div>';
  return `<div class="table-wrap"><table><thead><tr><th>Booking</th><th>Customer</th><th>Plan</th><th>Start</th>${compact ? '' : '<th>Delivery person</th><th>Progress</th>'}
    <th class="num">Total</th><th>Payment</th><th>Status</th><th></th></tr></thead><tbody>
    ${rows.map((b) => `<tr>
      <td><strong>${esc(b.booking_no)}</strong>${b.tracking_id ? `<div class="small muted">${esc(b.tracking_id)}</div>` : ''}</td>
      <td>${esc(b.name)}${b.phone ? `<div class="small muted">${esc(b.phone)}</div>` : ''}</td>
      <td>${freqBadge(b.frequency)}</td>
      <td class="nowrap">${fmtDate(b.start_date)}${b.delivery_time ? `<div class="small muted">${fmtTime(b.delivery_time)}</div>` : ''}</td>
      ${compact ? '' : `<td>${esc(b.agent_name || '—')}</td><td class="nowrap">${b.delivery_count ? `${b.delivered_count}/${b.delivery_count}` : '—'}</td>`}
      <td class="num">${money(b.total_amount || b.amount_per_delivery)}</td>
      <td>${payBadge(b.payment_status)}</td>
      <td>${badge(b.status)}</td>
      <td class="right"><button class="btn sm ${b.status === 'pending' && b.payment_status !== 'unpaid' ? 'green' : 'ghost'}" data-booking="${b.id}">${b.status === 'pending' && b.payment_status !== 'unpaid' ? 'Confirm' : 'Open'}</button></td>
    </tr>`).join('')}</tbody></table></div>`;
}

// ------------------------------------------------------------------ bookings
async function renderBookings() {
  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  setActions('<button class="btn green" data-new-booking>+ New booking</button>');
  view().innerHTML = `
    <form class="toolbar" id="bkFilter">
      <div class="field"><label>Search</label><input name="q" placeholder="Name, phone, email, booking or tracking no." value="${esc(params.get('q') || '')}" style="min-width:260px"></div>
      <div class="field"><label>Status</label><select name="status"><option value="">All</option>${['pending', 'confirmed', 'completed', 'cancelled']
        .map((s) => `<option ${params.get('status') === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      <div class="field"><label>Plan</label><select name="frequency"><option value="">All</option>${PLANS
        .map((k) => `<option value="${k}" ${params.get('frequency') === k ? 'selected' : ''}>${FREQ[k]}</option>`).join('')}</select></div>
      <button class="btn ghost">Filter</button>
    </form>
    <div id="bkList"><div class="empty">Loading…</div></div>`;
  const load = async () => {
    const f = new URLSearchParams(formData($('#bkFilter')));
    $('#bkList').innerHTML = bookingTable(await api(`/api/admin/bookings?${f}`));
  };
  $('#bkFilter').addEventListener('submit', (e) => { e.preventDefault(); load(); });
  $('#bkFilter').addEventListener('change', load);
  await load();
}

async function openBooking(id) {
  const b = await api(`/api/admin/bookings/${id}`);
  const t = todayStr();
  const delivered = b.deliveries.filter((d) => d.status === 'delivered');
  const body = `
    <div class="row between" style="margin-bottom:10px"><div>${badge(b.status)} ${freqBadge(b.frequency)}</div>
      ${b.tracking_id ? `<div class="small">Tracking ID: <strong>${esc(b.tracking_id)}</strong> · <a href="/track?id=${esc(b.tracking_id)}" target="_blank">customer view ↗</a></div>` : ''}</div>
    <div class="grid grid-2">
      <dl class="kv">
        <dt>Customer</dt><dd>${esc(b.name)}</dd>
        <dt>Contact no.</dt><dd><a href="tel:${esc(b.phone)}">${esc(b.phone)}</a></dd>
        <dt>Email</dt><dd>${esc(b.email)}</dd>
        <dt>Address</dt><dd>${esc(b.address)}</dd>
        <dt>Line / Lane No.</dt><dd>${esc(b.line_no || '—')}</dd>
        <dt>PIN code</dt><dd>${esc(b.pincode || '—')}</dd>
        ${b.notes ? `<dt>Notes</dt><dd>${esc(b.notes)}</dd>` : ''}
      </dl>
      <dl class="kv">
        <dt>Date &amp; time</dt><dd>${fmtDate(b.start_date)}${b.frequency === 'once' ? '' : ` → ${fmtDate(b.end_date)}`}<br>
          ${b.slot_label ? `${esc(b.slot_label)} · ${fmtTime(b.slot_start)}–${fmtTime(b.slot_end)}` : fmtTime(b.delivery_time)}</dd>
        <dt>Delivery person</dt><dd>${esc(b.agent_name || 'Not assigned')}</dd>
        <dt>Payment</dt><dd>${payBadge(b.payment_status)} ${b.payment_status === 'unpaid' ? `${money(b.total_amount)} due` : money(b.paid_amount)}
          ${b.payment_ref ? `<div class="small muted">Ref ${esc(b.payment_ref)}${b.paid_at ? ` · ${fmtDateTime(b.paid_at)}` : ''}</div>` : ''}
          ${b.refunded_amount ? `<div class="small muted">Refunded ${money(b.refunded_amount)}</div>` : ''}</dd>
        ${b.coupon_code ? `<dt>Code used</dt><dd>${esc(b.coupon_code)} · − ${money(b.discount)} ${b.discount_scope === 'all' ? 'each delivery' : 'first delivery'}
          ${b.referred_by_name ? `<br><span class="small muted">Referred by ${esc(b.referred_by_name)}</span>` : ''}</dd>` : ''}
        <dt>Booked on</dt><dd>${fmtDateTime(b.created_at)}</dd>
        <dt>Deliveries</dt><dd>${delivered.length} delivered of ${b.deliveries.filter((d) => d.status !== 'cancelled').length || '—'}</dd>
        <dt>Booking total</dt><dd>${money(b.total_amount)}${b.deposit_amount ? ` <span class="small muted">(incl. ${money(b.deposit_amount)} can deposit)</span>` : ''}</dd>
      </dl>
    </div>
    <h3 style="margin-top:14px">Items</h3>
    <div class="table-wrap"><table><thead><tr><th>Product</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr></thead><tbody>
      ${b.items.map((i) => `<tr><td>${esc(i.name)} <span class="small muted">${esc(i.unit)}</span></td><td class="num">${i.quantity}</td><td class="num">${money(i.price)}</td><td class="num">${money(i.price * i.quantity)}</td></tr>`).join('')}
      ${b.delivery_charge ? `<tr><td colspan="3">Delivery charge</td><td class="num">${money(b.delivery_charge)}</td></tr>` : ''}
      <tr><td colspan="3"><strong>Per delivery</strong>${b.discount ? ` <span class="small muted">(before ${money(b.discount)} discount)</span>` : ''}</td><td class="num"><strong>${money(b.amount_per_delivery)}</strong></td></tr>
    </tbody></table></div>
    ${b.status === 'pending' && b.payment_status === 'unpaid' ? `<div class="card" style="margin-top:16px;background:var(--amber-100)"><h3>Waiting for payment</h3>
      <p style="margin-top:0">The customer hasn't paid ${money(b.total_amount)} yet. The booking can be confirmed once paid.</p>
      <button class="btn" id="sendLinkBtn">Send payment link again</button> <span class="small muted" id="linkOut"></span></div>` : ''}
    ${b.status === 'pending' && b.payment_status !== 'unpaid' ? `<div class="card" style="margin-top:16px;background:var(--green-100)"><h3>Confirm booking</h3>
      <div class="row"><select id="confirmAgent" class="inline-input" style="min-width:220px"><option value="">Choose delivery person…</option>${agentOptions()}</select>
      <button class="btn green" id="confirmBtn">Confirm &amp; schedule deliveries</button></div></div>` : ''}
    ${['paid', 'partially_refunded'].includes(b.payment_status) && b.refundable > 0 && b.status === 'cancelled' ? `<div class="card" style="margin-top:16px;background:var(--red-100)">
      <h3>Refund due: ${money(b.refundable)}</h3>
      <p style="margin-top:0">Issue the refund in your <strong>Razorpay dashboard → Payments → ${esc(b.payment_ref || 'this payment')} → Refund</strong>, then record it here.</p>
      <button class="btn red" id="refundBtn">Record refund</button></div>` : ''}
    ${b.status === 'confirmed' ? `<div class="row" style="margin-top:16px"><span>Reassign upcoming deliveries to</span>
      <select id="assignAgent" class="inline-input">${agentOptions(b.agent_id)}</select><button class="btn ghost sm" id="assignBtn">Reassign</button></div>` : ''}
    ${b.deliveries.length ? `<h3 style="margin-top:16px">Delivery schedule</h3>
      <div class="table-wrap" style="max-height:300px;overflow:auto"><table><thead><tr><th>#</th><th>Date</th><th>Agent</th><th>Status</th><th class="num">Amount</th><th>Invoice</th></tr></thead><tbody>
      ${b.deliveries.map((d) => `<tr ${d.scheduled_date === t ? 'style="background:var(--blue-50)"' : ''}><td>${d.seq}</td><td class="nowrap">${fmtDate(d.scheduled_date)} ${fmtTime(d.scheduled_time)}</td>
        <td>${esc(d.agent_name || '—')}</td><td>${badge(d.status)}${d.note ? `<div class="small muted">${esc(d.note)}</div>` : ''}${d.rating ? `<div class="small" style="color:#f5a623">${'★'.repeat(d.rating)}</div>` : ''}</td>
        <td class="num">${money(d.amount + d.deposit_amount)}${d.deposit_amount ? `<div class="small muted">incl. ${money(d.deposit_amount)} deposit</div>` : ''}</td>
        <td>${d.invoice_no ? `<a href="/invoice?id=${d.id}" target="_blank">${esc(d.invoice_no)}</a>` : '—'}</td></tr>`).join('')}
      </tbody></table></div>` : ''}`;
  const foot = `${['pending', 'confirmed'].includes(b.status) ? '<button class="btn red" id="cancelBtn">Cancel booking</button>' : ''}<button class="btn ghost" data-close>Close</button>`;
  openModal({
    title: `Booking ${b.booking_no}`, body, foot, wide: true,
    onOpen: (el, close) => {
      const after = async (msg) => { toast(msg, 'success'); close(); refreshPendingCount(); await route(); };
      $('#confirmBtn', el)?.addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        const agentId = $('#confirmAgent', el).value;
        if (!agentId) throw new Error('Choose a delivery person first');
        const r = await api(`/api/admin/bookings/${b.id}/confirm`, { body: { agent_id: Number(agentId) } });
        await after(`Confirmed — tracking ID ${r.tracking_id}`);
      }));
      $('#assignBtn', el)?.addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        await api(`/api/admin/bookings/${b.id}/assign`, { body: { agent_id: Number($('#assignAgent', el).value) } });
        await after('Delivery person updated');
      }));
      $('#cancelBtn', el)?.addEventListener('click', (e) => {
        if (!confirm(`Cancel booking ${b.booking_no}? All upcoming deliveries will be cancelled.`)) return;
        withBusy(e.currentTarget, async () => {
          const r = await api(`/api/admin/bookings/${b.id}/cancel`, { body: {} });
          await after(r.refundable ? `Booking cancelled — refund ${money(r.refundable)} via Razorpay` : 'Booking cancelled');
        });
      });
      $('#sendLinkBtn', el)?.addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        const r = await api(`/api/admin/bookings/${b.id}/payment-link`, { body: {} });
        showPayLink(b, r.pay_url);
      }));
      $('#refundBtn', el)?.addEventListener('click', () => openModal({
        title: `Record refund — ${b.booking_no}`,
        body: `<form id="rfForm"><div class="field"><label>Amount refunded in Razorpay</label><input type="number" step="0.01" min="1" name="amount" value="${b.refundable}"></div>
          <div class="field"><label>Note</label><input name="note" placeholder="e.g. Razorpay refund rfnd_…"></div></form>`,
        foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn red" id="rfSave">Save</button>',
        onOpen: (el2, close2) => $('#rfSave', el2).addEventListener('click', (ev) => withBusy(ev.currentTarget, async () => {
          const f = formData($('#rfForm', el2));
          await api(`/api/admin/bookings/${b.id}/refund`, { body: { amount: Number(f.amount), note: f.note } });
          close2();
          await after('Refund recorded');
        })),
      }));
    },
  });
}

// Payment link to share with a customer (also sent on WhatsApp when it's connected).
function showPayLink(b, url) {
  const text = `Hi ${b.name.split(' ')[0]}, please pay ${money(b.total_amount)} for your ${SETTINGS.business_name} booking ${b.booking_no}: ${url}`;
  openModal({
    title: `Payment link — ${b.booking_no}`,
    body: `<p>Share this link with ${esc(b.name)} (${esc(b.phone)}) to pay <strong>${money(b.total_amount)}</strong>.</p>
      <div class="row" style="flex-wrap:nowrap"><input value="${esc(url)}" readonly id="plUrl"><button class="btn ghost" id="plCopy">Copy</button></div>
      <div class="row" style="margin-top:12px"><a class="btn green" target="_blank" rel="noopener" href="https://wa.me/${esc(b.phone.replace(/\D/g, '').replace(/^(\d{10})$/, '91$1'))}?text=${encodeURIComponent(text)}">Send on WhatsApp</a>
        <a class="btn ghost" target="_blank" href="${esc(url)}">Open link</a></div>`,
    onOpen: (el) => $('#plCopy', el).addEventListener('click', () => navigator.clipboard?.writeText(url).then(() => toast('Link copied', 'success'))),
  });
}

async function newBooking() {
  const [products, slots] = await Promise.all([api('/api/admin/products'), api('/api/admin/slots')]);
  const active = products.filter((p) => p.active);
  const body = `<form id="nbForm" novalidate>
    <div class="grid grid-2">
      <div class="field"><label class="req">Customer name</label><input name="name" required></div>
      <div class="field"><label class="req">Contact number</label><input name="phone" required inputmode="tel" id="nbPhone"></div>
      <div class="field"><label class="req">Email ID</label><input name="email" type="email" required></div>
      <div class="field"><label>Line / Lane No.</label><input name="line_no"></div>
    </div>
    <div class="field"><label class="req">Address</label><textarea name="address" required></textarea></div>
    <div class="grid grid-4">
      <div class="field"><label class="req">PIN code</label><input name="pincode" inputmode="numeric" maxlength="10"></div>
      <div class="field"><label class="req">Plan</label><select name="frequency">${PLANS.map((k) => `<option value="${k}">${FREQ[k]}</option>`).join('')}</select></div>
      <div class="field"><label class="req">Date</label><input type="date" name="start_date" value="${todayStr()}" min="${todayStr()}"></div>
      <div class="field"><label>End date</label><input type="date" name="end_date"><div class="hint">Blank = default length</div></div>
    </div>
    <div class="grid grid-4">
      <div class="field" style="grid-column:span 2"><label class="req">Time slot</label><select name="slot_id">
        ${slots.filter((s) => s.active).map((s) => `<option value="${s.id}">${esc(s.label)} · ${fmtTime(s.start_time)}–${fmtTime(s.end_time)}</option>`).join('')}
        <option value="">Custom time →</option></select></div>
      <div class="field"><label>Custom time</label><input type="time" name="delivery_time" value="08:00"></div>
      <div class="field"><label>Coupon / referral code</label><input name="coupon_code" style="text-transform:uppercase"></div>
    </div>
    <label class="row small" style="font-weight:500;margin-bottom:12px"><input type="checkbox" name="override_capacity" style="width:auto"> Allow even if the slot is full</label>
    <label>Quantity</label>
    <div class="table-wrap" style="max-height:260px;overflow:auto"><table><tbody>
      ${active.map((p) => `<tr><td>${esc(p.name)} <span class="small muted">${esc(p.unit)}</span></td><td class="num">${money(p.price)}</td>
        <td style="width:110px"><input type="number" min="0" max="999" value="0" data-pid="${p.id}" class="inline-input" style="width:90px"></td></tr>`).join('')}
    </tbody></table></div>
    <div class="field" style="margin-top:12px"><label>Notes</label><input name="notes"></div>
    <p class="small muted">After saving, you get a Razorpay payment link for the customer (also sent on WhatsApp when connected). Assign a delivery person once it's paid.</p>
  </form>`;
  openModal({
    title: 'New booking', body, wide: true,
    foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn green" id="nbSave">Create booking</button>',
    onOpen: (el, close) => {
      // Prefill a returning customer's saved details by phone number.
      $('#nbPhone', el).addEventListener('change', async (e) => {
        const phone = e.target.value.replace(/[\s()-]/g, '');
        if (phone.length < 10) return;
        const found = (await api(`/api/admin/customers?q=${encodeURIComponent(phone)}`)).find((c) => c.phone === phone);
        if (!found) return;
        const f = $('#nbForm', el);
        for (const k of ['name', 'email', 'address', 'line_no', 'pincode']) if (!f[k].value) f[k].value = found[k];
        toast(`Returning customer: ${found.name}`, 'success');
      });
      $('#nbSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        const data = formData($('#nbForm', el));
        data.items = $$('[data-pid]', el).filter((i) => Number(i.value) > 0).map((i) => ({ product_id: Number(i.dataset.pid), quantity: Number(i.value) }));
        if (!data.slot_id) delete data.slot_id;
        data.override_capacity = data.override_capacity === 'on';
        const r = await api('/api/admin/bookings', { body: data });
        toast(`Booking ${r.booking_no} created — waiting for payment`, 'success');
        close();
        route();
        if (r.pay_url) showPayLink({ ...data, booking_no: r.booking_no, total_amount: r.total }, r.pay_url);
        else if (r.pay_error) toast(r.pay_error, 'error');
      }));
    },
  });
}

// ------------------------------------------------------------------ deliveries
async function renderDeliveries() {
  setActions('');
  view().innerHTML = `
    <form class="toolbar" id="dvFilter">
      <div class="field"><label>From</label><input type="date" name="from" value="${todayStr()}"></div>
      <div class="field"><label>To</label><input type="date" name="to" value="${todayStr()}"></div>
      <div class="field"><label>Delivery person</label><select name="agent_id"><option value="">All</option>${agentOptions()}</select></div>
      <div class="field"><label>Status</label><select name="status"><option value="">All</option>${['scheduled', 'out_for_delivery', 'delivered', 'failed', 'cancelled']
        .map((s) => `<option value="${s}">${STATUS[s] || s}</option>`).join('')}</select></div>
      <button class="btn ghost">Show</button>
    </form>
    <div id="dvList"><div class="empty">Loading…</div></div>`;
  const load = async () => {
    const rows = await api(`/api/admin/deliveries?${new URLSearchParams(formData($('#dvFilter')))}`);
    const billed = rows.filter((r) => r.status === 'delivered');
    $('#dvList').innerHTML = rows.length ? `
      <p class="muted small">${rows.length} deliveries · ${billed.length} delivered · ${money(billed.reduce((s, r) => s + r.amount, 0))} delivered value</p>
      <div class="table-wrap"><table><thead><tr><th>Date / time</th><th>Customer &amp; address</th><th>Items</th><th>Delivery person</th><th>Status</th><th class="num">Amount</th><th></th></tr></thead><tbody>
      ${rows.map((d) => `<tr>
        <td class="nowrap">${fmtDate(d.scheduled_date)}<div class="small muted">${d.slot_start ? `${fmtTime(d.slot_start)}–${fmtTime(d.slot_end)}` : fmtTime(d.scheduled_time)}</div></td>
        <td><strong>${esc(d.name)}</strong> <span class="small muted">${esc(d.booking_no)}</span><div class="small">${esc(d.phone)}</div>
          <div class="small muted">${esc(d.address)}${d.line_no ? ` · Line ${esc(d.line_no)}` : ''}</div></td>
        <td class="small">${d.items.map((i) => `${esc(i.name)} × ${i.quantity}`).join('<br>')}</td>
        <td>${['scheduled', 'out_for_delivery'].includes(d.status)
          ? `<select class="inline-input" data-reassign="${d.id}">${agentOptions(d.agent_id)}</select>` : esc(d.agent_name || '—')}</td>
        <td>${badge(d.status)}${d.note ? `<div class="small muted">${esc(d.note)}</div>` : ''}</td>
        <td class="num">${money(d.amount + d.deposit_amount)}${d.deposit_amount ? `<div class="small muted">incl. ${money(d.deposit_amount)} deposit</div>` : ''}
          <div>${payBadge(d.payment_status)}</div></td>
        <td class="right nowrap">${deliveryActions(d)}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">No deliveries for these filters.</div>';
  };
  $('#dvFilter').addEventListener('submit', (e) => { e.preventDefault(); load(); });
  $('#dvFilter').addEventListener('change', load);
  $('#dvList').addEventListener('change', async (e) => {
    const id = e.target.dataset.reassign;
    if (!id) return;
    try { await api(`/api/admin/deliveries/${id}`, { method: 'PATCH', body: { agent_id: Number(e.target.value) } }); toast('Delivery reassigned', 'success'); }
    catch (err) { toast(err.message, 'error'); load(); }
  });
  $('#dvList').addEventListener('click', (e) => {
    const b = e.target.closest('[data-dv]');
    if (b) deliveryAction(Number(b.dataset.id), b.dataset.dv, load);
  });
  await load();
}

function deliveryActions(d) {
  const btn = (act, label, cls = 'ghost') => `<button class="btn sm ${cls}" data-dv="${act}" data-id="${d.id}" data-amount="${d.amount + d.deposit_amount}">${label}</button>`;
  if (d.status === 'scheduled' || d.status === 'out_for_delivery') return `${btn('deliver', 'Mark delivered', 'green')} ${btn('reschedule', 'Reschedule')} ${btn('cancel', 'Cancel')}`;
  if (d.status === 'delivered') return `<a class="btn sm ghost" href="/invoice?id=${d.id}" target="_blank">Invoice</a>`;
  if (d.status === 'failed' || d.status === 'cancelled') return btn('reschedule', 'Reschedule');
  return '';
}

function deliveryAction(id, act, reload) {
  const amount = Number($(`[data-dv][data-id="${id}"]`)?.dataset.amount || 0);
  const patch = async (body, msg) => { await api(`/api/admin/deliveries/${id}`, { method: 'PATCH', body }); toast(msg, 'success'); await reload(); };
  if (act === 'cancel') {
    if (confirm('Cancel this delivery?')) patch({ status: 'cancelled' }, 'Delivery cancelled').catch((e) => toast(e.message, 'error'));
    return;
  }
  const forms = {
    deliver: { title: 'Mark as delivered', html: `<p>This order (${money(amount)}) is prepaid online. Empty cans are recorded as swapped 1-for-1.</p>`,
      submit: () => patch({ status: 'delivered' }, 'Marked delivered — invoice generated') },
    reschedule: { title: 'Reschedule delivery', html: `<div class="grid grid-2"><div class="field"><label>New date</label><input type="date" name="scheduled_date" value="${todayStr(1)}" min="${todayStr()}"></div>
        <div class="field"><label>Time</label><input type="time" name="scheduled_time" value="08:00"></div></div>`,
      submit: (f) => patch({ status: 'scheduled', scheduled_date: f.scheduled_date, scheduled_time: f.scheduled_time }, 'Delivery rescheduled') },
  };
  const cfg = forms[act];
  openModal({
    title: cfg.title, body: `<form id="dvForm">${cfg.html}</form>`,
    foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="dvSave">Save</button>',
    onOpen: (el, close) => $('#dvSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => { await cfg.submit(formData($('#dvForm', el))); close(); })),
  });
}

// ------------------------------------------------------------------ payments
async function renderPayments() {
  const t = todayStr();
  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  const from = params.get('from') || `${t.slice(0, 7)}-01`, to = params.get('to') || t;
  const r = await api(`/api/admin/payments?from=${from}&to=${to}`);
  const MODE = { razorpay: '🟢 Razorpay live', 'razorpay-test': '🟡 Razorpay test mode', test: '🟡 Built-in test payments (add Razorpay keys to go live)', off: '🔴 Online payment not set up' };
  view().innerHTML = `
    <div class="alert ${r.mode === 'razorpay' ? '' : 'warn'}" style="margin-bottom:14px"><strong>${MODE[r.mode]}</strong>
      ${r.mode !== 'razorpay' ? ' — see RAZORPAY-WHATSAPP-SETUP.md to connect your Razorpay account.' : ''}</div>
    <form class="toolbar" id="pyForm"><div class="field"><label>From</label><input type="date" name="from" value="${from}"></div>
      <div class="field"><label>To</label><input type="date" name="to" value="${to}"></div><button class="btn ghost">Show</button></form>
    <div class="grid grid-3">${statCard('Received', money(r.summary.paid), `${r.summary.n} payments`)}${statCard('Refunded', money(r.summary.refunded))}
      ${statCard('Net', money(r.summary.paid - r.summary.refunded))}</div>
    ${r.toRefund.length ? `<div class="card" style="margin-top:16px;border-color:#f8c7c7"><h3>↩ Refunds to issue</h3>
      <div class="table-wrap"><table><thead><tr><th>Booking</th><th>Customer</th><th class="num">Paid</th><th class="num">Refund due</th><th></th></tr></thead><tbody>
      ${r.toRefund.map((b) => `<tr><td>${esc(b.booking_no)}</td><td>${esc(b.name)}<div class="small muted">${esc(b.phone)}</div></td><td class="num">${money(b.paid_amount)}</td>
        <td class="num" style="color:var(--red-600);font-weight:700">${money(b.refundable)}</td><td class="right"><button class="btn sm ghost" data-booking="${b.id}">Open</button></td></tr>`).join('')}
      </tbody></table></div></div>` : ''}
    ${r.awaiting.length ? `<div class="card" style="margin-top:16px"><h3>Awaiting payment</h3>
      <div class="table-wrap"><table><thead><tr><th>Booking</th><th>Customer</th><th>Started</th><th class="num">Amount</th><th></th></tr></thead><tbody>
      ${r.awaiting.map((b) => `<tr><td>${esc(b.booking_no)}</td><td>${esc(b.name)}<div class="small muted">${esc(b.phone)}</div></td><td class="nowrap">${fmtDateTime(b.created_at)}</td>
        <td class="num">${money(b.total_amount)}</td><td class="right"><button class="btn sm ghost" data-booking="${b.id}">Open</button></td></tr>`).join('')}
      </tbody></table></div></div>` : ''}
    <div class="card" style="margin-top:16px"><h3>Payments received</h3>
      ${r.rows.length ? `<div class="table-wrap"><table><thead><tr><th>When</th><th>Booking</th><th>Customer</th><th>Plan</th><th>Razorpay ref</th><th class="num">Paid</th><th>Status</th></tr></thead><tbody>
      ${r.rows.map((p) => `<tr><td class="nowrap">${fmtDateTime(p.paid_at)}</td><td>${esc(p.booking_no)}</td><td>${esc(p.name)}</td><td>${freqBadge(p.frequency)}</td>
        <td class="small">${esc(p.payment_ref || '—')}</td><td class="num">${money(p.paid_amount)}${p.refunded_amount ? `<div class="small muted">−${money(p.refunded_amount)} refunded</div>` : ''}</td>
        <td>${payBadge(p.payment_status)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No payments in this period.</p>'}</div>`;
  $('#pyForm').addEventListener('submit', (e) => { e.preventDefault(); location.hash = `payments?${new URLSearchParams(formData(e.target))}`; });
}

// ------------------------------------------------------------------ customers
const dueOf = (c) => Math.round((c.billed + (c.deposits || 0) - c.collected) * 100) / 100;

async function renderCustomers() {
  view().innerHTML = `<form class="toolbar" id="cuFilter"><div class="field"><label>Search</label><input name="q" placeholder="Name, phone, email or address" style="min-width:280px"></div><button class="btn ghost">Search</button></form><div id="cuList"></div>`;
  const load = async () => {
    const rows = await api(`/api/admin/customers?${new URLSearchParams(formData($('#cuFilter')))}`);
    $('#cuList').innerHTML = rows.length ? `<div class="table-wrap"><table><thead><tr><th>Customer</th><th>Contact</th><th>Address</th><th class="num">Bookings</th><th class="num">Cans</th>
      <th class="num">Billed</th><th class="num">Collected</th><th class="num">Due</th><th></th></tr></thead><tbody>
      ${rows.map((c) => `<tr><td><strong>${esc(c.name)}</strong><div class="small muted">since ${fmtDate(c.created_at)}</div></td>
        <td>${esc(c.phone)}<div class="small muted">${esc(c.email)}</div></td>
        <td class="small">${esc(c.address)}${c.line_no ? `<br><span class="muted">Line ${esc(c.line_no)}</span>` : ''}</td>
        <td class="num">${c.bookings}${c.active_bookings ? `<div class="small muted">${c.active_bookings} active</div>` : ''}</td>
        <td class="num">${c.cans_held || '—'}</td>
        <td class="num">${money(c.billed + c.deposits)}</td><td class="num">${money(c.collected)}</td>
        <td class="num" style="${dueOf(c) > 0 ? 'color:var(--red-600);font-weight:700' : ''}">${money(dueOf(c))}</td>
        <td class="right"><button class="btn sm ghost" data-customer="${c.id}">Open</button></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">No customers yet. They are saved automatically when someone books.</div>';
  };
  $('#cuFilter').addEventListener('submit', (e) => { e.preventDefault(); load(); });
  await load();
}

async function openCustomer(id) {
  const c = await api(`/api/admin/customers/${id}`);
  const from = `${todayStr().slice(0, 7)}-01`;
  openModal({
    title: c.name, wide: true,
    body: `<form id="cuForm" class="grid grid-2">
        <div class="field"><label>Name</label><input name="name" value="${esc(c.name)}"></div>
        <div class="field"><label>Contact number</label><input value="${esc(c.phone)}" disabled></div>
        <div class="field"><label>Email</label><input name="email" value="${esc(c.email)}"></div>
        <div class="field"><label>Line / Lane No.</label><input name="line_no" value="${esc(c.line_no)}"></div>
        <div class="field"><label>PIN code</label><input name="pincode" value="${esc(c.pincode)}"></div>
        <div class="field"><label>Referral code</label><input value="${esc(c.referral_code || '')}" disabled><div class="hint">${c.referred} friend${c.referred === 1 ? '' : 's'} referred</div></div>
        <div class="field" style="grid-column:1/-1"><label>Address</label><textarea name="address">${esc(c.address)}</textarea></div>
      </form>
      <div class="grid grid-4" style="margin:6px 0 16px">${statCard('Billed', money(c.billed))}${statCard('Deposits', money(c.deposits))}${statCard('Collected', money(c.collected))}${statCard('Due', money(dueOf(c)))}</div>
      <h3>🫙 Returnable cans</h3>
      ${c.containers.length ? `<div class="table-wrap"><table><thead><tr><th>Product</th><th class="num">With customer</th><th class="num">Deposits held</th><th></th></tr></thead><tbody>
        ${c.containers.map((x) => `<tr><td>${esc(x.name)}</td><td class="num">${x.held}</td><td class="num">${x.deposit_units} · ${money(x.deposit_units * x.deposit)}</td>
          <td class="right nowrap"><button class="btn sm ghost" data-can="return" data-pid="${x.product_id}" data-held="${x.held}" data-units="${x.deposit_units}" data-name="${esc(x.name)}" data-deposit="${x.deposit}">Return / refund</button>
          <button class="btn sm ghost" data-can="set" data-pid="${x.product_id}" data-held="${x.held}" data-units="${x.deposit_units}" data-name="${esc(x.name)}">Set balance</button></td></tr>`).join('')}
      </tbody></table></div>
      ${c.moves.length ? `<details style="margin-top:8px"><summary class="small muted">Can history</summary><div class="small" style="margin-top:6px">${c.moves.map((m) =>
        `${fmtDateTime(m.created_at)} — ${esc(m.name)}: ${m.delivered ? `+${m.delivered} delivered ` : ''}${m.collected ? `−${m.collected} collected ` : ''}${m.deposit_amount ? `deposit ${money(m.deposit_amount)} ` : ''}${m.note ? `(${esc(m.note)})` : ''}${m.by_name ? ` · ${esc(m.by_name)}` : ''}`).join('<br>')}</div></details>` : ''}`
        : '<p class="muted">No returnable products are set up. Mark products as returnable on the Products page.</p>'}
      <h3 style="margin-top:16px">Bookings</h3>${bookingTable(c.bookingList.map((b) => ({ ...b, name: c.name })), true)}`,
    foot: `<a class="btn ghost" href="/statement?customer_id=${c.id}&from=${from}&to=${todayStr()}" target="_blank">🧾 This month's statement</a>
      <button class="btn ghost" data-close>Close</button><button class="btn" id="cuSave">Save changes</button>`,
    onOpen: (el, close) => {
      $('#cuSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        await api(`/api/admin/customers/${c.id}`, { method: 'PUT', body: formData($('#cuForm', el)) });
        toast('Customer updated', 'success'); close(); route();
      }));
      el.addEventListener('click', (e) => {
        const b = e.target.closest('[data-can]');
        if (!b) return;
        canAction(c.id, b.dataset, () => { close(); openCustomer(c.id); });
      });
    },
  });
}

// Record cans returned (+ deposit refund) or correct a customer's can balance.
function canAction(customerId, ds, done) {
  const isSet = ds.can === 'set';
  openModal({
    title: `${isSet ? 'Set can balance' : 'Cans returned'} — ${ds.name}`,
    body: `<form id="canForm">${isSet
      ? `<p class="muted small">Use this to enter opening balances for existing customers or to correct a mistake.</p>
         <div class="grid grid-2"><div class="field"><label>Cans with customer</label><input type="number" min="0" step="1" name="held" value="${ds.held}"></div>
         <div class="field"><label>Deposits held</label><input type="number" min="0" step="1" name="deposit_units" value="${ds.units}"></div></div>`
      : `<div class="grid grid-2"><div class="field"><label>Cans returned</label><input type="number" min="0" max="${ds.held}" step="1" name="returned" value="${ds.held}"></div>
         <div class="field"><label>Deposits to refund</label><input type="number" min="0" max="${ds.units}" step="1" name="refund_units" value="${Math.min(ds.held, ds.units)}">
         <div class="hint">${money(ds.deposit)} each — refund this to the customer</div></div></div>
         <div class="field"><label>Note</label><input name="note" placeholder="e.g. Customer moved out"></div>`}</form>`,
    foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="canSave">Save</button>',
    onOpen: (el, close) => $('#canSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
      const f = formData($('#canForm', el));
      const r = await api(`/api/admin/customers/${customerId}/containers`, { body: { ...f, product_id: Number(ds.pid), mode: isSet ? 'set' : 'return' } });
      toast(r.refund ? `Saved — refund ${money(r.refund)} to the customer` : 'Saved', 'success');
      close(); done();
    })),
  });
}

// ------------------------------------------------------------------ cans & deposits
async function renderCans() {
  const r = await api('/api/admin/containers');
  view().innerHTML = `
    <div class="grid grid-3">${r.products.map((p) => statCard(esc(p.name), `${p.held} out`,
      `${p.deposit_units} deposits held (${money(p.deposit_units * p.deposit)}) · ${p.stock} in stock`)).join('') || '<p class="muted">No returnable products. Edit a product and tick “Returnable”.</p>'}</div>
    <div class="card" style="margin-top:16px"><h3>Customers holding cans</h3>
      ${r.customers.length ? `<div class="table-wrap"><table><thead><tr><th>Customer</th><th>Product</th><th class="num">Cans</th><th class="num">Deposits</th><th></th></tr></thead><tbody>
        ${r.customers.map((c) => `<tr><td><strong>${esc(c.name)}</strong><div class="small muted">${esc(c.phone)} · ${esc(c.address)}</div></td><td>${esc(c.product)}</td>
          <td class="num" style="${c.held > c.deposit_units ? 'color:var(--red-600);font-weight:700' : ''}">${c.held}</td>
          <td class="num">${c.deposit_units} · ${money(c.deposit_units * c.deposit)}</td>
          <td class="right"><button class="btn sm ghost" data-customer="${c.id}">Open</button></td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">No cans out with customers yet.</p>'}
      <p class="small muted" style="margin-top:8px">Cans are tracked automatically on every delivery (new cans add a refundable deposit; empties collected reduce the count). Red = more cans than deposits.</p>
    </div>`;
}

// ------------------------------------------------------------------ billing
async function renderBilling() {
  const customers = await api('/api/admin/customers');
  const t = todayStr();
  const from = `${t.slice(0, 7)}-01`;
  const dues = customers.filter((c) => dueOf(c) > 0.009).sort((a, b) => dueOf(b) - dueOf(a));
  view().innerHTML = `
    <div class="card"><h3>Generate customer bill / statement</h3>
      <form class="toolbar" id="stForm" style="margin:0">
        <div class="field"><label>Customer</label><select name="customer_id" required style="min-width:240px"><option value="">Choose…</option>
          ${customers.map((c) => `<option value="${c.id}">${esc(c.name)} — ${esc(c.phone)}</option>`).join('')}</select></div>
        <div class="field"><label>From</label><input type="date" name="from" value="${from}"></div>
        <div class="field"><label>To</label><input type="date" name="to" value="${t}"></div>
        <button class="btn">Open statement</button>
      </form>
      <p class="small muted" style="margin:10px 0 0">Every completed delivery automatically gets its own invoice (see Deliveries). Statements combine a customer's deliveries for a period — ideal for monthly subscriptions.</p>
    </div>
    <div class="card" style="margin-top:16px"><h3>Outstanding dues (e.g. extra can deposits, older cash bookings)</h3>
      ${dues.length ? `<div class="table-wrap"><table><thead><tr><th>Customer</th><th>Contact</th><th class="num">Billed</th><th class="num">Collected</th><th class="num">Due</th><th></th></tr></thead><tbody>
        ${dues.map((c) => `<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.phone)}</td><td class="num">${money(c.billed + c.deposits)}</td><td class="num">${money(c.collected)}</td>
          <td class="num" style="color:var(--red-600);font-weight:700">${money(dueOf(c))}</td>
          <td class="right"><a class="btn sm ghost" target="_blank" href="/statement?customer_id=${c.id}&from=2000-01-01&to=${t}">Full statement</a></td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">No outstanding dues — all delivered orders are fully paid. 🎉</p>'}
    </div>`;
  $('#stForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const f = formData(e.target);
    if (!f.customer_id) return toast('Choose a customer', 'error');
    window.open(`/statement?${new URLSearchParams(f)}`, '_blank');
  });
}

// ------------------------------------------------------------------ reports
async function renderReports() {
  const t = todayStr();
  view().innerHTML = `
    <form class="toolbar" id="rpForm">
      <div class="field"><label>From</label><input type="date" name="from" value="${t.slice(0, 7)}-01"></div>
      <div class="field"><label>To</label><input type="date" name="to" value="${t}"></div>
      <div class="chips">
        <button type="button" class="chip" data-range="today">Today</button>
        <button type="button" class="chip" data-range="7">Last 7 days</button>
        <button type="button" class="chip" data-range="month">This month</button>
        <button type="button" class="chip" data-range="year">This year</button>
      </div>
      <button class="btn">Run report</button>
      <button type="button" class="btn ghost" id="csvBtn">⬇ Export CSV</button>
      <button type="button" class="btn ghost" onclick="print()">🖨️ Print</button>
    </form>
    <div id="rpOut"><div class="empty">Loading…</div></div>`;
  const form = $('#rpForm');
  const load = async () => {
    const r = await api(`/api/admin/reports?${new URLSearchParams(formData(form))}`);
    const s = r.summary;
    const table = (head, rows) => rows.length ? `<div class="table-wrap"><table><thead><tr>${head.map((h) => `<th class="${h.startsWith('#') ? 'num' : ''}">${h.replace('#', '')}</th>`).join('')}</tr></thead>
      <tbody>${rows.join('')}</tbody></table></div>` : '<p class="muted">No data for this period.</p>';
    const maxRev = Math.max(1, ...r.byProduct.map((p) => p.revenue));
    $('#rpOut').innerHTML = `
      <p class="muted">${fmtDate(r.from)} – ${fmtDate(r.to)}</p>
      <div class="grid grid-4">
        ${statCard('Revenue (billed)', money(s.billed), `${s.delivered} deliveries completed`)}
        ${statCard('Paid online', money(r.payments.paid - r.payments.refunded), `${r.payments.n} payments · ${money(r.payments.refunded)} refunded`)}
        ${statCard('Deliveries', s.total, `${s.pending} pending · ${s.failed} failed · ${s.cancelled} cancelled`)}
        ${statCard('New bookings', r.newBookings, `${r.newCustomers} new customers`)}
        ${statCard('Can deposits taken', money(s.deposits), `${s.empties} empties collected`)}
        ${statCard('Discounts given', money(r.discounts), 'Coupons & referrals')}
        ${statCard('Customer rating', r.rating.n ? `★ ${r.rating.avg}` : '—', `${r.rating.n} ratings · <a href="#ratings">details</a>`)}
      </div>
      <div class="grid grid-2" style="margin-top:16px">
        <div class="card"><h3>Sales by product</h3>${table(['Product', '#Qty', '#Revenue', ''], r.byProduct.map((p) =>
          `<tr><td>${esc(p.name)}</td><td class="num">${p.quantity}</td><td class="num">${money(p.revenue)}</td><td style="width:30%"><div class="bar"><span style="width:${(p.revenue / maxRev) * 100}%"></span></div></td></tr>`))}</div>
        <div class="card"><h3>Delivery agent performance</h3>${table(['Agent', '#Assigned', '#Delivered', '#Failed', '#Rating'], r.byAgent.map((a) =>
          `<tr><td>${esc(a.name)}</td><td class="num">${a.total}</td><td class="num">${a.delivered}</td><td class="num">${a.failed}</td>
          <td class="num">${a.rating ? `★ ${a.rating}` : '—'}</td></tr>`))}</div>
        <div class="card"><h3>Sales by area (PIN code)</h3>${table(['PIN', 'Area', '#Delivered', '#Billed'], r.byArea.map((a) =>
          `<tr><td>${esc(a.pincode)}</td><td>${esc(a.area)}</td><td class="num">${a.delivered}</td><td class="num">${money(a.billed)}</td></tr>`))}</div>
        <div class="card"><h3>By booking frequency</h3>${table(['Frequency', '#Bookings', '#Delivered', '#Billed'], r.byFrequency.map((f) =>
          `<tr><td>${freqBadge(f.frequency)}</td><td class="num">${f.bookings}</td><td class="num">${f.delivered}</td><td class="num">${money(f.billed)}</td></tr>`))}</div>
        <div class="card"><h3>Daily breakdown</h3><div style="max-height:360px;overflow:auto">${table(['Date', '#Scheduled', '#Delivered', '#Delivered value'], r.daily.map((d) =>
          `<tr><td class="nowrap">${fmtDate(d.date)}</td><td class="num">${d.total}</td><td class="num">${d.delivered}</td><td class="num">${money(d.billed)}</td></tr>`))}</div></div>
      </div>`;
  };
  form.addEventListener('submit', (e) => { e.preventDefault(); load().catch((err) => toast(err.message, 'error')); });
  form.addEventListener('click', (e) => {
    const r = e.target.dataset.range;
    if (!r) return;
    const t2 = todayStr();
    form.to.value = t2;
    form.from.value = { today: t2, 7: todayStr(-6), month: `${t2.slice(0, 7)}-01`, year: `${t2.slice(0, 4)}-01-01` }[r];
    load();
  });
  $('#csvBtn').addEventListener('click', () => { location.href = `/api/admin/reports?${new URLSearchParams({ ...formData(form), format: 'csv' })}`; });
  await load();
}

// ------------------------------------------------------------------ ratings
async function renderRatings() {
  const t = todayStr();
  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  const from = params.get('from') || `${t.slice(0, 4)}-01-01`, to = params.get('to') || t;
  const r = await api(`/api/admin/ratings?from=${from}&to=${to}`);
  const stars = (n) => `<span style="color:#f5a623">${'★'.repeat(n)}</span><span style="color:#c9d3dc">${'★'.repeat(5 - n)}</span>`;
  view().innerHTML = `
    <form class="toolbar" id="rtForm"><div class="field"><label>From</label><input type="date" name="from" value="${from}"></div>
      <div class="field"><label>To</label><input type="date" name="to" value="${to}"></div><button class="btn ghost">Show</button></form>
    <div class="grid grid-3">${statCard('Average rating', r.summary.n ? `★ ${r.summary.avg}` : '—')}${statCard('Ratings received', r.summary.n)}${statCard('Low ratings (1–2★)', r.summary.low)}</div>
    <div class="grid grid-2" style="margin-top:16px">
      <div class="card"><h3>By delivery agent</h3>${r.byAgent.length ? r.byAgent.map((a) => `<div class="summary-row"><span>${esc(a.name)}</span><span>★ ${a.avg} <span class="small muted">(${a.n})</span></span></div>`).join('') : '<p class="muted">No ratings yet.</p>'}</div>
      <div class="card"><h3>Latest feedback</h3>${r.recent.length ? r.recent.map((x) => `<div style="padding:8px 0;border-bottom:1px solid var(--line)">
        <div class="row between">${stars(x.rating)}<span class="small muted">${fmtDate(x.scheduled_date)}</span></div>
        <div><strong>${esc(x.name)}</strong> <span class="small muted">${esc(x.booking_no)} · ${esc(x.agent_name || '')}</span></div>
        ${x.comment ? `<div class="small">“${esc(x.comment)}”</div>` : ''}</div>`).join('') : '<p class="muted">Customers can rate each delivery from their tracking page or account.</p>'}</div>
    </div>`;
  $('#rtForm').addEventListener('submit', (e) => { e.preventDefault(); location.hash = `ratings?${new URLSearchParams(formData(e.target))}`; });
}

// ------------------------------------------------------------------ coupons & referrals
async function renderCoupons() {
  const [rows, s] = await Promise.all([api('/api/admin/coupons'), api('/api/settings')]);
  setActions('<button class="btn green" data-coupon="new">+ New coupon</button>');
  const general = rows.filter((c) => !c.customer_id);
  const rewards = rows.filter((c) => c.customer_id);
  const desc = (c) => `${c.type === 'percent' ? `${c.value}%` : money(c.value)} off ${c.scope === 'all' ? 'every delivery' : 'first delivery'}${c.min_order ? ` · min ${money(c.min_order)}` : ''}${c.max_discount ? ` · max ${money(c.max_discount)}` : ''}`;
  view().innerHTML = `
    <div class="card" style="margin-bottom:16px"><h3>Referral programme</h3>
      <p>Every customer gets a personal referral code (see their profile or <em>My account</em>). A new customer using it gets <strong>${money(s.referral_discount)}</strong> off their first delivery;
      the referrer gets a <strong>${money(s.referral_reward)}</strong> coupon after that first delivery. <a href="#settings">Change amounts</a></p></div>
    <h3>Coupons</h3>
    ${general.length ? `<div class="table-wrap"><table><thead><tr><th>Code</th><th>Offer</th><th>Valid</th><th class="num">Used</th><th class="num">Discount given</th><th>Status</th><th></th></tr></thead><tbody>
      ${general.map((c) => `<tr><td><strong>${esc(c.code)}</strong>${c.description ? `<div class="small muted">${esc(c.description)}</div>` : ''}</td><td class="small">${desc(c)}</td>
        <td class="small nowrap">${c.valid_from ? fmtDate(c.valid_from) : 'Any time'} → ${c.valid_to ? fmtDate(c.valid_to) : 'no end'}</td>
        <td class="num">${c.uses}${c.usage_limit ? ` / ${c.usage_limit}` : ''}</td><td class="num">${money(c.discount_given)}</td>
        <td>${badge(c.active ? 'active' : 'inactive')}</td><td class="right"><button class="btn sm ghost" data-coupon="${c.id}">Edit</button></td></tr>`).join('')}
    </tbody></table></div>` : '<div class="card empty">No coupons yet. Create one like WELCOME10 for 10% off.</div>'}
    <h3 style="margin-top:20px">Referral rewards issued</h3>
    ${rewards.length ? `<div class="table-wrap"><table><thead><tr><th>Code</th><th>Customer</th><th>Offer</th><th>Status</th></tr></thead><tbody>
      ${rewards.map((c) => `<tr><td>${esc(c.code)}</td><td>${esc(c.customer_name)}</td><td class="small">${desc(c)}</td><td>${c.uses ? '<span class="badge b-delivered">Used</span>' : '<span class="badge b-pending">Not used yet</span>'}</td></tr>`).join('')}
    </tbody></table></div>` : '<p class="muted">No referral rewards yet.</p>'}`;
  view()._coupons = general;
}

function editCoupon(id) {
  const c = id === 'new' ? { type: 'percent', scope: 'first', active: 1, per_customer_limit: 1, usage_limit: 0, min_order: 0, max_discount: 0 } : view()._coupons.find((x) => x.id === Number(id));
  openModal({
    title: id === 'new' ? 'New coupon' : `Edit ${c.code}`,
    body: `<form id="cpForm"><div class="grid grid-2">
      <div class="field"><label class="req">Code</label><input name="code" value="${esc(c.code)}" style="text-transform:uppercase" placeholder="e.g. WELCOME10"></div>
      <div class="field"><label>Description (shown to customer)</label><input name="description" value="${esc(c.description)}"></div>
      <div class="field"><label class="req">Type</label><select name="type"><option value="percent" ${c.type === 'percent' ? 'selected' : ''}>Percent off</option><option value="flat" ${c.type === 'flat' ? 'selected' : ''}>Flat amount off</option></select></div>
      <div class="field"><label class="req">Value</label><input type="number" step="0.01" min="0" name="value" value="${c.value ?? ''}"></div>
      <div class="field"><label>Applies to</label><select name="scope"><option value="first" ${c.scope === 'first' ? 'selected' : ''}>First delivery only</option><option value="all" ${c.scope === 'all' ? 'selected' : ''}>Every delivery of the booking</option></select></div>
      <div class="field"><label>Minimum order (per delivery)</label><input type="number" step="0.01" min="0" name="min_order" value="${c.min_order}"></div>
      <div class="field"><label>Maximum discount (0 = no cap)</label><input type="number" step="0.01" min="0" name="max_discount" value="${c.max_discount}"></div>
      <div class="field"><label>Total uses (0 = unlimited)</label><input type="number" step="1" min="0" name="usage_limit" value="${c.usage_limit}"></div>
      <div class="field"><label>Uses per customer (0 = unlimited)</label><input type="number" step="1" min="0" name="per_customer_limit" value="${c.per_customer_limit}"></div>
      <div class="field"><label>Valid from</label><input type="date" name="valid_from" value="${esc(c.valid_from || '')}"></div>
      <div class="field"><label>Valid until</label><input type="date" name="valid_to" value="${esc(c.valid_to || '')}"></div>
    </div><label class="row" style="font-weight:500"><input type="checkbox" name="active" ${c.active ? 'checked' : ''} style="width:auto"> Active</label></form>`,
    foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="cpSave">Save</button>',
    onOpen: (el, close) => $('#cpSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
      const f = formData($('#cpForm', el));
      await api('/api/admin/coupons', { body: { ...f, id: id === 'new' ? undefined : Number(id), active: f.active === 'on' } });
      toast('Coupon saved', 'success'); close(); route();
    })),
  });
}

// ------------------------------------------------------------------ areas & slots
async function renderAreas() {
  const date = todayStr(1);
  const [areas, slots, s] = await Promise.all([api('/api/admin/areas'), api(`/api/admin/slots?date=${date}`), api('/api/settings')]);
  const active = areas.filter((a) => a.active);
  view().innerHTML = `<div class="grid grid-2">
    <div class="card"><div class="row between"><h3 style="margin:0">Delivery areas (PIN codes)</h3><button class="btn sm green" data-area="new">+ Add PIN code</button></div>
      <p class="small muted" style="margin:8px 0">${active.length ? `Customers can only book for these ${active.length} PIN code${active.length > 1 ? 's' : ''}.`
        : `No areas added — <strong>all PIN codes</strong> are accepted with the default charge (${money(s.default_delivery_charge)}) and minimum order (${money(s.default_min_order)}) from <a href="#settings">Settings</a>.`}</p>
      ${areas.length ? `<div class="table-wrap"><table><thead><tr><th>PIN</th><th>Area</th><th class="num">Delivery charge</th><th class="num">Min. order</th><th>Status</th><th></th></tr></thead><tbody>
        ${areas.map((a) => `<tr><td><strong>${esc(a.pincode)}</strong></td><td>${esc(a.name)}</td><td class="num">${a.delivery_charge ? money(a.delivery_charge) : 'Free'}</td>
          <td class="num">${a.min_order ? money(a.min_order) : '—'}</td><td>${badge(a.active ? 'active' : 'inactive')}</td>
          <td class="right nowrap"><button class="btn sm ghost" data-area="${a.id}">Edit</button> <button class="btn sm ghost" data-area-del="${a.id}">✕</button></td></tr>`).join('')}
      </tbody></table></div>` : ''}
    </div>
    <div class="card"><div class="row between"><h3 style="margin:0">Delivery time slots</h3><button class="btn sm green" data-slot="new">+ Add slot</button></div>
      <p class="small muted" style="margin:8px 0">Customers pick a slot when booking. Capacity = maximum deliveries per slot per day. Same-day bookings close
        ${esc(s.same_day_cutoff_minutes || 60)} minutes before the slot starts (change in Settings).</p>
      <div class="table-wrap"><table><thead><tr><th>Slot</th><th>Time</th><th class="num">Capacity</th><th class="num">Booked ${fmtDate(date)}</th><th>Status</th><th></th></tr></thead><tbody>
        ${slots.map((x) => `<tr><td>${esc(x.label)}</td><td class="nowrap">${fmtTime(x.start_time)}–${fmtTime(x.end_time)}</td><td class="num">${x.capacity}</td>
          <td class="num"><div class="bar" title="${x.booked}/${x.capacity}"><span style="width:${Math.min(100, (x.booked / x.capacity) * 100)}%"></span></div>${x.booked}</td>
          <td>${badge(x.active ? 'active' : 'inactive')}</td><td class="right"><button class="btn sm ghost" data-slot="${x.id}">Edit</button></td></tr>`).join('')}
      </tbody></table></div>
    </div></div>`;
  view().onclick = async (e) => {
    const a = e.target.closest('[data-area],[data-area-del],[data-slot]');
    if (!a) return;
    if (a.dataset.areaDel) {
      if (!confirm('Remove this PIN code?')) return;
      await api(`/api/admin/areas/${a.dataset.areaDel}`, { method: 'DELETE' }).catch((err) => toast(err.message, 'error'));
      return route();
    }
    if (a.dataset.area) {
      const x = a.dataset.area === 'new' ? { active: 1, delivery_charge: 0, min_order: 0 } : areas.find((y) => y.id === Number(a.dataset.area));
      return openModal({
        title: a.dataset.area === 'new' ? 'Add delivery area' : `Edit ${x.pincode}`,
        body: `<form id="arForm"><div class="grid grid-2">
          <div class="field"><label class="req">PIN code</label><input name="pincode" value="${esc(x.pincode)}" inputmode="numeric"></div>
          <div class="field"><label>Area name</label><input name="name" value="${esc(x.name)}" placeholder="e.g. Salt Lake Sector V"></div>
          <div class="field"><label>Delivery charge</label><input type="number" step="0.01" min="0" name="delivery_charge" value="${x.delivery_charge}"></div>
          <div class="field"><label>Minimum order (per delivery)</label><input type="number" step="0.01" min="0" name="min_order" value="${x.min_order}"></div></div>
          <label class="row" style="font-weight:500"><input type="checkbox" name="active" ${x.active ? 'checked' : ''} style="width:auto"> We deliver here</label></form>`,
        foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="arSave">Save</button>',
        onOpen: (el, close) => $('#arSave', el).addEventListener('click', (ev) => withBusy(ev.currentTarget, async () => {
          const f = formData($('#arForm', el));
          await api('/api/admin/areas', { body: { ...f, id: x.id, active: f.active === 'on' } });
          toast('Saved', 'success'); close(); route();
        })),
      });
    }
    const x = a.dataset.slot === 'new' ? { active: 1, capacity: 25, sort: slots.length } : slots.find((y) => y.id === Number(a.dataset.slot));
    openModal({
      title: a.dataset.slot === 'new' ? 'Add time slot' : `Edit ${x.label}`,
      body: `<form id="slForm"><div class="grid grid-2">
        <div class="field"><label class="req">Name</label><input name="label" value="${esc(x.label)}" placeholder="e.g. Morning"></div>
        <div class="field"><label class="req">Capacity per day</label><input type="number" min="1" step="1" name="capacity" value="${x.capacity}"></div>
        <div class="field"><label class="req">Starts</label><input type="time" name="start_time" value="${esc(x.start_time || '08:00')}"></div>
        <div class="field"><label class="req">Ends</label><input type="time" name="end_time" value="${esc(x.end_time || '10:00')}"></div>
        <div class="field"><label>Display order</label><input type="number" name="sort" value="${x.sort}"></div></div>
        <label class="row" style="font-weight:500"><input type="checkbox" name="active" ${x.active ? 'checked' : ''} style="width:auto"> Available for booking</label></form>`,
      foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="slSave">Save</button>',
      onOpen: (el, close) => $('#slSave', el).addEventListener('click', (ev) => withBusy(ev.currentTarget, async () => {
        const f = formData($('#slForm', el));
        await api('/api/admin/slots', { body: { ...f, id: x.id, active: f.active === 'on' } });
        toast('Saved', 'success'); close(); route();
      })),
    });
  };
}

// ------------------------------------------------------------------ products
const TYPES = { can: 'Water can', bottle: 'Bottle', box: 'Box', jar: 'Jar', leafy: 'Leafy greens', herb: 'Herb', tomato: 'Tomato / fruit', microgreens: 'Microgreens' };
async function renderProducts() {
  const rows = await api('/api/admin/products');
  setActions('<button class="btn green" data-product="new">+ Add product</button>');
  view().innerHTML = `<div class="table-wrap"><table><thead><tr><th></th><th>Product</th><th>Category</th><th>Unit</th><th class="num">Price</th><th class="num">Stock</th><th>Status</th><th></th></tr></thead><tbody>
    ${rows.map((p) => `<tr><td style="width:56px"><div style="width:44px;height:44px">${productArt(p.type)}</div></td>
      <td><strong>${esc(p.name)}</strong><div class="small muted">${esc(p.description)}</div></td>
      <td><span class="badge b-${p.category}">${p.category}</span><div class="small muted">${TYPES[p.type] || p.type}</div></td>
      <td>${esc(p.unit)}${p.returnable ? `<div class="small muted">🫙 returnable · deposit ${money(p.deposit)}</div>` : ''}</td><td class="num">${money(p.price)}</td>
      <td class="num" style="${p.stock <= 10 ? 'color:var(--red-600);font-weight:700' : ''}">${p.stock}</td>
      <td>${badge(p.active ? 'active' : 'inactive')}</td>
      <td class="right"><button class="btn sm ghost" data-product="${p.id}">Edit</button></td></tr>`).join('')}
  </tbody></table></div>`;
  view()._products = rows;
}

function editProduct(id) {
  const p = id === 'new' ? { category: 'water', type: 'can', active: 1, stock: 0, sort: 0 } : view()._products.find((x) => x.id === Number(id));
  openModal({
    title: id === 'new' ? 'Add product' : `Edit ${p.name}`,
    body: `<form id="pForm">
      <div class="field"><label class="req">Name</label><input name="name" value="${esc(p.name)}"></div>
      <div class="grid grid-2">
        <div class="field"><label class="req">Category</label><select name="category"><option value="water" selected>Water</option></select></div>
        <div class="field"><label class="req">Type (picture)</label><select name="type">${Object.entries(TYPES).map(([k, v]) => `<option value="${k}" ${p.type === k ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
        <div class="field"><label>Unit / pack size</label><input name="unit" value="${esc(p.unit)}" placeholder="e.g. 20 litre can, 250 g"></div>
        <div class="field"><label class="req">Price</label><input name="price" type="number" step="0.01" min="0" value="${p.price ?? ''}"></div>
        <div class="field"><label>Stock</label><input name="stock" type="number" min="0" step="1" value="${p.stock}"></div>
        <div class="field"><label>Display order</label><input name="sort" type="number" value="${p.sort}"></div>
        <div class="field"><label class="row" style="font-weight:600;margin-top:28px"><input type="checkbox" name="returnable" ${p.returnable ? 'checked' : ''} style="width:auto"> Returnable can / jar (track empties)</label></div>
        <div class="field"><label>Refundable deposit per can</label><input name="deposit" type="number" step="0.01" min="0" value="${p.deposit || 0}"></div>
      </div>
      <div class="field"><label>Description</label><textarea name="description">${esc(p.description)}</textarea></div>
      <label class="row" style="font-weight:500"><input type="checkbox" name="active" ${p.active ? 'checked' : ''} style="width:auto"> Show in shop</label>
    </form>`,
    foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="pSave">Save</button>',
    onOpen: (el, close) => $('#pSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
      const f = formData($('#pForm', el));
      const body = { ...f, price: Number(f.price), stock: Number(f.stock), sort: Number(f.sort), active: f.active === 'on',
        returnable: f.returnable === 'on', deposit: Number(f.deposit || 0) };
      await api(id === 'new' ? '/api/admin/products' : `/api/admin/products/${id}`, { method: id === 'new' ? 'POST' : 'PUT', body });
      toast('Product saved', 'success'); close(); route();
    })),
  });
}

// ------------------------------------------------------------------ staff
async function renderStaff() {
  await loadAgents();
  setActions('<button class="btn green" data-user="new">+ Add delivery agent / admin</button>');
  view().innerHTML = `<div class="table-wrap"><table><thead><tr><th>Name</th><th>Role</th><th>Login email</th><th>Phone</th><th>Today</th><th>Status</th><th></th></tr></thead><tbody>
    ${AGENTS.map((u) => `<tr><td><strong>${esc(u.name)}</strong>${u.id === ME.id ? ' <span class="small muted">(you)</span>' : ''}</td>
      <td>${u.role === 'admin' ? 'Admin' : 'Delivery agent'}</td><td>${esc(u.email)}</td><td>${esc(u.phone)}</td>
      <td>${u.role === 'agent' ? `${u.today_delivered}/${u.today_total} delivered` : '—'}</td>
      <td>${badge(u.active ? 'active' : 'inactive')}
        <div class="small muted">${u.push_devices ? `📲 alerts on ${u.push_devices} device${u.push_devices > 1 ? 's' : ''}` : '📲 alerts off'}${u.rating ? ` · ★ ${u.rating}` : ''}</div>
        ${u.must_change_password ? '<div class="small" style="color:var(--amber-600)">Must set own password</div>' : ''}</td>
      <td class="right"><button class="btn sm ghost" data-user="${u.id}">Edit</button></td></tr>`).join('')}
  </tbody></table></div>
  <p class="small muted" style="margin-top:10px">Delivery agents log in at <a href="/login?role=agent" target="_blank">/login?role=agent</a> on their phone, tap
  <strong>Install app</strong> to add it to the home screen, then turn on alerts in the 🔔 bell so they're notified of new tasks even when the app is closed.</p>`;
}

function editUser(id) {
  const u = id === 'new' ? { role: 'agent', active: 1 } : AGENTS.find((x) => x.id === Number(id));
  openModal({
    title: id === 'new' ? 'Add staff member' : `Edit ${u.name}`,
    body: `<form id="uForm">
      <div class="grid grid-2">
        <div class="field"><label class="req">Name</label><input name="name" value="${esc(u.name)}"></div>
        <div class="field"><label class="req">Role</label><select name="role"><option value="agent" ${u.role === 'agent' ? 'selected' : ''}>Delivery agent</option><option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option></select></div>
        <div class="field"><label class="req">Login email</label><input name="email" type="email" value="${esc(u.email)}"></div>
        <div class="field"><label>Phone</label><input name="phone" value="${esc(u.phone)}"></div>
      </div>
      <div class="field"><label class="${id === 'new' ? 'req' : ''}">${id === 'new' ? 'Temporary password' : 'Reset password'}</label><input name="password" type="password" autocomplete="new-password" placeholder="${id === 'new' ? 'At least 8 characters' : 'Leave blank to keep current password'}">
        <div class="hint">They will be asked to choose their own password the first time they log in.</div></div>
      <label class="row" style="font-weight:500"><input type="checkbox" name="active" ${u.active ? 'checked' : ''} style="width:auto"> Active (can log in)</label>
    </form>`,
    foot: '<button class="btn ghost" data-close>Cancel</button><button class="btn" id="uSave">Save</button>',
    onOpen: (el, close) => $('#uSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
      const f = formData($('#uForm', el));
      await api(id === 'new' ? '/api/admin/users' : `/api/admin/users/${id}`, { method: id === 'new' ? 'POST' : 'PUT', body: { ...f, active: f.active === 'on' } });
      toast('Saved', 'success'); close(); await loadAgents(); route();
    })),
  });
}

// ------------------------------------------------------------------ settings
async function renderSettings() {
  const s = await api('/api/settings');
  const field = (k, label, hint = '') => `<div class="field"><label>${label}</label><input name="${k}" value="${esc(s[k])}">${hint ? `<div class="hint">${hint}</div>` : ''}</div>`;
  view().innerHTML = `<div class="grid grid-2">
    <form class="card" id="setForm"><h3>Business details</h3>
      ${field('business_name', 'Business name')}${field('tagline', 'Tagline')}${field('phone', 'Phone')}${field('email', 'Email')}
      ${field('address', 'Address')}${field('currency', 'Currency symbol')}${field('tax_id', 'Tax / GST number', 'Shown on invoices if set')}
      ${field('invoice_note', 'Invoice footer note')}
      <h3 style="margin-top:18px">Delivery &amp; referrals</h3>
      <div class="grid grid-2">
        ${field('default_delivery_charge', 'Default delivery charge', 'Used when no delivery areas are set')}
        ${field('default_min_order', 'Default minimum order', 'Per delivery; 0 = none')}
        ${field('same_day_cutoff_minutes', 'Same-day booking cut-off (minutes)', 'How long before a slot starts bookings close')}
        ${field('referral_discount', 'Referral: new customer discount', 'Off their first delivery')}
        ${field('referral_reward', 'Referral: reward coupon for referrer', 'After the friend’s first delivery')}
      </div>
      <button class="btn">Save settings</button></form>
    <form class="card" id="pwForm" style="align-self:start"><h3>Change my password</h3>
      <div class="field"><label>Current password</label><input type="password" name="current" autocomplete="current-password"></div>
      <div class="field"><label>New password</label><input type="password" name="next" autocomplete="new-password"></div>
      <button class="btn">Update password</button>
      <p class="small muted" style="margin-top:10px">Logged in as ${esc(ME.email)} · at least 8 characters</p>
      <h3 style="margin-top:22px">💾 Backups</h3>
      <p class="small muted">A copy of the database is saved automatically every day (last 14 kept). Download one now to keep it somewhere safe (e.g. Google Drive).</p>
      <a class="btn ghost" href="/api/admin/backup/download">⬇ Download backup now</a>
      <div id="backupList" class="small muted" style="margin-top:10px"></div></form></div>`;
  api('/api/admin/backups').then((b) => {
    $('#backupList').innerHTML = b.files.length
      ? `Automatic backups in <code>${esc(b.dir)}</code>:<br>${b.files.slice(0, 5).map((f) => `${esc(f.file)} (${Math.round(f.size / 1024)} KB)`).join('<br>')}`
      : 'The first automatic backup is made a few seconds after the server starts.';
  }).catch(() => {});
  $('#setForm').addEventListener('submit', (e) => {
    e.preventDefault();
    withBusy(e.submitter, async () => { await api('/api/admin/settings', { method: 'PUT', body: formData(e.target) }); await loadSettings(); toast('Settings saved', 'success'); });
  });
  $('#pwForm').addEventListener('submit', (e) => {
    e.preventDefault();
    withBusy(e.submitter, async () => { await api('/api/auth/password', { body: formData(e.target) }); e.target.reset(); toast('Password updated', 'success'); });
  });
}

// ------------------------------------------------------------------ boot
(async function init() {
  try { ME = (await api('/api/auth/me')).user; } catch { return location.replace('/login?role=admin'); }
  if (ME.role !== 'admin') return location.replace('/agent');
  if (ME.must_change_password) return requirePasswordChange(() => location.reload());
  await loadSettings();
  $('#brand').innerHTML = `${BRAND_SVG}<span>${esc(SETTINGS.business_name)}</span>`;
  await loadAgents();

  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-booking],[data-new-booking],[data-customer],[data-product],[data-user],[data-coupon]');
    if (!t) return;
    const run = (fn) => Promise.resolve(fn()).catch((err) => toast(err.message, 'error'));
    if (t.dataset.booking) run(() => openBooking(t.dataset.booking));
    else if (t.hasAttribute('data-new-booking')) run(newBooking);
    else if (t.dataset.customer) run(() => openCustomer(t.dataset.customer));
    else if (t.dataset.product) editProduct(t.dataset.product);
    else if (t.dataset.user) editUser(t.dataset.user);
    else if (t.dataset.coupon) editCoupon(t.dataset.coupon);
  });
  $('#menuBtn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  $('#logout').addEventListener('click', async (e) => {
    e.preventDefault();
    await Push.disable().catch(() => {});
    await api('/api/auth/logout', { body: {} });
    location.replace('/login?role=admin');
  });
  addEventListener('hashchange', route);
  initNotifications($('#notifMount'), {
    onNew: () => {
      refreshPendingCount();
      const current = location.hash.slice(1).split('?')[0] || 'dashboard';
      if (['dashboard', 'bookings', 'deliveries'].includes(current) && !$('.overlay')) route();
    },
  });
  refreshPendingCount();
  setInterval(refreshPendingCount, 60000);
  await route();
})();
