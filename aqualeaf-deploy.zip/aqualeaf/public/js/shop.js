// Storefront: product grid and cart. Checkout continues on the booking page (/book).
let products = [];
let filter = 'all';
let cart = store.get(CART_KEY, {});

const cartLines = () => Object.entries(cart)
  .map(([id, qty]) => ({ product: products.find((p) => p.id === Number(id)), qty }))
  .filter((l) => l.product && l.qty > 0);
const cartTotal = () => cartLines().reduce((s, l) => s + l.product.price * l.qty, 0);

function setQty(id, qty) {
  qty = Math.max(0, Math.min(999, Math.round(Number(qty) || 0)));
  if (qty) cart[id] = qty; else delete cart[id];
  store.set(CART_KEY, cart);
  renderProducts();
  renderCart();
}

function renderProducts() {
  const list = products.filter((p) => filter === 'all' || p.category === filter);
  $('#products').innerHTML = list.length ? list.map((p) => {
    const qty = cart[p.id] || 0;
    return `<article class="product">
      <div class="product-art ${p.category}">${productArt(p.type)}</div>
      <div class="product-info">
        <div class="small muted">${esc(p.unit)}${p.returnable && p.deposit ? ` · +${money(p.deposit)} refundable can deposit` : ''}</div>
        <h3>${esc(p.name)}</h3>
        <div class="desc">${esc(p.description)}</div>
        <div class="row between" style="margin-top:6px">
          <div class="price">${money(p.price)}</div>
          ${qty ? `<div class="stepper"><button data-dec="${p.id}" aria-label="Decrease">−</button><input value="${qty}" data-qty="${p.id}" inputmode="numeric" aria-label="Quantity"><button data-inc="${p.id}" aria-label="Increase">+</button></div>`
            : `<button class="btn sm" data-add="${p.id}">Add to cart</button>`}
        </div>
      </div></article>`;
  }).join('') : '<div class="empty">No products in this category yet.</div>';
}

function renderCart() {
  const lines = cartLines();
  const count = lines.reduce((s, l) => s + l.qty, 0);
  $('#cartCount').textContent = count;
  $('#cartCount').classList.toggle('hidden', !count);
  $('#cartBody').innerHTML = lines.length ? lines.map(({ product: p, qty }) => `
    <div class="cart-line">${productArt(p.type)}
      <div><strong>${esc(p.name)}</strong><div class="small muted">${money(p.price)} × ${qty}</div>
        <div class="stepper" style="margin-top:6px"><button data-dec="${p.id}">−</button><input value="${qty}" data-qty="${p.id}" inputmode="numeric"><button data-inc="${p.id}">+</button></div></div>
      <div class="right"><strong>${money(p.price * qty)}</strong><br><button class="btn ghost sm" data-remove="${p.id}" style="margin-top:6px">Remove</button></div>
    </div>`).join('') : '<div class="empty">Your cart is empty.<br>Add some products to book a delivery.</div>';
  $('#cartTotal').textContent = money(cartTotal());
  $('#checkoutBtn').disabled = !lines.length;
}

(async function init() {
  await loadSettings();
  $('#header').innerHTML = headerHtml('shop');
  $('#footer').innerHTML = footerHtml();
  await loadSettings();
  $('#headerExtra').innerHTML = '<button class="btn sm cart-btn" id="openCart">🛒 Cart<span class="cart-count hidden" id="cartCount">0</span></button>';

  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-add],[data-inc],[data-dec],[data-remove],[data-filter],#openCart,#closeCart,#checkoutBtn');
    if (!t) return;
    if (t.dataset.add) { setQty(t.dataset.add, 1); toast('Added to cart', 'success'); }
    else if (t.dataset.inc) setQty(t.dataset.inc, (cart[t.dataset.inc] || 0) + 1);
    else if (t.dataset.dec) setQty(t.dataset.dec, (cart[t.dataset.dec] || 0) - 1);
    else if (t.dataset.remove) setQty(t.dataset.remove, 0);
    else if (t.dataset.filter) {
      filter = t.dataset.filter;
      $$('#filters .chip').forEach((c) => c.classList.toggle('active', c === t));
      renderProducts();
    } else if (t.id === 'openCart') $('#cart').classList.add('open');
    else if (t.id === 'closeCart') $('#cart').classList.remove('open');
    else if (t.id === 'checkoutBtn') location.href = '/book';
  });
  document.addEventListener('change', (e) => { if (e.target.dataset.qty) setQty(e.target.dataset.qty, e.target.value); });

  try {
    products = await api('/api/products');
  } catch (e) {
    $('#products').innerHTML = `<div class="empty">Could not load products: ${esc(e.message)}</div>`;
    return;
  }
  renderProducts();
  renderCart();
})();
