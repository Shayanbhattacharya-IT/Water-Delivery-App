// Customer account: OTP login, bookings (pause / skip / resume / cancel), bills, cans, referral, profile.
const main = () => $('#main');

// ---------------------------------------------------------------- login
function renderLogin(prefillPhone = '') {
  main().innerHTML = `<div class="card" style="max-width:440px;margin:0 auto">
    <h1 style="font-size:1.5rem">My account</h1>
    <p class="muted">Log in with the mobile number you used to book. We'll send you a 6-digit code.</p>
    <form id="phoneForm" novalidate>
      <div class="field"><label for="a-phone">Mobile number</label><input id="a-phone" name="phone" inputmode="tel" autocomplete="tel" required value="${esc(prefillPhone)}" placeholder="10-digit mobile"></div>
      <button class="btn block" id="sendBtn">Send login code</button>
    </form>
    <form id="codeForm" class="hidden" novalidate style="margin-top:14px">
      <div class="alert hidden" id="devNote" style="margin-bottom:12px"></div>
      <div class="field"><label for="a-code">Enter the 6-digit code</label><input id="a-code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" required style="font-size:1.4rem;letter-spacing:.4em;text-align:center"></div>
      <button class="btn green block" id="verifyBtn">Log in</button>
      <button type="button" class="btn ghost block" id="resendBtn" style="margin-top:8px">Send a new code</button>
    </form>
    <div class="alert error hidden" id="loginErr" style="margin-top:12px"></div>
    <p class="small muted" style="margin-top:16px">New here? <a href="/book">Book your first delivery</a> — your account is created automatically.</p>
  </div>`;
  const err = (m) => { $('#loginErr').textContent = m; $('#loginErr').classList.toggle('hidden', !m); };
  const send = (btn) => withBusy(btn, async () => {
    err('');
    try {
      const r = await api('/api/customer/otp', { body: { phone: $('#a-phone').value } });
      $('#codeForm').classList.remove('hidden');
      $('#a-code').focus();
      if (r.dev_code) {
        $('#devNote').innerHTML = `<strong>Test mode:</strong> WhatsApp isn't connected yet, so your code is <strong>${esc(r.dev_code)}</strong>. (Customers will receive it on WhatsApp once it's connected.)`;
        $('#devNote').classList.remove('hidden');
      } else toast(r.channel === 'whatsapp' ? 'Code sent on WhatsApp' : 'Code sent by SMS', 'success');
    } catch (e) { err(e.message); }
  });
  $('#phoneForm').addEventListener('submit', (e) => { e.preventDefault(); send($('#sendBtn')); });
  $('#resendBtn').addEventListener('click', (e) => send(e.currentTarget));
  $('#codeForm').addEventListener('submit', (e) => {
    e.preventDefault();
    withBusy($('#verifyBtn'), async () => {
      err('');
      try { await api('/api/customer/verify', { body: { phone: $('#a-phone').value, code: $('#a-code').value } }); load(); }
      catch (ex) { err(ex.message); }
    });
  });
}

// ---------------------------------------------------------------- dashboard
async function load() {
  let d;
  try { d = await api('/api/customer/me'); } catch (e) {
    if (e.status === 401) return renderLogin(store.get(CUSTOMER_KEY, {})?.phone || '');
    main().innerHTML = `<div class="alert error">${esc(e.message)}</div>`;
    return;
  }
  const c = d.customer;
  const shareUrl = `${location.origin}/book?code=${encodeURIComponent(c.referral_code)}`;
  const shareText = `I get my drinking water & fresh greens from ${SETTINGS.business_name}. Use my code ${c.referral_code} for ${money(d.referral.discount)} off your first delivery: ${shareUrl}`;
  const active = d.bookings.filter((b) => ['pending', 'confirmed'].includes(b.status));
  const past = d.bookings.filter((b) => !['pending', 'confirmed'].includes(b.status));
  const cans = d.containers.reduce((s, x) => s + x.held, 0);

  main().innerHTML = `
    <div class="row between" style="margin-bottom:16px"><div><h1 style="margin:0">Hi, ${esc(c.name.split(' ')[0])} 👋</h1>
      <div class="muted small">${esc(c.phone)} · ${esc(c.email)}</div></div>
      <div class="row"><a class="btn green" href="/book">+ New booking</a><button class="btn ghost" id="logoutBtn">Log out</button></div></div>

    <div class="grid grid-4">
      <div class="card stat"><span class="label">Total paid</span><span class="value">${money(d.bookings.reduce((s, b) => s + (b.paid_amount || 0) - (b.refunded_amount || 0), 0))}</span>
        <span class="sub">${d.bookings.some((b) => b.payment_status === 'unpaid' && b.status === 'pending') ? '⚠️ A booking is awaiting payment' : 'Paid online via Razorpay'}</span></div>
      <div class="card stat"><span class="label">Active bookings</span><span class="value">${active.length}</span></div>
      <div class="card stat"><span class="label">Cans with you</span><span class="value">${cans}</span>
        <span class="sub">${d.containers.map((x) => `${esc(x.name)}: ${x.held}`).join(' · ') || 'None'}</span></div>
      <div class="card stat"><span class="label">Friends referred</span><span class="value">${d.referrals}</span><span class="sub">${d.coupons.length} reward${d.coupons.length === 1 ? '' : 's'} to use</span></div>
    </div>

    <h2 style="margin-top:24px">My bookings</h2>
    ${active.length ? `<div class="stack">${active.map(bookingCard).join('')}</div>` : '<div class="card empty">No active bookings. <a href="/book">Book a delivery</a></div>'}
    ${past.length ? `<details style="margin-top:12px"><summary class="muted">Past bookings (${past.length})</summary><div class="stack" style="margin-top:10px">${past.map(bookingCard).join('')}</div></details>` : ''}

    <div class="grid grid-2" style="margin-top:24px">
      <div class="card"><div class="row between"><h3 style="margin:0">Bills</h3>
        <a class="btn ghost sm" target="_blank" href="/statement?mine=1&from=${todayStr().slice(0, 7)}-01&to=${todayStr()}">This month's statement</a></div>
        ${d.bills.length ? `<div class="table-wrap" style="margin-top:10px;max-height:360px;overflow:auto"><table><thead><tr><th>Date</th><th>Bill</th><th class="num">Amount</th><th></th></tr></thead><tbody>
          ${d.bills.map((b) => `<tr><td class="nowrap">${fmtDate(b.scheduled_date)}</td><td><a href="/invoice?id=${b.id}" target="_blank">${esc(b.invoice_no)}</a></td>
            <td class="num">${money(b.amount + b.deposit_amount)}</td>
            <td>${b.rating ? `<span title="Your rating">${'★'.repeat(b.rating)}</span>` : `<a href="/track?id=${esc(b.tracking_id)}#rate">Rate</a>`}</td></tr>`).join('')}
        </tbody></table></div>` : '<p class="muted">No bills yet — they appear after each delivery.</p>'}
      </div>

      <div class="card"><h3>🎁 Refer &amp; earn</h3>
        <p>Give friends <strong>${money(d.referral.discount)} off</strong> their first delivery. When they get their first delivery, you get a <strong>${money(d.referral.reward)} coupon</strong>.</p>
        <div class="row" style="flex-wrap:nowrap"><input value="${esc(c.referral_code)}" readonly style="font-weight:800;letter-spacing:.1em;text-align:center"><button class="btn ghost" id="copyCode">Copy</button></div>
        <div class="row" style="margin-top:10px">
          <a class="btn green sm" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(shareText)}">Share on WhatsApp</a>
          ${navigator.share ? '<button class="btn ghost sm" id="shareBtn">Share…</button>' : ''}
        </div>
        ${d.coupons.length ? `<h3 style="margin-top:16px">Your coupons</h3>${d.coupons.map((cp) => `<div class="summary-row"><span><strong>${esc(cp.code)}</strong> — ${esc(cp.description)}</span>
          <a class="btn sm" href="/book?code=${encodeURIComponent(cp.code)}">Use</a></div>`).join('')}` : ''}
      </div>

      <div class="card"><h3>🫙 Cans &amp; deposits</h3>
        ${d.containers.length ? d.containers.map((x) => `<div class="summary-row"><span>${esc(x.name)}</span><span>${x.held} with you · ${x.deposit_units} deposit${x.deposit_units === 1 ? '' : 's'} (${money(x.deposit_units * x.deposit)})</span></div>`).join('')
          + '<p class="small muted" style="margin-top:8px">Give your empty cans to the delivery person on each delivery. Deposits are refunded when you return cans for good — just ask us.</p>'
          : '<p class="muted">You have no returnable cans right now.</p>'}
      </div>

      <form class="card" id="profileForm"><h3>My details</h3>
        <div class="field"><label>Name</label><input name="name" value="${esc(c.name)}" required></div>
        <div class="field"><label>Email</label><input name="email" type="email" value="${esc(c.email)}" required></div>
        <div class="field"><label>Address</label><textarea name="address" required>${esc(c.address)}</textarea></div>
        <div class="grid grid-2"><div class="field"><label>PIN code</label><input name="pincode" value="${esc(c.pincode)}" inputmode="numeric"></div>
          <div class="field"><label>Line / Lane No.</label><input name="line_no" value="${esc(c.line_no)}"></div></div>
        <label class="row" style="font-weight:500"><input type="checkbox" name="apply_to_bookings" checked style="width:auto"> Also use this address for my active bookings</label>
        <button class="btn" style="margin-top:12px">Save</button>
      </form>
    </div>`;

  $('#logoutBtn').addEventListener('click', async () => { await api('/api/customer/logout', { body: {} }); renderLogin(c.phone); });
  $('#copyCode').addEventListener('click', () => navigator.clipboard?.writeText(c.referral_code).then(() => toast('Code copied', 'success')).catch(() => {}));
  $('#shareBtn')?.addEventListener('click', () => navigator.share({ title: SETTINGS.business_name, text: shareText }).catch(() => {}));
  $('#profileForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const f = formData(e.target);
    withBusy(e.submitter, async () => { await api('/api/customer/me', { method: 'PUT', body: { ...f, apply_to_bookings: f.apply_to_bookings === 'on' } }); toast('Details saved', 'success'); load(); });
  });
}

function bookingCard(b) {
  const when = b.slot_start ? `${fmtTime(b.slot_start)}–${fmtTime(b.slot_end)}` : fmtTime(b.delivery_time);
  return `<div class="card">
    <div class="row between"><div><strong>${esc(b.booking_no)}</strong> ${freqBadge(b.frequency)} ${badge(b.status)} ${payBadge(b.payment_status)}</div>
      ${b.tracking_id ? `<a class="btn ghost sm" href="/track?id=${esc(b.tracking_id)}">View</a>` : ''}</div>
    <div class="small" style="margin-top:6px">${b.items.map((i) => `${esc(i.name)} × ${i.quantity}`).join(', ')} · ${money(b.amount_per_delivery)}/delivery${b.coupon_code ? ` · code ${esc(b.coupon_code)}` : ''}</div>
    <div class="small muted">${fmtDate(b.start_date)}${b.frequency === 'once' ? '' : ` → ${fmtDate(b.end_date)}`} · ${when}${b.agent_name ? ` · Delivery by ${esc(b.agent_name)}` : ''}</div>
    ${b.status === 'confirmed' ? `<div class="small" style="margin-top:4px">Next delivery: <strong>${b.next_date ? fmtDate(b.next_date) : '—'}</strong> · ${b.delivered_count} delivered · ${b.open_count} upcoming</div>` : ''}
    ${b.status === 'pending' && b.payment_status === 'unpaid' ? `<div class="small" style="margin-top:4px;color:var(--amber-600)">Awaiting payment of ${money(b.total_amount)}.</div>` : ''}
    ${b.status === 'pending' && b.payment_status !== 'unpaid' ? '<div class="small" style="margin-top:4px;color:var(--amber-600)">Paid — we will confirm and schedule your deliveries shortly.</div>' : ''}
    ${['pending', 'confirmed'].includes(b.status) ? `<div class="row" style="margin-top:10px">
      ${b.status === 'pending' && b.payment_status === 'unpaid' && b.tracking_id ? `<a class="btn green sm" href="/track?id=${esc(b.tracking_id)}">Pay now</a>` : ''}
      ${b.status === 'confirmed' && b.frequency !== 'once' ? `<button class="btn sm" data-manage="${b.id}">Skip / pause deliveries</button>` : ''}
      <button class="btn ghost sm" data-cancel="${b.id}" data-no="${esc(b.booking_no)}" data-paid="${b.payment_status === 'paid' ? 1 : ''}">Cancel booking</button></div>` : ''}
  </div>`;
}

async function onBookingAction(e) {
  const t = e.target.closest('[data-manage],[data-cancel]');
  if (!t) return;
  if (t.dataset.cancel) {
    const msg = t.dataset.paid
      ? `Cancel booking ${t.dataset.no}? Deliveries from tomorrow will be cancelled and the unused amount refunded to your original payment method.`
      : `Cancel booking ${t.dataset.no}?`;
    if (!confirm(msg)) return;
    return withBusy(t, async () => {
      const r = await api(`/api/customer/bookings/${t.dataset.cancel}/cancel`, { body: {} });
      toast(r.refund ? `Booking cancelled — ${money(r.refund)} will be refunded` : 'Booking cancelled');
      load();
    });
  }
  const id = t.dataset.manage;
  const r = await api(`/api/customer/bookings/${id}/deliveries`);
  const rows = r.deliveries;
  openModal({
    title: 'Skip or pause deliveries', wide: true,
    body: `<div class="alert" style="margin-bottom:12px">Your plan is prepaid, so skipped or paused deliveries are <strong>moved to the end of your plan</strong> — you don't lose any.</div>
      <form id="pauseForm" class="card" style="background:var(--blue-50);margin-bottom:14px">
        <h3>Going away? Pause a date range</h3>
        <div class="row"><div class="field" style="margin:0"><label>From</label><input type="date" name="from" min="${r.cutoff}" value="${r.cutoff}"></div>
          <div class="field" style="margin:0"><label>To</label><input type="date" name="to" min="${r.cutoff}" value="${addDaysStr(r.cutoff, 6)}"></div>
          <button class="btn" style="align-self:flex-end">Pause</button></div>
        <p class="small muted" style="margin:8px 0 0">Changes are possible from tomorrow onwards. For today's delivery, please call us.</p></form>
      <div class="table-wrap" style="max-height:360px;overflow:auto"><table><thead><tr><th>#</th><th>Date</th><th>Status</th><th></th></tr></thead><tbody>
      ${rows.map((x) => `<tr><td>${x.seq}</td><td class="nowrap">${fmtDate(x.scheduled_date)}${/moved to end/.test(x.note || '') ? '<div class="small muted">moved</div>' : ''}</td>
        <td>${badge(x.status)}</td>
        <td class="right">${x.scheduled_date >= r.cutoff && x.status === 'scheduled' ? `<button class="btn ghost sm" data-skip="${x.id}">Skip</button>` : ''}</td></tr>`).join('')}
      </tbody></table></div>`,
    onOpen: (el, close) => {
      const done = (msg) => { toast(msg, 'success'); close(); load(); };
      $('#pauseForm', el).addEventListener('submit', (ev) => {
        ev.preventDefault();
        withBusy(ev.submitter, async () => {
          const x = await api(`/api/customer/bookings/${id}/pause`, { body: formData(ev.target) });
          done(`${x.paused} deliveries moved — your plan now ends ${fmtDate(x.ends)}`);
        });
      });
      el.addEventListener('click', (ev) => {
        const s = ev.target.closest('[data-skip]');
        if (!s) return;
        withBusy(s, async () => {
          const x = await api(`/api/customer/bookings/${id}/skip`, { body: { delivery_id: Number(s.dataset.skip) } });
          done(`Skipped — moved to ${fmtDate(x.moved_to)}`);
        });
      });
    },
  });
}

(async function init() {
  await loadSettings();
  $('#header').innerHTML = headerHtml('account');
  $('#footer').innerHTML = footerHtml();
  await loadSettings();
  main().addEventListener('click', onBookingAction);
  load();
})();
