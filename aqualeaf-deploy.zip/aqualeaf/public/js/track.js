// Customer tracking page: booking & payment status, delivery schedule, bills and ratings.
let currentTid = null;
let pollTimer = null;
let lastRateKey = null;

function showLookup(html, cls = '') {
  const box = $('#lookupMsg');
  box.className = `alert ${cls}`;
  box.innerHTML = html;
}

function stepsFor(d) {
  if (!d) return '';
  const order = ['scheduled', 'out_for_delivery', 'delivered'];
  const idx = d.status === 'failed' ? 1 : order.indexOf(d.status);
  const labels = ['Scheduled', 'Out for delivery', d.status === 'failed' ? 'Not delivered' : 'Delivered'];
  return `<div class="timeline">${labels.map((l, i) =>
    `<div class="step ${i <= idx ? 'done' : ''} ${d.status === 'failed' && i === 2 ? 'fail' : ''}">${l}</div>`).join('')}</div>`;
}

async function track(tid, { quiet = false } = {}) {
  tid = tid.trim().toUpperCase();
  if (!tid) return;
  let data;
  try {
    data = await api(`/api/track/${encodeURIComponent(tid)}`);
  } catch (e) {
    if (!quiet) { $('#result').innerHTML = ''; showLookup(esc(e.message), 'error'); }
    return;
  }
  currentTid = tid;
  $('#lookupMsg').className = 'hidden';
  const q = new URLSearchParams(location.search);
  const keep = ['paid', 'payment'].filter((k) => q.get(k)).map((k) => `&${k}=${q.get(k)}`).join('');
  history.replaceState(null, '', `/track?id=${tid}${keep}`);
  render(data);
  clearTimeout(pollTimer);
  // Refresh while something is changing: awaiting confirmation, or a delivery is on the way today.
  const b = data.booking;
  if (b.status === 'pending' || b.status === 'confirmed') pollTimer = setTimeout(() => track(tid, { quiet: true }), data.active?.status === 'out_for_delivery' ? 15000 : 30000);
}

function renderRating(deliveries) {
  const unrated = deliveries.filter((d) => d.status === 'delivered' && !d.rating).slice(-3).reverse();
  const key = unrated.map((d) => d.id).join(',');
  if (key === lastRateKey) return;
  lastRateKey = key;
  $('#rateBox').innerHTML = unrated.length ? `<div class="card" style="border-color:#f5d48a;background:#fffaf0">
    <h3>How was your delivery?</h3>
    ${unrated.map((d) => `<form class="rate-form" data-id="${d.id}" style="padding:10px 0;border-top:1px solid var(--line)">
      <div class="row between"><span>${fmtDate(d.scheduled_date)}${d.agent_name ? ` · by ${esc(d.agent_name)}` : ''}</span>
        <span class="stars">${[1, 2, 3, 4, 5].map((n) => `<button type="button" data-star="${n}" aria-label="${n} star${n > 1 ? 's' : ''}">★</button>`).join('')}</span></div>
      <div class="row hidden rate-more" style="margin-top:8px;flex-wrap:nowrap"><input name="comment" maxlength="500" placeholder="Anything we should know? (optional)">
        <button class="btn sm">Send</button></div></form>`).join('')}</div>` : '';
}

function paymentCard(b) {
  const q = new URLSearchParams(location.search);
  if (b.payment_status === 'unpaid') {
    return `<div class="card" style="border-color:#f6e0a8;background:var(--amber-100)">
      <h3>${q.get('payment') === 'failed' ? 'Payment was not completed' : 'Payment pending'}</h3>
      <p>Pay <strong>${money(b.total_amount)}</strong> to confirm booking ${esc(b.booking_no)}. Your booking is held until you pay.</p>
      <button class="btn green" id="payNow">Pay ${money(b.total_amount)} securely</button>
      <span class="small muted" style="margin-left:8px">UPI · cards · net banking</span></div>`;
  }
  if (q.get('paid') === '1') {
    return `<div class="card" style="border-color:#bfe5c8;background:var(--green-100)">
      <h3>✅ Payment received — thank you!</h3>
      <p style="margin:0">We've received <strong>${money(b.paid_amount)}</strong>. ${b.status === 'pending'
        ? "We'll confirm your booking and assign a delivery person shortly. You'll get updates on WhatsApp."
        : 'Your deliveries are scheduled below.'}</p></div>`;
  }
  return '';
}

function render({ booking: b, items, active, deliveries, containers = [] }) {
  renderRating(deliveries);
  const t = todayStr();
  const done = deliveries.filter((d) => d.status === 'delivered');
  const isMoved = (d) => /moved to end/.test(d.note || '');
  const upcoming = deliveries.filter((d) => d.scheduled_date >= t && d.status === 'scheduled').slice(0, 8);
  const past = deliveries.filter((d) => !upcoming.includes(d) && (['delivered', 'failed', 'cancelled'].includes(d.status) || d.scheduled_date < t)).reverse().slice(0, 12);
  const agentName = active?.agent_name || b.agent_name;
  const agentPhone = active?.agent_phone || b.agent_phone;
  const statusText = b.payment_status === 'unpaid' ? 'Awaiting payment'
    : b.status === 'pending' ? 'Paid — awaiting confirmation' : null;

  $('#result').innerHTML = `
  ${paymentCard(b)}
  <div class="grid grid-2" style="margin-top:16px">
    <div class="card">
      <div class="row between"><h2 style="margin:0">Booking ${esc(b.booking_no)}</h2>${statusText ? `<span class="badge b-pending">${statusText}</span>` : badge(b.status)}</div>
      <p class="muted small" style="margin-top:4px">Tracking ID <strong>${esc(b.tracking_id)}</strong></p>
      <dl class="kv">
        <dt>Customer</dt><dd>${esc(b.name)}</dd>
        <dt>Contact</dt><dd>${esc(b.phone)} · ${esc(b.email)}</dd>
        <dt>Address</dt><dd>${esc(b.address)}${b.line_no ? `<br><span class="muted">Line/Lane: ${esc(b.line_no)}</span>` : ''}</dd>
        <dt>Plan</dt><dd>${freqBadge(b.frequency)} ${fmtDate(b.start_date)}${b.frequency === 'once' ? '' : ` → ${fmtDate(b.end_date)}`} at ${b.slot_start ? `${fmtTime(b.slot_start)}–${fmtTime(b.slot_end)}` : fmtTime(b.delivery_time)}</dd>
        <dt>Delivery person</dt><dd>${agentName ? `${esc(agentName)}${agentPhone ? ` · <a href="tel:${esc(agentPhone)}">${esc(agentPhone)}</a>` : ''}` : '—'}</dd>
        <dt>Items</dt><dd>${items.map((i) => `${esc(i.name)} × ${i.quantity}`).join('<br>')}</dd>
        <dt>Payment</dt><dd>${payBadge(b.payment_status)} ${b.payment_status === 'unpaid' ? money(b.total_amount) : money(b.paid_amount)}
          ${b.refunded_amount ? `<span class="small muted">· refunded ${money(b.refunded_amount)}</span>` : ''}</dd>
        ${deliveries.length ? `<dt>Progress</dt><dd>${done.length} of ${deliveries.filter((d) => d.status !== 'cancelled').length} delivered</dd>` : ''}
        ${containers.length ? `<dt>Cans</dt><dd>${containers.map((c) => `${esc(c.name)}: ${c.held} with you${c.deposit_units ? ` · ${c.deposit_units} deposit${c.deposit_units > 1 ? 's' : ''} paid` : ''}`).join('<br>')}</dd>` : ''}
      </dl>
      <p class="small" style="margin:10px 0 0"><a href="/account">Log in to My account</a> to skip or pause deliveries and see all your bills.</p>
    </div>
    <div class="card">
      ${active ? `<div class="row between"><h3 style="margin:0">${active.status === 'out_for_delivery' ? '🚚 On the way' : 'Next delivery'}</h3>${badge(active.status)}</div>
        <p class="muted" style="margin:4px 0 0">${fmtDate(active.scheduled_date)} · ${active.slot_start ? `${fmtTime(active.slot_start)}–${fmtTime(active.slot_end)}` : fmtTime(active.scheduled_time)}</p>
        ${stepsFor(active)}
        ${active.status === 'out_for_delivery' && agentPhone ? `<a class="btn ghost" href="tel:${esc(agentPhone)}" style="margin-top:12px">📞 Call ${esc(agentName || 'delivery person')}</a>` : ''}`
        : `<h3>${b.status === 'cancelled' ? 'This booking was cancelled' : b.status === 'completed' ? 'All deliveries completed ✅'
          : b.payment_status === 'unpaid' ? 'Complete payment to confirm your booking' : 'Your delivery schedule appears here once we confirm the booking'}</h3>`}
      <h3 style="margin-top:18px">Upcoming deliveries</h3>
      ${upcoming.length ? `<div class="table-wrap"><table><thead><tr><th>#</th><th>Date</th><th>Time</th><th>Status</th></tr></thead><tbody>
        ${upcoming.map((d) => `<tr><td>${d.seq}</td><td>${fmtDate(d.scheduled_date)}${isMoved(d) ? '<div class="small muted">moved (skipped day)</div>' : ''}</td>
          <td>${d.slot_start ? `${fmtTime(d.slot_start)}–${fmtTime(d.slot_end)}` : fmtTime(d.scheduled_time)}</td><td>${badge(d.status)}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="muted">Nothing scheduled.</p>'}
    </div>
  </div>
  <div class="card" style="margin-top:16px"><h3>History &amp; bills</h3>
    ${past.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Status</th><th class="num">Amount</th><th>Bill</th></tr></thead><tbody>
      ${past.map((d) => `<tr><td>${fmtDate(d.scheduled_date)}</td><td>${badge(d.status)}${d.rating ? `<div class="small" style="color:#f5a623">${'★'.repeat(d.rating)}</div>` : ''}</td>
        <td class="num">${money(d.amount + (d.deposit_amount || 0))}</td>
        <td>${d.invoice_no ? `<a href="/invoice?id=${d.id}&t=${encodeURIComponent(b.tracking_id)}" target="_blank">${esc(d.invoice_no)}</a>` : '—'}</td></tr>`).join('')}
    </tbody></table></div>` : '<p class="muted">No past deliveries yet.</p>'}
  </div>`;

  $('#payNow')?.addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
    const r = await api('/api/bookings/pay', { body: { booking_no: b.booking_no, phone: b.phone } });
    if (r.paid) return track(currentTid);
    location.href = r.pay_url;
  }));
}

(async function init() {
  await loadSettings();
  $('#header').innerHTML = headerHtml('track');
  $('#footer').innerHTML = footerHtml();
  await loadSettings();

  $$('[data-mode]').forEach((b) => b.addEventListener('click', () => {
    $$('[data-mode]').forEach((x) => x.classList.toggle('active', x === b));
    $('#tidForm').classList.toggle('hidden', b.dataset.mode !== 'tid');
    $('#bookingForm').classList.toggle('hidden', b.dataset.mode !== 'booking');
  }));
  $('#tidForm').addEventListener('submit', (e) => { e.preventDefault(); track(e.target.tid.value); });
  $('#rateBox').addEventListener('click', (e) => {
    const s = e.target.closest('[data-star]');
    if (!s) return;
    const f = s.closest('form');
    f.dataset.rating = s.dataset.star;
    $$('[data-star]', f).forEach((b) => b.classList.toggle('on', Number(b.dataset.star) <= Number(s.dataset.star)));
    $('.rate-more', f).classList.remove('hidden');
    f.comment.focus();
  });
  $('#rateBox').addEventListener('submit', (e) => {
    e.preventDefault();
    const f = e.target;
    withBusy(e.submitter, async () => {
      await api(`/api/track/${encodeURIComponent(currentTid)}/rate`, { body: { delivery_id: Number(f.dataset.id), rating: Number(f.dataset.rating), comment: f.comment.value } });
      toast('Thank you for your feedback! 💙', 'success');
      lastRateKey = null;
      track(currentTid, { quiet: true });
    });
  });
  $('#bookingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = formData(e.target);
    await lookup(f.booking_no, f.phone);
  });

  const q = new URLSearchParams(location.search);
  if (q.get('id')) { $('#tidForm').tid.value = q.get('id'); track(q.get('id')); }
  else if (q.get('booking')) {
    $('[data-mode="booking"]').click();
    $('#bookingForm').booking_no.value = q.get('booking');
    $('#bookingForm').phone.value = q.get('phone') || '';
    if (q.get('phone')) lookup(q.get('booking'), q.get('phone'));
  } else if (q.get('payment') === 'unknown') {
    showLookup('We could not match that payment to a booking. If money was taken, please contact us with your booking number.', 'warn');
  }
})();

async function lookup(bookingNo, phone) {
  try {
    const r = await api('/api/track/lookup', { body: { booking_no: bookingNo, phone } });
    if (r.tracking_id) { $('#tidForm').tid.value = r.tracking_id; track(r.tracking_id); }
    else showLookup(`Booking <strong>${esc(r.booking_no)}</strong> was found but has no tracking ID yet. Please contact us.`, 'warn');
  } catch (err) {
    showLookup(esc(err.message), 'error');
  }
}
