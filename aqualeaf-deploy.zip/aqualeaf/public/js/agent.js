// Delivery agent app: today's run, empty-can collection and delivery confirmation. Bookings are prepaid online.
let ME = null;

// Inside the Android app (Capacitor) new-task alerts are also shown as system notifications.
const Native = (() => {
  const cap = window.Capacitor;
  const isNative = !!cap?.isNativePlatform?.();
  return { isNative, notifications: isNative ? cap.Plugins?.LocalNotifications || cap.registerPlugin?.('LocalNotifications') : null };
})();

function cansHtml(d) {
  if (d.containers?.length) {
    return `<div class="alert" style="margin-top:8px;padding:8px 10px">🫙 ${d.containers.map((c) =>
      `<strong>${esc(c.name)}</strong>: give ${c.delivered}, collect <strong>${c.expected}</strong> empt${c.expected === 1 ? 'y' : 'ies'}
       <span class="muted">(customer has ${c.held})</span>`).join('<br>')}</div>`;
  }
  if (d.moves?.length) {
    return `<div class="small muted" style="margin-top:6px">🫙 ${d.moves.map((m) => `${esc(m.name)}: gave ${m.delivered}, collected ${m.collected}`).join(' · ')}</div>`;
  }
  return '';
}

function card(d) {
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${d.address} ${d.pincode || ''}`)}`;
  const open = d.status === 'scheduled' || d.status === 'out_for_delivery';
  const when = d.slot_start ? `${fmtTime(d.slot_start)}–${fmtTime(d.slot_end)}` : fmtTime(d.scheduled_time);
  return `<div class="delivery-card ${d.status}">
    <div class="row between"><div><strong style="font-size:1.05rem">${esc(d.name)}</strong> <span class="small muted">${esc(d.booking_no)} · #${d.seq}</span></div>${badge(d.status)}</div>
    <div class="small" style="margin-top:4px">🕒 ${fmtDate(d.scheduled_date)}, ${when} · ${freqBadge(d.frequency)}</div>
    <div style="margin-top:8px">📍 ${esc(d.address)}${d.pincode ? ` – ${esc(d.pincode)}` : ''}${d.line_no ? ` <strong>· Line/Lane ${esc(d.line_no)}</strong>` : ''}</div>
    <div>📞 <a href="tel:${esc(d.phone)}">${esc(d.phone)}</a></div>
    ${d.booking_notes ? `<div class="alert" style="margin-top:8px;padding:8px 10px">📝 ${esc(d.booking_notes)}</div>` : ''}
    <div style="margin-top:8px">${d.items.map((i) => `<span class="badge b-water" style="margin:2px 4px 2px 0">${esc(i.name)} × ${i.quantity}</span>`).join('')}</div>
    ${cansHtml(d)}
    <div class="row between" style="margin-top:10px">${d.payment_status === 'cod'
      ? `<span class="badge b-pending">Older cash booking — collect ${money(d.amount)}</span>`
      : '<span class="badge b-delivered">✔ Paid online — collect no cash</span>'}
      ${d.status === 'delivered' ? `<div class="right small"><a href="/invoice?id=${d.id}" target="_blank">${esc(d.invoice_no)}</a>
        ${d.rating ? `<br>${'★'.repeat(d.rating)}${'☆'.repeat(5 - d.rating)}` : ''}</div>` : ''}
      ${d.status === 'failed' ? `<div class="small muted">${esc(d.note)}</div>` : ''}</div>
    ${open ? `<div class="actions">
      <a class="btn ghost sm" href="${mapsUrl}" target="_blank" rel="noopener">🧭 Directions</a>
      ${d.status === 'scheduled' ? `<button class="btn sm" data-act="start" data-id="${d.id}">🚚 Start delivery</button>` : ''}
      <button class="btn green sm" data-act="deliver" data-id="${d.id}">✅ Delivered</button>
      <button class="btn red sm" data-act="fail" data-id="${d.id}">✖ Not delivered</button>
    </div>` : ''}
  </div>`;
}

let current = { deliveries: [], overdue: [] };

async function load() {
  const date = $('#day').value || todayStr();
  let r;
  try { r = await api(`/api/agent/deliveries?date=${date}`); } catch (e) {
    if (e.status === 401) return location.replace('/login?role=agent');
    if (e.code === 'change_password') return requirePasswordChange(() => location.reload());
    $('#list').innerHTML = `<div class="alert error">${esc(e.message)}</div>`;
    return;
  }
  current = r;
  const s = r.summary;
  $('#dayTitle').textContent = date === r.today ? "Today's deliveries" : `Deliveries — ${fmtDate(date)}`;
  $('#summary').innerHTML = [
    ['Assigned', s.total], ['Delivered', s.delivered], ['Left', s.pending], ['Empties collected', s.empties],
  ].map(([l, v]) => `<div class="card stat"><span class="label">${l}</span><span class="value">${v}</span></div>`).join('')
    + (r.rating?.n ? `<div class="card stat"><span class="label">Your rating</span><span class="value">★ ${r.rating.avg}</span><span class="sub">${r.rating.n} reviews</span></div>` : '');
  $('#overdue').innerHTML = r.overdue.length && date === r.today
    ? `<div class="alert warn"><strong>${r.overdue.length} overdue</strong> deliveries from earlier days are still open:</div><div class="stack" style="margin-top:12px">${r.overdue.map(card).join('')}</div>` : '';
  $('#list').innerHTML = r.deliveries.length ? r.deliveries.map(card).join('') : '<div class="card empty">No deliveries assigned for this day. 🎉</div>';
  $('#upcoming').innerHTML = r.upcoming.length ? `<div class="card"><h3>Coming up</h3>${r.upcoming.map((u) =>
    `<div class="summary-row"><a href="#" data-goto="${u.date}">${fmtDate(u.date)}</a><span>${u.n} deliver${u.n === 1 ? 'y' : 'ies'}</span></div>`).join('')}</div>` : '';
}

const findDelivery = (id) => [...current.deliveries, ...current.overdue].find((d) => d.id === Number(id));

function deliverModal(d) {
  const cans = d.containers || [];
  openModal({
    title: `Deliver to ${d.name}`,
    body: `<form id="aForm">
      <div class="alert" style="margin-bottom:12px">✔ This order is <strong>already paid online</strong>. Do not collect cash.</div>
      ${cans.map((c) => `<div class="field"><label>Empty ${esc(c.name)} collected <span class="muted">(gave ${c.delivered}, customer had ${c.held})</span></label>
        <input type="number" min="0" max="999" step="1" name="empty_${c.product_id}" value="${c.expected}" inputmode="numeric"></div>`).join('')}
      <div id="depBox"></div></form>`,
    foot: '<button class="btn ghost" data-close>Back</button><button class="btn green" id="aSave">Mark delivered</button>',
    onOpen: (el, close) => {
      const f = $('#aForm', el);
      const empties = () => Object.fromEntries(cans.map((c) => [c.product_id, f[`empty_${c.product_id}`].value]));
      // If the customer keeps more cans than their prepaid deposit covers, the office follows up — show a note.
      const check = async () => {
        if (!cans.length) return;
        try {
          const p = await api(`/api/agent/deliveries/${d.id}/preview`, { body: { empties: empties() } });
          $('#depBox', el).innerHTML = p.deposit_due ? `<div class="alert warn">Customer will hold extra cans — deposit of ${money(p.deposit_due)} will be billed by the office.</div>` : '';
        } catch (e) { $('#depBox', el).innerHTML = `<span class="small" style="color:var(--red-600)">${esc(e.message)}</span>`; }
      };
      f.addEventListener('change', check);
      check();
      $('#aSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        const r = await api(`/api/agent/deliveries/${d.id}/deliver`, { body: { empties: empties() } });
        toast(`Delivered · invoice ${r.invoice_no}`, 'success');
        close();
        load();
      }));
    },
  });
}

function act(kind, id) {
  const d = findDelivery(id);
  if (kind === 'start') {
    return withBusy(null, async () => {
      await api(`/api/agent/deliveries/${id}/start`, { body: {} });
      toast('Delivery started — the customer has been told you are on the way', 'success');
      load();
    });
  }
  if (kind === 'deliver') return deliverModal(d);
  openModal({
    title: 'Could not deliver',
    body: `<form id="aForm"><div class="field"><label class="req">Reason</label><select name="note">
      <option>Customer not available</option><option>Address not found</option><option>Customer refused</option>
      <option>Customer asked to reschedule</option><option>Vehicle / stock problem</option></select></div></form>`,
    foot: '<button class="btn ghost" data-close>Back</button><button class="btn red" id="aSave">Mark not delivered</button>',
    onOpen: (el, close) => $('#aSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
      await api(`/api/agent/deliveries/${id}/fail`, { body: { note: formData($('#aForm', el)).note } });
      toast('Marked as not delivered — the office has been told');
      close();
      load();
    })),
  });
}

(async function init() {
  try { ME = (await api('/api/auth/me')).user; } catch { return location.replace('/login?role=agent'); }
  if (ME.role !== 'agent') return location.replace('/admin');
  if (ME.must_change_password) return requirePasswordChange(() => location.reload());
  await loadSettings();
  $('#brand').innerHTML = `${BRAND_SVG}<span>${esc(SETTINGS.business_name)}</span>`;
  $('#who').textContent = `👋 ${ME.name}`;
  const qDate = new URLSearchParams(location.search).get('date');
  $('#day').value = /^\d{4}-\d{2}-\d{2}$/.test(qDate || '') ? qDate : todayStr();
  setupInstallButton($('#installBtn'));
  initNotifications($('#notifMount'), {
    repeat: 2,
    onNew: (fresh) => {
      load();
      if (Native.notifications && document.hidden) {
        Native.notifications.schedule({ notifications: fresh.map((n) => ({ id: n.id, title: n.title, body: n.body })) }).catch(() => {});
      }
    },
  });
  Native.notifications?.requestPermissions?.().catch(() => {});

  const shift = (n) => {
    const d = new Date(`${$('#day').value}T00:00:00`);
    d.setDate(d.getDate() + n);
    $('#day').value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    load();
  };
  $('#prevDay').addEventListener('click', () => shift(-1));
  $('#nextDay').addEventListener('click', () => shift(1));
  $('#day').addEventListener('change', load);
  $('#refresh').addEventListener('click', load);
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (b) act(b.dataset.act, b.dataset.id);
    const g = e.target.closest('[data-goto]');
    if (g) { e.preventDefault(); $('#day').value = g.dataset.goto; load(); scrollTo(0, 0); }
  });
  $('#logout').addEventListener('click', async () => {
    await Push.disable().catch(() => {});
    await api('/api/auth/logout', { body: {} });
    location.replace('/login?role=agent');
  });

  await load();
  setInterval(load, 60000);
})();
