// Standalone customer booking page: products → details (PIN) → plan (slot) → coupon → pay with Razorpay.
let products = [];
let cart = store.get(CART_KEY, {});
let slots = [];
let quote = null;          // last successful server quote
let quoteError = '';       // why the last quote failed (area / minimum order / coupon)
let appliedCoupon = '';    // coupon code the customer applied
let couponMsg = '';        // why the last coupon was rejected (kept visible after re-pricing)
const form = () => $('#bookForm');

const lines = () => Object.entries(cart)
  .map(([id, qty]) => ({ product: products.find((p) => p.id === Number(id)), qty }))
  .filter((l) => l.product && l.qty > 0);
const subtotal = () => lines().reduce((s, l) => s + l.product.price * l.qty, 0);

function setQty(id, qty) {
  qty = Math.max(0, Math.min(999, Math.round(Number(qty) || 0)));
  if (qty) cart[id] = qty; else delete cart[id];
  store.set(CART_KEY, cart);
  renderPicks();
  requote();
}

function renderPicks() {
  $('#pickList').innerHTML = [products].map((list) => `${list.map((p) => {
    const qty = cart[p.id] || 0;
    return `<div class="pick-row ${qty ? 'selected' : ''}">
      <div class="pick-art ${p.category}">${productArt(p.type)}</div>
      <div><strong>${esc(p.name)}</strong><div class="small muted">${esc(p.unit)} · <strong style="color:var(--blue-900)">${money(p.price)}</strong>
        ${p.returnable && p.deposit ? ` · <span title="Refundable deposit per can, charged only for cans you keep">+${money(p.deposit)} refundable can deposit</span>` : ''}</div></div>
      <div class="stepper"><button type="button" data-dec="${p.id}" aria-label="Decrease ${esc(p.name)}">−</button>
        <input value="${qty}" data-qty="${p.id}" inputmode="numeric" aria-label="Quantity of ${esc(p.name)}">
        <button type="button" data-inc="${p.id}" aria-label="Increase ${esc(p.name)}">+</button></div>
    </div>`;
  }).join('')}`).join('');
}

// Number of deliveries in the chosen plan (the whole plan is paid upfront).
function deliveryCount() {
  const f = form();
  const freq = f.frequency.value, start = f.start_date.value;
  if (!start) return 1;
  return freq === 'once' ? 1 : countDeliveries(freq, start, f.end_date.value || start);
}

// ---- server-side pricing (delivery area, charges, minimum order, coupon, deposit, upfront total)
let quoteTimer = null;
function requote() {
  clearTimeout(quoteTimer);
  quoteTimer = setTimeout(async () => {
    const f = form();
    const pin = f.pincode.value.trim();
    quote = null;
    quoteError = '';
    if (!lines().length || !/^\d{4,10}$/.test(pin)) { renderSummary(); return; }
    try {
      quote = await api('/api/quote', { body: {
        items: lines().map((l) => ({ product_id: l.product.id, quantity: l.qty })), pincode: pin, coupon_code: appliedCoupon, phone: f.phone.value,
        deliveries: deliveryCount(),
      } });
      $('#pinHint').innerHTML = `<span style="color:var(--green-700)">✓ We deliver here${quote.area_name ? ` (${esc(quote.area_name)})` : ''}${quote.min_order ? ` · minimum order ${money(quote.min_order)}` : ''}</span>`;
      $('#couponHint').innerHTML = quote.coupon ? `<span style="color:var(--green-700)">✓ ${esc(quote.coupon.description)}</span>`
        : couponMsg ? `<span style="color:var(--red-600)">${esc(couponMsg)}</span>` : '';
    } catch (e) {
      quoteError = e.message;
      if (appliedCoupon && /coupon|referral|code/i.test(e.message)) {
        // Price the order without the rejected code, but keep telling the customer why it didn't apply.
        couponMsg = e.message;
        appliedCoupon = '';
        return requote();
      }
      $('#pinHint').innerHTML = `<span style="color:var(--red-600)">${esc(e.message)}</span>`;
    }
    renderSummary();
  }, 250);
}

function renderSummary() {
  const l = lines();
  $('#sumItems').innerHTML = l.length
    ? l.map(({ product: p, qty }) => `<div class="summary-row"><span>${esc(p.name)} × ${qty}</span><span>${money(p.price * qty)}</span></div>`).join('')
    : '<p class="muted">No products selected yet.</p>';
  const charge = quote ? quote.delivery_charge : null;
  $('#sumCharge').textContent = charge === null ? '—' : charge ? money(charge) : 'Free';
  const per = quote ? quote.per_delivery : subtotal();
  $('#sumPer').textContent = money(per);
  const disc = quote?.coupon?.discount || 0;
  $('#sumDiscountRow').classList.toggle('hidden', !disc);
  $('#sumDiscountLabel').textContent = quote?.coupon ? `${quote.coupon.code} (${quote.coupon.scope === 'all' ? 'each delivery' : 'first delivery'})` : 'Discount';
  $('#sumDiscount').textContent = `− ${money(disc)}`;
  $('#depositRow').classList.toggle('hidden', !quote?.deposit);
  if (quote?.deposit) $('#sumDeposit').textContent = money(quote.deposit);

  const f = form();
  const freq = f.frequency.value;
  $$('#freqChips .chip').forEach((ch) => ch.classList.toggle('active', ch.querySelector('input').checked));
  $('#endWrap').classList.toggle('hidden', freq === 'once');
  $('#dateLabel').textContent = freq === 'once' ? 'Delivery date' : 'Start date';
  const start = f.start_date.value;
  if (!start) { $('#schedSummary').textContent = 'Choose a date'; $('#schedTotal').textContent = '—'; return; }
  f.end_date.min = start;
  if (freq !== 'once' && (!f.end_date.value || f.end_date.value < start || f.end_date.dataset.auto === '1')) {
    f.end_date.value = defaultEnd(freq, start);
    f.end_date.dataset.auto = '1';
  }
  const n = freq === 'once' ? 1 : countDeliveries(freq, start, f.end_date.value || start);
  const slot = slots.find((s) => s.id === Number(f.slot_id?.value));
  $('#schedSummary').textContent = `${FREQ[freq]} · ${n} deliver${n === 1 ? 'y' : 'ies'} · ${fmtDate(start)}${freq === 'once' ? '' : ` → ${fmtDate(f.end_date.value)}`}${slot ? ` · ${fmtTime(slot.start_time)}–${fmtTime(slot.end_time)}` : ''}`;
  // The server quote is the source of truth; until it arrives (or if the PIN isn't entered yet) show an estimate.
  const total = quote && quote.deliveries === n ? quote.total
    : per * n - (quote?.coupon ? (quote.coupon.scope === 'all' ? disc * n : disc) : 0) + (quote?.deposit || 0);
  $('#schedTotal').textContent = l.length ? money(total) : '—';
  $('#submitBtn').textContent = l.length && quote ? `Pay ${money(total)} & book` : 'Pay & book';
}

// ---- time slots for the chosen start date
async function loadSlots() {
  const date = form().start_date.value;
  if (!date) return;
  let r;
  try { r = await api(`/api/slots?date=${date}`); } catch { return; }
  slots = r.slots;
  const hasSlots = slots.length > 0;
  $('#slotWrap').classList.toggle('hidden', !hasSlots);
  $('#timeWrap').classList.toggle('hidden', hasSlots);
  const prev = Number(form().querySelector('input[name="slot_id"]:checked')?.value);
  $('#slotChips').innerHTML = slots.map((s) => `<label class="chip ${s.available ? '' : 'disabled'}" title="${esc(s.reason || `${s.remaining} left`)}">
    <input type="radio" name="slot_id" value="${s.id}" ${s.available ? '' : 'disabled'} ${s.available && s.id === prev ? 'checked' : ''}>
    ${esc(s.label)} · ${fmtTime(s.start_time)}–${fmtTime(s.end_time)}${s.available ? (s.remaining <= 5 ? ` <span class="small">(${s.remaining} left)</span>` : '') : ` <span class="small">(${esc(s.reason)})</span>`}</label>`).join('');
  if (!form().querySelector('input[name="slot_id"]:checked')) {
    const first = form().querySelector('input[name="slot_id"]:not([disabled])');
    if (first) first.checked = true;
  }
  if (hasSlots && !slots.some((s) => s.available)) {
    $('#slotChips').insertAdjacentHTML('beforeend', '<div class="hint" style="color:var(--red-600)">No slots left on this date — please choose another day.</div>');
  }
  markSlots();
  renderSummary();
}
const markSlots = () => $$('#slotChips .chip').forEach((ch) => ch.classList.toggle('active', !!ch.querySelector('input:checked')));

function showError(msg) {
  const box = $('#formError');
  box.textContent = msg;
  box.classList.remove('hidden');
}

async function submit(btn) {
  $('#formError').classList.add('hidden');
  if (!lines().length) {
    showError('Please choose at least one product.');
    $('#pickList').scrollIntoView({ behavior: 'smooth', block: 'start' });
    return;
  }
  const f = form();
  if (!f.reportValidity()) return;
  if (slots.length && !f.querySelector('input[name="slot_id"]:checked')) { showError('Please choose a delivery time slot.'); return; }
  if (quoteError && !/code/i.test(quoteError)) { showError(quoteError); return; }
  const data = formData(f);
  await withBusy(btn, async () => {
    try {
      const res = await api('/api/bookings', {
        body: { ...data, coupon_code: appliedCoupon, items: lines().map((l) => ({ product_id: l.product.id, quantity: l.qty })) },
      });
      store.set(CUSTOMER_KEY, { name: data.name, phone: data.phone, email: data.email, address: data.address, line_no: data.line_no, pincode: data.pincode });
      cart = {};
      store.set(CART_KEY, cart);
      // Off to Razorpay (or the test payment page). Coming back lands on the tracking page with the result.
      if (res.pay_url) { location.href = res.pay_url; return; }
      $('#main').innerHTML = `<div class="card" style="max-width:600px;margin:0 auto;text-align:center">
        <h1>Booking ${esc(res.booking_no)} saved</h1>
        <div class="alert warn" style="text-align:left">${esc(res.pay_error || 'Online payment is not available right now.')}</div>
        <p style="margin-top:12px">Please call us on <strong>${esc(SETTINGS.phone)}</strong> to complete your booking.</p>
        <a class="btn" href="/track?id=${encodeURIComponent(res.tracking_id)}">View booking</a></div>`;
      scrollTo(0, 0);
    } catch (err) {
      showError(err.message);
      if (/slot/i.test(err.message)) loadSlots();
    }
  });
}

(async function init() {
  await loadSettings();
  $('#header').innerHTML = headerHtml('book');
  $('#footer').innerHTML = footerHtml();
  await loadSettings();

  const f = form();
  $('#freqChips').innerHTML = PLANS.map((k, i) =>
    `<label class="chip ${i === 0 ? 'active' : ''}"><input type="radio" name="frequency" value="${k}" ${i === 0 ? 'checked' : ''}>${FREQ[k]}</label>`).join('');
  f.start_date.min = todayStr();
  f.start_date.value = todayStr(1);
  const q = new URLSearchParams(location.search);
  if (PLANS.includes(q.get('plan'))) f.querySelector(`input[value="${q.get('plan')}"]`).checked = true;
  if (q.get('code')) { $('#f-coupon').value = q.get('code').toUpperCase(); appliedCoupon = $('#f-coupon').value; }

  // Prefill: logged-in customer account first, otherwise details remembered on this device.
  let saved = store.get(CUSTOMER_KEY, null);
  try { const s = await api('/api/customer/session'); if (s.logged_in) saved = s.customer; } catch { /* ignore */ }
  if (saved?.name) {
    for (const k of ['name', 'phone', 'email', 'address', 'line_no', 'pincode']) if (f[k]) f[k].value = saved[k] || '';
    $('#savedNote').innerHTML = `Welcome back, <strong>${esc(saved.name)}</strong> — we've filled in your saved details. <a href="#" id="clearSaved">Not you?</a>`;
    $('#savedNote').classList.remove('hidden');
    $('#clearSaved').addEventListener('click', (e) => {
      e.preventDefault();
      store.set(CUSTOMER_KEY, null);
      for (const k of ['name', 'phone', 'email', 'address', 'line_no', 'pincode']) f[k].value = '';
      $('#savedNote').classList.add('hidden');
      requote();
    });
  }

  f.addEventListener('change', (e) => {
    if (e.target === f.end_date) f.end_date.dataset.auto = '0';
    if (e.target === f.start_date) loadSlots();
    if (e.target.name === 'slot_id') markSlots();
    if (['pincode', 'phone', 'frequency', 'start_date', 'end_date'].includes(e.target.name)) requote();
    renderSummary();
  });
  f.pincode.addEventListener('input', () => { if (/^\d{6}$/.test(f.pincode.value)) requote(); });
  f.addEventListener('submit', (e) => { e.preventDefault(); submit($('#submitBtn')); });
  $('#submitBtn').addEventListener('click', (e) => submit(e.currentTarget));
  $('#applyCoupon').addEventListener('click', () => {
    appliedCoupon = $('#f-coupon').value.trim().toUpperCase();
    couponMsg = '';
    if (!appliedCoupon) { $('#couponHint').textContent = ''; }
    else if (!f.pincode.value || !lines().length) { $('#couponHint').textContent = 'Add products and your PIN code first'; }
    requote();
  });
  $('#f-coupon').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#applyCoupon').click(); } });

  $('#pickList').addEventListener('click', (e) => {
    const t = e.target.closest('[data-inc],[data-dec]');
    if (!t) return;
    if (t.dataset.inc) setQty(t.dataset.inc, (cart[t.dataset.inc] || 0) + 1);
    else setQty(t.dataset.dec, (cart[t.dataset.dec] || 0) - 1);
  });
  $('#pickList').addEventListener('change', (e) => { if (e.target.dataset.qty) setQty(e.target.dataset.qty, e.target.value); });

  try {
    products = await api('/api/products');
  } catch (e) {
    $('#pickList').innerHTML = `<div class="empty">Could not load products: ${esc(e.message)}</div>`;
    return;
  }
  for (const id of Object.keys(cart)) if (!products.some((p) => p.id === Number(id))) delete cart[id];
  renderPicks();
  await loadSlots();
  requote();
})();
