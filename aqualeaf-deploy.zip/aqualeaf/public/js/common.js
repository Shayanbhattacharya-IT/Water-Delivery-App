// Shared helpers for every page.
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

async function api(path, { method, body } = {}) {
  const res = await fetch(path, {
    method: method || (body !== undefined ? 'POST' : 'GET'),
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  const isJson = (res.headers.get('content-type') || '').includes('json');
  const data = isJson ? await res.json() : await res.text();
  if (!res.ok) {
    const err = new Error((data && data.error) || 'Request failed');
    err.status = res.status;
    err.code = data && data.code;
    throw err;
  }
  return data;
}

let SETTINGS = { business_name: 'AquaLeaf', currency: '₹' };
async function loadSettings() {
  try { SETTINGS = await api('/api/settings'); } catch { /* keep defaults */ }
  $$('[data-setting]').forEach((el) => { el.textContent = SETTINGS[el.dataset.setting] || ''; });
  if (SETTINGS.business_name) document.title = document.title.replace('AquaLeaf', SETTINGS.business_name);
  return SETTINGS;
}

const money = (n) => `${SETTINGS.currency || '₹'}${Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function fmtDate(s) {
  if (!s) return '—';
  const [y, m, d] = s.slice(0, 10).split('-').map(Number);
  return `${d} ${MONTHS[m - 1]} ${y}`;
}
function fmtTime(t) {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`;
}
const fmtDateTime = (s) => (s ? `${fmtDate(s)}, ${fmtTime(s.slice(11, 16))}` : '—');
function todayStr(offset = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function timeAgo(iso) {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  return `${Math.round(s / 3600)} h ago`;
}

const FREQ = { once: 'One time', alternate: 'Alternate days', daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', yearly: 'Yearly' };
const STATUS = { out_for_delivery: 'Out for delivery' };
const badge = (status) => `<span class="badge b-${esc(status)}">${esc(STATUS[status] || String(status).replaceAll('_', ' '))}</span>`;
const freqBadge = (f) => `<span class="badge b-freq">${esc(FREQ[f] || f)}</span>`;
// Plans customers can book now (older bookings may still show weekly/monthly/yearly).
const PLANS = ['once', 'alternate', 'daily'];
const PAY = { unpaid: ['Awaiting payment', 'pending'], paid: ['Paid', 'delivered'], cod: ['Cash (old)', 'scheduled'],
  refunded: ['Refunded', 'cancelled'], partially_refunded: ['Part refunded', 'pending'] };
const payBadge = (s) => `<span class="badge b-${(PAY[s] || [])[1] || 'pending'}">${esc((PAY[s] || [s])[0])}</span>`;

function toast(msg, type = '') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// Simple modal: returns { el, close }. `onSubmit` receives FormData when the form is submitted.
// `locked` modals can't be dismissed (no ×, no backdrop click, no Escape) — e.g. a required password change.
function openModal({ title, body, foot = '', wide = false, onOpen, locked = false }) {
  const ov = document.createElement('div');
  ov.className = 'overlay';
  ov.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
    <div class="modal-head"><h2>${esc(title)}</h2><button class="icon-btn" data-close aria-label="Close">×</button></div>
    <div class="modal-body">${body}</div>${foot ? `<div class="modal-foot">${foot}</div>` : ''}</div>`;
  const close = () => { ov.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape' && !locked) close(); };
  ov.addEventListener('click', (e) => { if (!locked && (e.target === ov || e.target.closest('[data-close]'))) close(); });
  if (locked) ov.querySelector('.modal-head [data-close]')?.remove();
  document.addEventListener('keydown', onKey);
  document.body.appendChild(ov);
  onOpen?.(ov, close);
  return { el: ov, close };
}

const formData = (form) => Object.fromEntries(new FormData(form).entries());

async function withBusy(btn, fn) {
  const label = btn?.innerHTML;
  if (btn) { btn.disabled = true; btn.innerHTML = 'Please wait…'; }
  try { return await fn(); } catch (e) { toast(e.message, 'error'); return undefined; } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = label; }
  }
}

const BRAND_SVG = `<svg class="brand-mark" viewBox="0 0 40 40" aria-hidden="true"><path d="M20 3C14 12 8 18 8 25a12 12 0 0 0 24 0c0-7-6-13-12-22z" fill="#1f8fd6"/><path d="M20 35c0-8 3-13 9-16-1 7-4 13-9 16z" fill="#34a853"/><path d="M14 24a6 6 0 0 0 4 6" stroke="#fff" stroke-width="2.5" fill="none" stroke-linecap="round"/></svg>`;

// Illustrations per product type (no external images needed).
function productArt(type) {
  const W = (inner) => `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">${inner}</svg>`;
  switch (type) {
    case 'can': return W(`<rect x="50" y="8" width="20" height="10" rx="3" fill="#0e6ba8"/><rect x="46" y="16" width="28" height="8" rx="3" fill="#1f8fd6"/>
      <path d="M32 34q0-10 12-10h32q12 0 12 10v66q0 12-12 12H44q-12 0-12-12z" fill="#9fd3f5" stroke="#1f8fd6" stroke-width="3"/>
      <path d="M34 60h52v40q0 10-10 10H44q-10 0-10-10z" fill="#5fb6ec" opacity=".8"/><rect x="40" y="44" width="40" height="5" rx="2.5" fill="#fff" opacity=".7"/>
      <rect x="40" y="72" width="40" height="20" rx="4" fill="#fff"/><text x="60" y="86" font-size="11" text-anchor="middle" font-family="sans-serif" font-weight="700" fill="#0e6ba8">20L</text>`);
    case 'bottle': return W(`<g transform="translate(-14 0)"><rect x="54" y="8" width="14" height="9" rx="2" fill="#0e6ba8"/><path d="M54 17h14v10q10 6 10 18v58q0 8-8 8H52q-8 0-8-8V45q0-12 10-18z" fill="#bfe3f9" stroke="#1f8fd6" stroke-width="3"/>
      <rect x="45" y="58" width="32" height="22" fill="#1f8fd6"/><path d="M47 88h28v14q0 6-6 6H53q-6 0-6-6z" fill="#7cc4f0" opacity=".7"/></g>
      <g transform="translate(26 14) scale(.85)"><rect x="54" y="8" width="14" height="9" rx="2" fill="#0e6ba8"/><path d="M54 17h14v10q10 6 10 18v58q0 8-8 8H52q-8 0-8-8V45q0-12 10-18z" fill="#bfe3f9" stroke="#1f8fd6" stroke-width="3"/>
      <rect x="45" y="58" width="32" height="22" fill="#34a853"/></g>`);
    case 'box': return W(`<path d="M20 38l40-18 40 18v56l-40 18-40-18z" fill="#cfe9fb" stroke="#0e6ba8" stroke-width="3" stroke-linejoin="round"/>
      <path d="M20 38l40 18 40-18M60 56v56" fill="none" stroke="#0e6ba8" stroke-width="3" stroke-linejoin="round"/><path d="M60 56l40-18v56l-40 18z" fill="#9fd3f5"/>
      <rect x="30" y="72" width="16" height="10" rx="2" fill="#1f8fd6"/><rect x="35" y="82" width="6" height="8" fill="#0e6ba8"/>
      <path d="M70 70l20-9" stroke="#fff" stroke-width="4" stroke-linecap="round"/>`);
    case 'jar': return W(`<rect x="44" y="10" width="32" height="10" rx="3" fill="#0e6ba8"/><path d="M30 30q0-10 12-10h36q12 0 12 10v72q0 10-10 10H40q-10 0-10-10z" fill="#bfe3f9" stroke="#1f8fd6" stroke-width="3"/>
      <path d="M90 40q14 0 14 16t-14 16" fill="none" stroke="#1f8fd6" stroke-width="6" stroke-linecap="round"/><path d="M32 56h56v46q0 8-8 8H40q-8 0-8-8z" fill="#7cc4f0" opacity=".8"/>
      <rect x="22" y="84" width="12" height="9" rx="2" fill="#0e6ba8"/>`);
    case 'leafy': return W(`<ellipse cx="60" cy="74" rx="40" ry="34" fill="#7bc96f"/><path d="M60 40c-26 0-38 20-34 40 10-12 22-16 34-16s24 4 34 16c4-20-8-40-34-40z" fill="#a6dc8f"/>
      <path d="M60 46c-14 4-20 18-18 32 6-8 12-12 18-12s12 4 18 12c2-14-4-28-18-32z" fill="#cfeeb9"/><path d="M60 50v58M60 70l-14 12M60 70l14 12M60 88l-18 12M60 88l18 12" stroke="#4e9d45" stroke-width="2.5" fill="none" stroke-linecap="round"/>`);
    case 'herb': return W(`<path d="M60 112V40M60 70l-22-18M60 58l20-20M60 88l22-14" stroke="#3a8a3f" stroke-width="4" fill="none" stroke-linecap="round"/>
      <ellipse cx="60" cy="30" rx="12" ry="18" fill="#56b35a"/><ellipse cx="34" cy="48" rx="16" ry="10" transform="rotate(35 34 48)" fill="#6cc46a"/>
      <ellipse cx="86" cy="34" rx="16" ry="10" transform="rotate(-40 86 34)" fill="#6cc46a"/><ellipse cx="88" cy="70" rx="15" ry="9" transform="rotate(-25 88 70)" fill="#56b35a"/>
      <ellipse cx="36" cy="82" rx="14" ry="9" transform="rotate(30 36 82)" fill="#7fd07a"/>`);
    case 'tomato': return W(`<path d="M30 30q30-16 60 0" stroke="#3a8a3f" stroke-width="4" fill="none" stroke-linecap="round"/>
      <circle cx="40" cy="62" r="18" fill="#e5483b"/><circle cx="76" cy="58" r="20" fill="#f05a4a"/><circle cx="58" cy="90" r="19" fill="#d93d30"/>
      <circle cx="34" cy="56" r="4" fill="#fff" opacity=".5"/><circle cx="70" cy="51" r="4" fill="#fff" opacity=".5"/><circle cx="52" cy="84" r="4" fill="#fff" opacity=".5"/>
      <path d="M40 44l-5-8M76 38l4-8M58 71l0-8" stroke="#3a8a3f" stroke-width="4" stroke-linecap="round"/>`);
    case 'microgreens': return W(`<rect x="14" y="78" width="92" height="28" rx="6" fill="#8a6a4a"/><rect x="14" y="78" width="92" height="8" rx="4" fill="#6e523a"/>
      ${[24, 36, 48, 60, 72, 84, 96].map((x, i) => `<path d="M${x} 80V${50 + (i % 3) * 6}" stroke="#7bbf5a" stroke-width="3"/><ellipse cx="${x - 5}" cy="${48 + (i % 3) * 6}" rx="7" ry="4" fill="#5fae47"/><ellipse cx="${x + 5}" cy="${46 + (i % 3) * 6}" rx="7" ry="4" fill="#8fd16d"/>`).join('')}`);
    default: return W('<circle cx="60" cy="60" r="40" fill="#cfe9fb"/>');
  }
}

function headerHtml(active) {
  return `<header class="site-header"><div class="container">
    <a class="brand" href="/">${BRAND_SVG}<span data-setting="business_name">${esc(SETTINGS.business_name)}</span></a>
    <nav class="nav">
      <a href="/" class="hide-sm ${active === 'shop' ? 'active' : ''}">Shop</a>
      <a href="/book" class="${active === 'book' ? 'active' : ''}">Book now</a>
      <a href="/track" class="${active === 'track' ? 'active' : ''}">Track order</a>
      <a href="/account" class="${active === 'account' ? 'active' : ''}">My account</a>
      <a href="/login" class="hide-sm">Staff login</a>
      <span id="headerExtra"></span>
    </nav></div></header>`;
}

function footerHtml() {
  return `<footer class="site-footer"><div class="container row between">
    <div><strong data-setting="business_name"></strong> — <span data-setting="tagline"></span><br><span data-setting="address"></span></div>
    <div>📞 <span data-setting="phone"></span> &nbsp; ✉️ <span data-setting="email"></span><br><span class="small">🔒 Secure online payment by Razorpay · UPI, cards, net banking</span></div>
  </div></footer>`;
}

// ---- local storage (cart + the customer's saved details live on their own device)
const CART_KEY = 'aq_cart';
const CUSTOMER_KEY = 'aq_customer';
const store = {
  get(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
  set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable */ } },
};

// ---- schedule estimate (mirrors server/schedule.js)
function addDaysStr(s, n) { const d = new Date(`${s}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }
function addMonthsStr(s, n) {
  const [y, m, d] = s.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1 + n, 1));
  const dim = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
  t.setUTCDate(Math.min(d, dim));
  return t.toISOString().slice(0, 10);
}
function nthDate(freq, start, i) {
  return { once: i === 0 ? start : null, daily: addDaysStr(start, i), alternate: addDaysStr(start, 2 * i), weekly: addDaysStr(start, 7 * i),
    monthly: addMonthsStr(start, i), yearly: addMonthsStr(start, 12 * i) }[freq];
}
function countDeliveries(freq, start, end) {
  let n = 0;
  for (let i = 0; i < 400; i++) { const d = nthDate(freq, start, i); if (!d || d > end) break; n++; }
  return n;
}
function defaultEnd(freq, start) {
  return { once: start, daily: addDaysStr(start, 29), alternate: addDaysStr(start, 29), weekly: addDaysStr(start, 77),
    monthly: addMonthsStr(start, 11), yearly: addMonthsStr(start, 24) }[freq];
}

// ---- notification chime (Web Audio, no sound file needed).
// Browsers keep page audio muted until the user clicks or presses a key once, so we unlock on first interaction.
const SOUND_KEY = 'aq_sound';
const chime = (() => {
  let ctx = null;
  const get = () => {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    return ctx;
  };
  const unlock = () => { const c = get(); if (c && c.state === 'suspended') c.resume(); };
  ['pointerdown', 'keydown', 'touchstart'].forEach((ev) => addEventListener(ev, unlock, { passive: true }));

  function tone(c, freq, start, dur) {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = 'sine';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(0.3, start + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g).connect(c.destination);
    o.start(start);
    o.stop(start + dur + 0.05);
  }
  return {
    enabled: () => store.get(SOUND_KEY, true) !== false,
    setEnabled: (on) => store.set(SOUND_KEY, !!on),
    ready: () => !!ctx && ctx.state === 'running',
    // A rising "ding-dong"; `times` repeats it (agents get it twice so it's harder to miss on the road).
    play(times = 1, force = false) {
      if (!force && !this.enabled()) return false;
      const c = get();
      if (!c || c.state !== 'running') return false;
      let t = c.currentTime + 0.02;
      for (let i = 0; i < times; i++) {
        tone(c, 880, t, 0.35);
        tone(c, 1318.5, t + 0.18, 0.55);
        t += 0.85;
      }
      return true;
    },
  };
})();

// ---- PWA: service worker + Web Push (staff get alerts even when the app/tab is closed).
const Push = {
  supported: () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && window.isSecureContext,
  async registration() {
    if (!('serviceWorker' in navigator)) return null;
    return navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => null);
  },
  async subscription() {
    const reg = await this.registration();
    return reg?.pushManager ? reg.pushManager.getSubscription() : null;
  },
  async enable() {
    if (!this.supported()) throw new Error('Push alerts need HTTPS and a modern browser (Chrome, Edge, Firefox, or Safari on an installed app)');
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') throw new Error('Notifications are blocked — allow them for this site in your browser settings');
    const reg = await this.registration();
    await navigator.serviceWorker.ready;
    const { key } = await api('/api/push/key');
    const pad = '='.repeat((4 - (key.length % 4)) % 4);
    const raw = atob((key + pad).replace(/-/g, '+').replace(/_/g, '/'));
    const sub = (await reg.pushManager.getSubscription())
      || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(raw, (c) => c.charCodeAt(0)) });
    await api('/api/push/subscribe', { body: { subscription: sub.toJSON() } });
    return true;
  },
  async disable() {
    const sub = await this.subscription();
    if (!sub) return;
    await api('/api/push/unsubscribe', { body: { endpoint: sub.endpoint } }).catch(() => {});
    await sub.unsubscribe();
  },
};

// "Install app" button (Android/desktop Chrome & Edge). iOS: Share → Add to Home Screen.
let deferredInstall = null;
addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstall = e;
  document.dispatchEvent(new Event('aq-installable'));
});
const isStandalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
function setupInstallButton(btn) {
  if (!btn || isStandalone()) return;
  const show = () => btn.classList.remove('hidden');
  if (deferredInstall) show();
  document.addEventListener('aq-installable', show);
  if (/iphone|ipad/i.test(navigator.userAgent)) { show(); btn.dataset.ios = '1'; }
  btn.addEventListener('click', async () => {
    if (btn.dataset.ios) return toast('On iPhone: tap the Share button, then “Add to Home Screen”');
    if (!deferredInstall) return;
    deferredInstall.prompt();
    await deferredInstall.userChoice;
    deferredInstall = null;
    btn.classList.add('hidden');
  });
}

// Staff whose password was set by an admin (or still the demo one) must pick a new one before using the app.
function requirePasswordChange(onDone) {
  openModal({
    title: 'Choose a new password',
    body: `<form id="pcForm"><p class="muted">For security, please replace the temporary password before continuing.</p>
      <div class="field"><label class="req">Current (temporary) password</label><input type="password" name="current" autocomplete="current-password" required></div>
      <div class="field"><label class="req">New password</label><input type="password" name="next" autocomplete="new-password" minlength="8" required>
        <div class="hint">At least 8 characters.</div></div>
      <div class="field"><label class="req">Repeat new password</label><input type="password" name="repeat" autocomplete="new-password" required></div></form>`,
    foot: '<button class="btn ghost" id="pcLogout">Log out</button><button class="btn" id="pcSave">Save password</button>',
    locked: true,
    onOpen: (el, close) => {
      $('#pcLogout', el).addEventListener('click', async () => { await api('/api/auth/logout', { body: {} }).catch(() => {}); location.replace('/login'); });
      $('#pcSave', el).addEventListener('click', (e) => withBusy(e.currentTarget, async () => {
        const f = formData($('#pcForm', el));
        if (f.next !== f.repeat) throw new Error('The new passwords do not match');
        await api('/api/auth/password', { body: { current: f.current, next: f.next } });
        toast('Password updated', 'success');
        close();
        onDone?.();
      }));
    },
  });
}

// ---- staff notification bell (admin + agent). Polls the server and alerts on new items.
function initNotifications(mount, { onNew, interval = 15000, repeat = 1 } = {}) {
  mount.innerHTML = `<div class="notif">
    <button class="btn ghost sm notif-btn" aria-label="Notifications" aria-haspopup="true">🔔<span class="cart-count hidden"></span></button>
    <div class="notif-panel hidden" role="menu"></div></div>`;
  const btn = $('.notif-btn', mount);
  const count = $('.cart-count', mount);
  const panel = $('.notif-panel', mount);
  let lastId = null;
  let items = [];
  const canNotify = 'Notification' in window;
  let pushOn = false;
  Push.subscription().then((s) => { pushOn = !!s; render(); }).catch(() => {});

  const render = () => {
    const unread = items.filter((i) => !i.read_at).length;
    count.textContent = unread > 99 ? '99+' : unread;
    count.classList.toggle('hidden', !unread);
    panel.innerHTML = `<div class="notif-head"><strong>Notifications</strong>
        ${unread ? '<button class="btn ghost sm" data-readall>Mark all read</button>' : ''}</div>
      <div class="notif-enable">${Push.supported()
        ? `<button class="btn sm ${pushOn ? 'ghost' : ''}" data-push>${pushOn ? '📲 Phone/desktop alerts: ON — turn off' : '📲 Get alerts even when the app is closed'}</button>`
        : '<span class="small muted">Alerts arrive while this page is open. Install the app over HTTPS to get alerts when it is closed.</span>'}</div>
      <div class="notif-enable row between">
        <button class="btn ghost sm" data-sound>${chime.enabled() ? '🔊 Sound on' : '🔇 Sound off'}</button>
        <button class="btn ghost sm" data-sound-test>▶ Test sound</button>
      </div>
      ${items.length ? items.map((n) => `<a class="notif-item ${n.read_at ? '' : 'unread'}" href="${esc(n.link || '#')}" data-nid="${n.id}">
          <strong>${esc(n.title)}</strong><span>${esc(n.body)}</span><small>${fmtDateTime(n.created_at)}</small></a>`).join('')
        : '<div class="empty">No notifications yet.</div>'}`;
  };

  const poll = async () => {
    let r;
    try { r = await api('/api/notifications'); } catch { return; }
    items = r.items;
    const newest = items[0]?.id || 0;
    if (lastId !== null) {
      const fresh = items.filter((i) => i.id > lastId && !i.read_at).reverse();
      for (const n of fresh) {
        toast(`🔔 ${n.title}`, 'success');
        // With push on, the service worker already shows a system notification — don't show a second one.
        if (!pushOn && canNotify && Notification.permission === 'granted' && document.hidden) {
          try { new Notification(n.title, { body: n.body, tag: `aq-${n.id}` }); } catch { /* not supported on this device */ }
        }
      }
      if (fresh.length) {
        if (chime.enabled() && !chime.play(repeat)) toast('🔇 Click anywhere on the page once to allow notification sounds');
        onNew?.(fresh);
      }
    }
    lastId = Math.max(lastId ?? 0, newest);
    render();
  };

  const markRead = (ids) => api('/api/notifications/read', { body: ids ? { ids } : {} }).catch(() => {});

  btn.addEventListener('click', (e) => { e.stopPropagation(); panel.classList.toggle('hidden'); });
  document.addEventListener('click', (e) => { if (!mount.contains(e.target)) panel.classList.add('hidden'); });
  panel.addEventListener('click', async (e) => {
    if (e.target.closest('[data-push]')) {
      e.stopPropagation();
      try {
        if (pushOn) { await Push.disable(); pushOn = false; toast('Phone/desktop alerts turned off'); }
        else { await Push.enable(); pushOn = true; toast('Alerts turned on — you will be notified even when the app is closed', 'success'); }
      } catch (err) { toast(err.message, 'error'); }
      render();
      return;
    }
    // Sound buttons update in place (re-rendering would detach the clicked node and close the panel).
    const soundBtn = e.target.closest('[data-sound]');
    if (soundBtn) {
      chime.setEnabled(!chime.enabled());
      soundBtn.textContent = chime.enabled() ? '🔊 Sound on' : '🔇 Sound off';
      if (chime.enabled()) setTimeout(() => chime.play(1), 50);
      return;
    }
    if (e.target.closest('[data-sound-test]')) { setTimeout(() => chime.play(repeat, true), 50); return; }
    if (e.target.closest('[data-readall]')) {
      e.preventDefault();
      await markRead();
      items.forEach((i) => { i.read_at = i.read_at || 'now'; });
      render();
      return;
    }
    const a = e.target.closest('[data-nid]');
    if (!a) return;
    const n = items.find((i) => i.id === Number(a.dataset.nid));
    if (n && !n.read_at) { n.read_at = 'now'; markRead([n.id]); }
    panel.classList.add('hidden');
    render();
    // Same-page hash links (admin views) don't reload, so let the hashchange handler route.
  });

  poll();
  setInterval(poll, interval);
  // A push arriving while the page is open → refresh straight away instead of waiting for the next poll.
  navigator.serviceWorker?.addEventListener('message', (e) => { if (e.data?.type === 'push') poll(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
  return { refresh: poll };
}
