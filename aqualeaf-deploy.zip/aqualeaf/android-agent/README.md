# AquaLeaf Agent — Android app

A small native Android app for delivery agents. It opens your live site's `/agent` page, so every change you make to
the website shows up in the app straight away. On top of the website it adds **system notifications** for new tasks.

> The installable web app (Chrome → "Install app") already does almost everything, including push alerts.
> Build this only if you want an APK file to hand out, or a Play Store listing.

## Build the APK (one-time setup)

1. Install **Android Studio** (https://developer.android.com/studio).
2. Put the website online with HTTPS first. Then edit `capacitor.config.json` and replace `https://YOUR-DOMAIN/agent`
   with your real address.
3. In this folder run:
   ```bash
   npm install
   npm run add-android
   npm run sync
   npm run open
   ```
4. In Android Studio choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. The file is created at
   `android/app/build/outputs/apk/debug/app-debug.apk`.
5. Send the APK to each agent's phone and install it, allowing "Install unknown apps" once. On first launch,
   allow **Notifications**.

For the Play Store, use **Build → Generate Signed Bundle** instead.
