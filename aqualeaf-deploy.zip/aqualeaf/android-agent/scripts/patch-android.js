// Adds the permissions notifications need to android/app/src/main/AndroidManifest.xml.
// Runs automatically after `npm run add-android`; safe to run again.
const fs = require('fs');
const path = require('path');

const manifest = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(manifest)) {
  console.error('AndroidManifest.xml not found — run `npx cap add android` first.');
  process.exit(1);
}
const PERMS = [
  'android.permission.INTERNET',
  'android.permission.POST_NOTIFICATIONS',
];
let xml = fs.readFileSync(manifest, 'utf8');
const missing = PERMS.filter((p) => !xml.includes(`"${p}"`));
if (missing.length) {
  xml = xml.replace('</manifest>', `${missing.map((p) => `    <uses-permission android:name="${p}" />`).join('\n')}\n</manifest>`);
  fs.writeFileSync(manifest, xml);
}
console.log(missing.length ? `Added permissions: ${missing.join(', ')}` : 'Permissions already present');
