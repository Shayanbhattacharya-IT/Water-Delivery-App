# Going live: step by step

You'll need three things that only you can buy or sign up for:

| What | Example | Approx. cost |
|---|---|---|
| A domain name | `aqualeaf.in` from GoDaddy, Hostinger or Namecheap | ₹500–₹1,000 / year |
| A small server (VPS) | Hostinger KVM 1, DigitalOcean, Hetzner (1 vCPU, 1–2 GB RAM, Ubuntu 24.04) | ₹400–₹700 / month |
| SMS provider (for OTP login & customer SMS) | MSG91 (India, needs DLT registration) or Twilio | ~₹0.20–0.30 per SMS |

HTTPS certificates are **free and automatic**: Caddy gets them from Let's Encrypt.

## Option A — Your own server with Docker (recommended)

1. **Point the domain at the server.** In your domain's DNS settings, add an `A` record for `@`
   (and one for `www`) pointing to the server's IP address. Wait 5–30 minutes.
2. **Install Docker on the server** (SSH in as root):
   ```bash
   curl -fsSL https://get.docker.com | sh
   ```
3. **Copy the project to the server.** Use `git clone`, or copy the `aqualeaf` folder with WinSCP or FileZilla.
   Leave out `node_modules` and `data`.
4. **Configure it:**
   ```bash
   cd aqualeaf
   cp .env.example .env
   nano .env
   ```
   Set `DOMAIN`, `PUBLIC_URL` and `SESSION_SECRET`, plus the SMS settings when you have them.
5. **Start it:**
   ```bash
   docker compose up -d --build
   ```
   Open `https://your-domain`. The first visit can take about 30 seconds while the certificate is issued.
6. **Log in at `/login?role=admin`** with `admin@aqualeaf.local` / `admin123`. You'll be asked to set a new
   password straight away. Then:
   - Under **Settings**, set your business name, address, phone and GST number.
   - Under **Areas & time slots**, add your PIN codes and slots.
   - Under **Products**, set your real prices and can deposits.
   - Under **Staff**, change the demo agents or add your own.

### Moving your current data to the server
Your local database is `data/aqualeaf.db`. To keep the bookings you've made while testing:
```bash
docker compose cp ./data/aqualeaf.db app:/data/aqualeaf.db
docker compose restart app
```
Do this before taking real orders.

### Updating later
```bash
git pull
docker compose up -d --build
```
Your data lives in the `aqualeaf-data` Docker volume and is kept between updates.

### Backups
- **Automatic:** a daily copy goes to `/data/backups` inside the volume. The last 14 days are kept
  (set `BACKUP_KEEP_DAYS` to change that).
- **Off-site:** admin → Settings → **Download backup now**. Do this weekly and store the file in Google Drive.
  If the server dies, only the off-site copy survives.
- **Restore:** stop the app, copy a backup file over `/data/aqualeaf.db`, then start the app again.

## Option B — Render.com (no server to manage)

1. Push the project to a GitHub repository.
2. On render.com: **New → Blueprint** → choose the repo. It reads `render.yaml`.
3. Set `PUBLIC_URL` and the SMS variables, then add your custom domain in Render's settings.

The persistent disk needs a paid plan (about $7/month plus disk).

## After going live

- **Delivery agents** open `https://your-domain/login?role=agent` on their phone, tap **⬇ Install app**,
  then turn on alerts in the 🔔 bell. They're notified of new tasks even when the app is closed.
- **Optional native Android app** for tracking with the screen locked: see `android-agent/README.md`.
- **SMS:** until an SMS provider is set, customer OTP login is switched off in production. Everything else works.
  Customers can still book and track with their booking number and phone.
