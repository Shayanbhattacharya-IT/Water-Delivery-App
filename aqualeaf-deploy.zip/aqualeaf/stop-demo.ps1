# Stops the client demo processes started by start-demo.ps1 (demo server, GPS simulator, Cloudflare link).
# Your real site (port 3000, data\) is not touched.
param([switch]$Quiet)
$procs = Get-CimInstance Win32_Process | Where-Object {
  ($_.Name -eq 'node.exe' -and ($_.CommandLine -match 'demo\.env' -or $_.CommandLine -match 'demo-sim\.js')) -or
  ($_.Name -eq 'cloudflared.exe' -and $_.CommandLine -match 'localhost:3100')
}
foreach ($p in $procs) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
if (-not $Quiet) { Write-Host "Demo stopped ($(@($procs).Count) processes)." }
