# Client demo

The demo uses its **own database** (`demo-data/`). Nothing you do in it touches your real data in `data/`.
Payments in the demo use the **built-in test payment page**, so no money is taken.

**Public link:** run `start-demo.cmd`. The latest link is always in `demo-link.txt`.

## Logins (demo only)

| Role | Where | Email | Password |
|---|---|---|---|
| Admin | `/login?role=admin` | admin@aqualeaf.local | AquaDemo@2026 |
| Delivery agent | `/login?role=agent` | ravi@aqualeaf.local (or sunil@…) | AgentDemo@2026 |
| Customer | `/account` | phone 9830055555 (Sneha) or any demo customer | The 6-digit code is shown on screen (test mode) |

## Ready-made demo data

- **10 customers** on one-time, alternate-day and daily plans, all paid through Razorpay (demo references)
- Around **75 past deliveries** with invoices, plus ratings and cans with customers
- **Ishita Banerjee:** paid, **waiting for the admin to confirm**
- **Vikram Singh:** booked but **awaiting payment**
- **Sneha Iyer:** delivery **out for delivery** today
- **Delivery PIN codes:**
  - 700016 Park Street (free delivery)
  - 700019 Ballygunge (₹10)
  - 700029 Gariahat (₹10, minimum order ₹100)
  - 700091 Salt Lake (₹20, minimum order ₹150)
- **Coupons:** `WELCOME10` (10% off the first delivery) and `MONSOON20` (₹20 off every delivery)

## Suggested walkthrough (about 10 minutes)

1. **Customer books and pays.**
   - Open `/book` on a phone and add 2 × 20L cans.
   - Enter PIN **700091**, pick **Daily**, choose a slot, and apply **WELCOME10**.
   - Show the upfront total and the can deposit, then tap **Pay ₹… & book**.
   - On the test payment page, tap **Pay**. You land on "Payment received ✅".
2. **Admin is alerted.** In admin the 🔔 bell chimes: "New paid booking". Open **Bookings**, click **Confirm**,
   pick **Ravi Kumar**, and the deliveries are scheduled.
3. **Agent is alerted.** On a second phone logged in as Ravi (`/agent`), the new task appears.
   - Show **Install app**.
   - Tap **Start delivery** (the customer gets a WhatsApp update).
   - Tap **Delivered** and enter the empty cans. There's no cash, because it's prepaid. The invoice is created.
4. **Customer self-service.** Open `/account` and log in as Sneha.
   - Show **Skip / pause**: the deliveries move to the end of the plan.
   - Show bills, cans, and refer & earn.
5. **Owner's view.** In admin, show the Dashboard, **Payments** (received, awaiting, refunds), Reports, Cans &
   deposits, Ratings, Coupons, and Areas & time slots.

## Restarting the demo

In `C:\Users\SBhattacharya\claude\aqualeaf`:
- **Double-click `start-demo.cmd`** to start or restart it. After about 30 seconds the new link appears.
- On the morning of a demo, refresh the data so "today" looks right: run `start-demo.cmd -Reset`.
- **Double-click `stop-demo.cmd`** to stop it.

Keep the PC awake and online during the demo; the link stops working if it sleeps.
