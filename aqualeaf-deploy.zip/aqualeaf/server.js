'use strict';
const path = require('path');
const express = require('express');
const { port } = require('./server/config');
const { db, HttpError } = require('./server/util');
const backup = require('./server/backup');

const isProd = process.env.NODE_ENV === 'production';
const app = express();
app.disable('x-powered-by');

// Behind a reverse proxy (Caddy / Nginx / Render / Railway) trust X-Forwarded-* so req.secure and req.ip are right.
app.set('trust proxy', process.env.TRUST_PROXY ?? (isProd ? 1 : false));

app.use((req, res, next) => {
  if (process.env.FORCE_HTTPS === '1' && !req.secure && req.path !== '/healthz') {
    return res.redirect(301, `https://${req.headers.host}${req.originalUrl}`);
  }
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(self), camera=(), microphone=()');
  if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  next();
});

// Keep the raw body too: Razorpay webhook signatures are computed over the exact bytes received.
// Remember our own address so WhatsApp/SMS links are absolute even without PUBLIC_URL.
const config = require('./server/config');
app.use((req, _res, next) => {
  if (!process.env.PUBLIC_URL && !config.runtimeBaseUrl && req.get('host')) config.runtimeBaseUrl = `${req.protocol}://${req.get('host')}`;
  next();
});
app.use(express.json({ limit: '100kb', verify: (req, _res, buf) => { req.rawBody = buf; } }));
app.use((req, _res, next) => { req.body ??= {}; next(); });

// The service worker must never be cached by the browser HTTP cache, or app updates won't roll out.
app.get('/sw.js', (_req, res) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Service-Worker-Allowed', '/');
  res.sendFile(path.join(__dirname, 'public', 'sw.js'));
});
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], maxAge: isProd ? '1h' : 0 }));

app.get('/healthz', (_req, res) => {
  db.prepare('SELECT 1').get();
  res.json({ ok: true });
});

app.use('/api', require('./server/routes/public'));
app.use('/api', require('./server/routes/staff'));
app.use('/api/agent', require('./server/routes/agent').router);
app.use('/api/admin', require('./server/routes/admin'));
app.use('/api/customer', require('./server/routes/customer'));

app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, _req, res, _next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid request body' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

const server = app.listen(port, () => {
  console.log(`AquaLeaf running at http://localhost:${port}`);
  console.log(`  Shop:    http://localhost:${port}/          Book:  /book     Track: /track    Account: /account`);
  console.log(`  Admin:   http://localhost:${port}/admin     Agent: /agent`);
  if (!process.env.SMS_PROVIDER) console.log('  SMS:     not configured — OTP codes are shown on screen (local testing only)');
});
backup.startBackups();

function shutdown() {
  server.close(() => { db.close(); process.exit(0); });
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
