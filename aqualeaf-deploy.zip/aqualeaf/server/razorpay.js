// Razorpay Payment Links: create a link for a booking, verify the redirect signature and the webhook signature.
// Configure with RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET (test keys start with rzp_test_) and RAZORPAY_WEBHOOK_SECRET.
const crypto = require('crypto');

const keyId = () => process.env.RAZORPAY_KEY_ID || '';
const keySecret = () => process.env.RAZORPAY_KEY_SECRET || '';
const configured = () => !!(keyId() && keySecret());
const isTestKey = () => keyId().startsWith('rzp_test_');

const hmac = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest('hex');
function safeEqual(a, b) {
  const x = Buffer.from(String(a || '')), y = Buffer.from(String(b || ''));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

function e164(phone) {
  const digits = String(phone).replace(/[^\d]/g, '');
  return digits.length === 10 ? `+91${digits}` : `+${digits}`;
}

async function api(method, path, body) {
  const res = await fetch(`https://api.razorpay.com/v1${path}`, {
    method,
    headers: { Authorization: `Basic ${Buffer.from(`${keyId()}:${keySecret()}`).toString('base64')}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Razorpay: ${data.error?.description || res.status}`);
  return data;
}

// amount in rupees; reference must be unique per link (Razorpay rejects reused reference_ids).
async function createPaymentLink({ amount, reference, description, customer, callbackUrl, notes }) {
  const link = await api('POST', '/payment_links', {
    amount: Math.round(amount * 100),
    currency: 'INR',
    accept_partial: false,
    reference_id: reference,
    description: description.slice(0, 2048),
    customer: { name: customer.name, contact: e164(customer.phone), email: customer.email || undefined },
    notify: { sms: false, email: false }, // we send the link on WhatsApp ourselves
    reminder_enable: false,
    expire_by: Math.floor(Date.now() / 1000) + 3 * 86400,
    callback_url: callbackUrl,
    callback_method: 'get',
    notes,
  });
  return { id: link.id, url: link.short_url };
}

const fetchPaymentLink = (id) => api('GET', `/payment_links/${encodeURIComponent(id)}`);

// Query params Razorpay adds when it redirects the customer back after paying.
function verifyCallback(q) {
  if (!configured()) return false;
  const payload = `${q.razorpay_payment_link_id}|${q.razorpay_payment_link_reference_id}|${q.razorpay_payment_link_status}|${q.razorpay_payment_id}`;
  return safeEqual(hmac(keySecret(), payload), q.razorpay_signature);
}

function verifyWebhook(rawBody, signature) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret || !rawBody) return false;
  return safeEqual(hmac(secret, rawBody), signature);
}

module.exports = { configured, isTestKey, createPaymentLink, fetchPaymentLink, verifyCallback, verifyWebhook };
