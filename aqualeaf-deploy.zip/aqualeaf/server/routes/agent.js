// Delivery agent API: day's run, start / deliver (empty cans) / fail. Bookings are prepaid, so agents collect no cash.
const express = require('express');
const sch = require('../schedule');
const { one, all, fail, bad, str, round2 } = require('../util');
const B = require('../booking');
const { agentOnly } = require('../session');

const r = express.Router();
r.use(agentOnly);

function withContainers(rows) {
  for (const d of rows) {
    if (B.isOpen(d)) d.containers = B.containerPlan(d);
    else if (d.status === 'delivered') d.moves = B.deliveryMoves(d.id);
  }
  return rows;
}

r.get('/deliveries', (req, res) => {
  const date = sch.isDate(req.query.date) ? req.query.date : sch.today();
  const uid = req.user.id;
  const deliveries = withContainers(B.deliveryRows("d.agent_id = ? AND d.scheduled_date = ? AND d.status != 'cancelled'", [uid, date]));
  const summary = one(`SELECT COUNT(*) AS total, COALESCE(SUM(status = 'delivered'), 0) AS delivered,
      COALESCE(SUM(status IN ('scheduled', 'out_for_delivery')), 0) AS pending, COALESCE(SUM(status = 'failed'), 0) AS failed,
      COALESCE(SUM(CASE WHEN status = 'delivered' THEN empties_collected END), 0) AS empties
    FROM deliveries WHERE agent_id = ? AND scheduled_date = ? AND status != 'cancelled'`, uid, date);
  const overdue = withContainers(B.deliveryRows("d.agent_id = ? AND d.scheduled_date < ? AND d.status IN ('scheduled', 'out_for_delivery')",
    [uid, sch.today()], 50));
  const upcoming = all(`SELECT scheduled_date AS date, COUNT(*) AS n FROM deliveries
    WHERE agent_id = ? AND scheduled_date > ? AND status = 'scheduled' GROUP BY scheduled_date ORDER BY scheduled_date LIMIT 7`, uid, sch.today());
  const rating = one('SELECT ROUND(AVG(rating), 1) AS avg, COUNT(*) AS n FROM ratings WHERE agent_id = ?', uid);
  res.json({ date, today: sch.today(), deliveries, summary, overdue, upcoming, rating });
});

function ownDelivery(req) {
  const d = B.getDelivery(req.params.id);
  if (d.agent_id !== req.user.id) fail(403, 'This delivery is not assigned to you');
  return d;
}

r.post('/deliveries/:id/start', (req, res) => { B.startDelivery(ownDelivery(req)); res.json({ ok: true }); });

// Preview any can deposit still uncovered for a given number of empties (normally ₹0 — deposits are paid online).
r.post('/deliveries/:id/preview', (req, res) => {
  const plan = B.containerPlan(ownDelivery(req), req.body.empties);
  res.json({ containers: plan, deposit_due: round2(plan.reduce((s, p) => s + p.deposit_amount, 0)) });
});

r.post('/deliveries/:id/deliver', (req, res) => {
  const d = ownDelivery(req);
  B.markDelivered(d, { empties: req.body.empties });
  res.json(one('SELECT id, invoice_no, deposit_amount, empties_collected FROM deliveries WHERE id = ?', d.id));
});

r.post('/deliveries/:id/fail', (req, res) => {
  const note = str(req.body.note, 300);
  if (!note) bad('Please give a reason');
  B.failDelivery(ownDelivery(req), note, { alertAdmins: true });
  res.json({ ok: true });
});

module.exports = { router: r };
