// Staff login, password, in-app notifications and Web Push subscriptions (admins + agents).
const express = require('express');
const auth = require('../auth');
const { one, all, run, fail, bad, str, intId, localNow, rateLimit } = require('../util');
const { publicUser, staff, staffAllowStale } = require('../session');
const { vapidPublicKey } = require('../notify');

const r = express.Router();
const DEMO_PASSWORDS = ['admin123', 'agent123', 'password', '123456'];

r.post('/auth/login', (req, res) => {
  rateLimit(`login:${req.ip}`, 10, 15 * 60e3, 'Too many login attempts. Try again in 15 minutes.');
  const email = str(req.body.email, 120).toLowerCase();
  const u = one('SELECT * FROM users WHERE email = ?', email);
  if (!u || !u.active || !auth.verifyPassword(String(req.body.password ?? ''), u.password_hash)) fail(401, 'Incorrect email or password');
  res.setHeader('Set-Cookie', auth.sessionCookie(u.id, req.secure));
  res.json({ user: publicUser(u) });
});

r.post('/auth/logout', (req, res) => {
  res.setHeader('Set-Cookie', auth.clearCookie(req.secure));
  res.json({ ok: true });
});

r.get('/auth/me', staffAllowStale, (req, res) => res.json({ user: publicUser(req.user) }));

r.post('/auth/password', staffAllowStale, (req, res) => {
  rateLimit(`pw:${req.user.id}`, 10, 15 * 60e3);
  if (!auth.verifyPassword(String(req.body.current ?? ''), req.user.password_hash)) bad('Current password is incorrect');
  const next = String(req.body.next ?? '');
  if (next.length < 8) bad('New password must be at least 8 characters');
  if (DEMO_PASSWORDS.includes(next.toLowerCase())) bad('Please choose a less common password');
  if (next === req.body.current) bad('New password must be different from the current one');
  run('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?', auth.hashPassword(next), req.user.id);
  res.json({ ok: true });
});

r.get('/notifications', staff, (req, res) => {
  res.json({
    unread: one('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL', req.user.id).n,
    items: all('SELECT id, title, body, link, read_at, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 30', req.user.id),
  });
});

r.post('/notifications/read', staff, (req, res) => {
  const ids = Array.isArray(req.body.ids) ? req.body.ids.map(intId).filter(Boolean).slice(0, 100) : null;
  if (ids && !ids.length) return res.json({ ok: true });
  run(`UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL${ids ? ` AND id IN (${ids.map(() => '?').join(',')})` : ''}`,
    localNow(), req.user.id, ...(ids || []));
  res.json({ ok: true });
});

r.get('/push/key', staff, (_req, res) => res.json({ key: vapidPublicKey }));

r.post('/push/subscribe', staff, (req, res) => {
  const s = req.body.subscription || {};
  const endpoint = str(s.endpoint, 1000);
  const p256dh = str(s.keys?.p256dh, 200);
  const authKey = str(s.keys?.auth, 100);
  if (!/^https:\/\//.test(endpoint) || !p256dh || !authKey) bad('Invalid push subscription');
  run(`INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth) VALUES (?, ?, ?, ?)
    ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth`,
  req.user.id, endpoint, p256dh, authKey);
  res.json({ ok: true });
});

r.post('/push/unsubscribe', staff, (req, res) => {
  run('DELETE FROM push_subscriptions WHERE endpoint = ? AND user_id = ?', str(req.body.endpoint, 1000), req.user.id);
  res.json({ ok: true });
});

module.exports = r;
