// Customer self-service: OTP login by phone, profile, bookings, bills, cans, referral, and subscription controls.
const crypto = require('crypto');
const express = require('express');
const auth = require('../auth');
const sch = require('../schedule');
const {
  one, all, run, tx, fail, bad, str, intId, round2, cleanPhone, isEmail, rateLimit, setting, numSetting, fmtDate, getSettings, localNow,
} = require('../util');
const B = require('../booking');
const { notify, notifyAdmins } = require('../notify');
const { sendOtp, otpConfigured } = require('../messaging');
const { requireCustomer, currentCustomer } = require('../session');
const { demoMode } = require('../config');

const r = express.Router();
const OTP_TTL = 10 * 60e3;
const isProd = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------- OTP login
r.post('/otp', async (req, res) => {
  const phone = cleanPhone(req.body.phone);
  if (!/^\+?\d{10,15}$/.test(phone)) bad('Enter the mobile number you booked with');
  rateLimit(`otp-ip:${req.ip}`, 20, 3600e3);
  rateLimit(`otp:${phone}`, 5, 3600e3, 'Too many codes requested for this number. Try again in an hour.');
  if (!one('SELECT 1 FROM customers WHERE phone = ?', phone)) {
    fail(404, "We couldn't find a booking with this number. Book a delivery first — your account is created automatically.");
  }
  const prev = one('SELECT sent_at FROM otp_codes WHERE phone = ?', phone);
  if (prev && Date.now() - prev.sent_at < 30e3) fail(429, 'Please wait 30 seconds before requesting a new code');
  const showCode = !otpConfigured() && (!isProd || demoMode);
  if (!otpConfigured() && !showCode) fail(503, 'Login codes are not available yet. Please contact us.');

  const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0');
  run(`INSERT INTO otp_codes (phone, code_hash, expires_at, attempts, sent_at) VALUES (?, ?, ?, 0, ?)
    ON CONFLICT(phone) DO UPDATE SET code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0, sent_at = excluded.sent_at`,
  phone, auth.hashPassword(code), Date.now() + OTP_TTL, Date.now());
  let channel = null;
  try {
    channel = await sendOtp(phone, code, setting('business_name'));
  } catch (e) {
    console.error(`[otp] ${e.message}`);
    fail(502, 'Could not send the login code. Please try again in a minute.');
  }
  // Without WhatsApp/SMS configured (local testing / demo only) the code is returned so you can log in.
  res.json({ ok: true, channel, ...(showCode ? { dev_code: code } : {}) });
});

r.post('/verify', (req, res) => {
  const phone = cleanPhone(req.body.phone);
  const code = str(req.body.code, 6);
  rateLimit(`verify-ip:${req.ip}`, 30, 600e3);
  const rec = one('SELECT * FROM otp_codes WHERE phone = ?', phone);
  if (!rec || rec.expires_at < Date.now()) bad('This code has expired — please request a new one');
  if (rec.attempts >= 5) { run('DELETE FROM otp_codes WHERE phone = ?', phone); bad('Too many wrong attempts — please request a new code'); }
  if (!/^\d{6}$/.test(code) || !auth.verifyPassword(code, rec.code_hash)) {
    run('UPDATE otp_codes SET attempts = attempts + 1 WHERE phone = ?', phone);
    bad('Incorrect code');
  }
  run('DELETE FROM otp_codes WHERE phone = ?', phone);
  const c = one('SELECT id FROM customers WHERE phone = ?', phone);
  res.setHeader('Set-Cookie', auth.customerCookie(c.id, req.secure));
  res.json({ ok: true });
});

r.post('/logout', (req, res) => {
  res.setHeader('Set-Cookie', auth.clearCustomerCookie(req.secure));
  res.json({ ok: true });
});

r.get('/session', (req, res) => {
  const c = currentCustomer(req);
  res.json(c ? { logged_in: true, customer: { name: c.name, phone: c.phone, email: c.email, address: c.address, line_no: c.line_no, pincode: c.pincode } }
    : { logged_in: false });
});

// ---------------------------------------------------------------- account
r.use(requireCustomer);

r.get('/me', (req, res) => {
  const c = req.customer;
  const t = sch.today();
  const bookings = all(`SELECT b.id, b.booking_no, b.tracking_id, b.frequency, b.status, b.start_date, b.end_date, b.delivery_time,
      b.amount_per_delivery, b.coupon_code, b.discount, b.slot_id, b.payment_status, b.total_amount, b.paid_amount, b.refunded_amount,
      u.name AS agent_name, s.start_time AS slot_start, s.end_time AS slot_end,
      (SELECT MIN(scheduled_date) FROM deliveries d WHERE d.booking_id = b.id AND d.status IN ('scheduled', 'out_for_delivery') AND d.scheduled_date >= ?) AS next_date,
      (SELECT COUNT(*) FROM deliveries d WHERE d.booking_id = b.id AND d.status = 'delivered') AS delivered_count,
      (SELECT COUNT(*) FROM deliveries d WHERE d.booking_id = b.id AND d.status IN ('scheduled', 'out_for_delivery')) AS open_count
    FROM bookings b LEFT JOIN users u ON u.id = b.agent_id LEFT JOIN time_slots s ON s.id = b.slot_id
    WHERE b.customer_id = ? ORDER BY b.id DESC`, t, c.id);
  const items = bookings.length
    ? all(`SELECT booking_id, name, quantity FROM booking_items WHERE booking_id IN (${bookings.map(() => '?').join(',')})`, ...bookings.map((b) => b.id))
    : [];
  for (const b of bookings) b.items = items.filter((i) => i.booking_id === b.id);
  const bills = all(`SELECT d.id, d.scheduled_date, d.delivered_at, d.invoice_no, d.amount, d.deposit_amount, d.collected, b.booking_no, b.tracking_id,
      r.rating FROM deliveries d JOIN bookings b ON b.id = d.booking_id LEFT JOIN ratings r ON r.delivery_id = d.id
    WHERE b.customer_id = ? AND d.status = 'delivered' ORDER BY d.scheduled_date DESC, d.id DESC LIMIT 60`, c.id);
  const totals = one(`SELECT COALESCE(SUM(d.amount), 0) AS billed, COALESCE(SUM(d.deposit_amount), 0) AS deposits,
      COALESCE(SUM(d.collected), 0) AS collected FROM deliveries d JOIN bookings b ON b.id = d.booking_id
    WHERE b.customer_id = ? AND d.status = 'delivered'`, c.id);
  totals.due = round2(totals.billed + totals.deposits - totals.collected);
  const containers = all(`SELECT p.name, cc.held, cc.deposit_units, p.deposit FROM customer_containers cc JOIN products p ON p.id = cc.product_id
    WHERE cc.customer_id = ? AND (cc.held > 0 OR cc.deposit_units > 0)`, c.id);
  const coupons = all(`SELECT code, description, type, value, scope, valid_to FROM coupons
    WHERE customer_id = ? AND active = 1 AND (valid_to IS NULL OR valid_to >= ?)
    AND (usage_limit = 0 OR (SELECT COUNT(*) FROM bookings bk WHERE bk.coupon_code = coupons.code AND bk.status != 'cancelled') < usage_limit)`, c.id, t);
  const referrals = one(`SELECT COUNT(DISTINCT customer_id) AS n FROM bookings WHERE referred_by = ?`, c.id).n;
  res.json({
    customer: { name: c.name, phone: c.phone, email: c.email, address: c.address, line_no: c.line_no, pincode: c.pincode, referral_code: c.referral_code },
    bookings, bills, totals, containers, coupons, referrals,
    referral: { discount: numSetting('referral_discount', 50), reward: numSetting('referral_reward', 50) },
    settings: getSettings(),
  });
});

r.put('/me', (req, res) => {
  const name = str(req.body.name, 100), email = str(req.body.email, 120).toLowerCase();
  const address = str(req.body.address, 500), lineNo = str(req.body.line_no, 50), pincode = str(req.body.pincode, 10);
  if (!name) bad('Name is required');
  if (!isEmail(email)) bad('Enter a valid email');
  if (address.length < 5) bad('Address is required');
  if (pincode && !/^\d{4,10}$/.test(pincode)) bad('Enter a valid PIN code');
  run('UPDATE customers SET name = ?, email = ?, address = ?, line_no = ?, pincode = ?, updated_at = ? WHERE id = ?',
    name, email, address, lineNo, pincode, localNow(), req.customer.id);
  // Upcoming deliveries go to the new address.
  if (req.body.apply_to_bookings) {
    run(`UPDATE bookings SET name = ?, email = ?, address = ?, line_no = ?, pincode = COALESCE(NULLIF(?, ''), pincode)
      WHERE customer_id = ? AND status IN ('pending', 'confirmed')`, name, email, address, lineNo, pincode, req.customer.id);
  }
  res.json({ ok: true });
});

function ownBooking(req) {
  const b = one('SELECT * FROM bookings WHERE id = ? AND customer_id = ?', intId(req.params.id), req.customer.id);
  if (!b) fail(404, 'Booking not found');
  return b;
}

r.get('/bookings/:id/deliveries', (req, res) => {
  const b = ownBooking(req);
  res.json({
    cutoff: sch.addDays(sch.today(), 1),
    deliveries: all(`SELECT id, seq, scheduled_date, scheduled_time, status, amount, note FROM deliveries
      WHERE booking_id = ? AND scheduled_date >= ? ORDER BY scheduled_date LIMIT 120`, b.id, sch.today()),
  });
});

// Tell the assigned agents and the admins about customer changes.
function announce(b, title, body, agentIds) {
  notifyAdmins(title, `${b.name} · ${body}`, '/admin#bookings');
  notify(agentIds, title, `${b.name}, ${b.address} · ${body}`, '/agent');
}
const changeable = (b) => {
  if (b.status !== 'confirmed') bad('Only active bookings can be changed');
  if (b.frequency === 'once') bad('One-time deliveries can be changed by calling us');
};

// Prepaid plans: skipping moves the delivery to the end of the plan, so nothing paid for is lost.
r.post('/bookings/:id/skip', (req, res) => {
  const b = ownBooking(req);
  changeable(b);
  const d = one("SELECT * FROM deliveries WHERE id = ? AND booking_id = ? AND status = 'scheduled'", intId(req.body.delivery_id), b.id);
  if (!d) bad('This delivery cannot be skipped');
  if (d.scheduled_date <= sch.today()) bad("Today's delivery can't be skipped online — please call us");
  const newDate = tx(() => B.moveToEnd(d, 'Skipped by customer — moved to end of plan'));
  announce(b, `Delivery skipped: ${b.booking_no}`, `${fmtDate(d.scheduled_date)} moved to ${fmtDate(newDate)}`, [d.agent_id]);
  res.json({ ok: true, moved_to: newDate });
});

r.post('/bookings/:id/pause', (req, res) => {
  const b = ownBooking(req);
  changeable(b);
  const from = str(req.body.from, 10), to = str(req.body.to, 10);
  if (!sch.isDate(from) || !sch.isDate(to) || to < from) bad('Choose the dates to pause');
  if (from <= sch.today()) bad('Pauses can start from tomorrow');
  const affected = all(`SELECT * FROM deliveries WHERE booking_id = ? AND status = 'scheduled' AND scheduled_date BETWEEN ? AND ?
    ORDER BY scheduled_date`, b.id, from, to);
  if (!affected.length) bad('There are no deliveries in those dates');
  const lastDate = tx(() => {
    let last = null;
    for (const d of affected) last = B.moveToEnd({ ...d, scheduled_date: to }, 'Paused by customer — moved to end of plan');
    return last;
  });
  announce(b, `Subscription paused: ${b.booking_no}`,
    `paused ${fmtDate(from)} – ${fmtDate(to)} (${affected.length} deliveries moved; plan now ends ${fmtDate(lastDate)})`, affected.map((a) => a.agent_id));
  res.json({ ok: true, paused: affected.length, ends: lastDate });
});

// Cancelling a paid booking stops future deliveries; the admin is asked to refund the undelivered amount via Razorpay.
r.post('/bookings/:id/cancel', (req, res) => {
  const b = ownBooking(req);
  if (!['pending', 'confirmed'].includes(b.status)) bad(`This booking is already ${b.status}`);
  const t = sch.today();
  const agents = all("SELECT DISTINCT agent_id FROM deliveries WHERE booking_id = ? AND status = 'scheduled' AND scheduled_date > ?", b.id, t)
    .map((a) => a.agent_id);
  const refund = round2(one(`SELECT COALESCE(SUM(amount), 0) AS n FROM deliveries WHERE booking_id = ? AND status = 'scheduled' AND scheduled_date > ?`, b.id, t).n
    + (b.status === 'pending' && b.payment_status === 'paid' ? b.total_amount : 0));
  tx(() => {
    // Today's delivery (if any) is left for the agent; everything from tomorrow is cancelled.
    run("UPDATE deliveries SET status = 'cancelled', note = 'Cancelled by customer' WHERE booking_id = ? AND status = 'scheduled' AND scheduled_date > ?", b.id, t);
    const open = one("SELECT COUNT(*) AS n FROM deliveries WHERE booking_id = ? AND status IN ('scheduled', 'out_for_delivery')", b.id).n;
    if (b.status === 'pending' || open === 0) run("UPDATE bookings SET status = 'cancelled' WHERE id = ?", b.id);
    else run('UPDATE bookings SET end_date = ? WHERE id = ?', t, b.id);
  });
  const paid = b.payment_status === 'paid';
  announce(b, `Booking cancelled by customer: ${b.booking_no}`,
    paid && refund > 0 ? `cancelled upcoming deliveries — refund ${setting('currency')}${refund} via Razorpay` : 'cancelled upcoming deliveries', agents);
  res.json({ ok: true, refund: paid ? refund : 0 });
});

r.get('/statement', (req, res) => {
  const c = req.customer;
  const t = sch.today();
  const from = sch.isDate(req.query.from) ? req.query.from : `${t.slice(0, 7)}-01`;
  const to = sch.isDate(req.query.to) ? req.query.to : t;
  if (to < from) bad('“To” date must be after “From” date');
  const rows = B.deliveryRows("b.customer_id = ? AND d.scheduled_date BETWEEN ? AND ? AND d.status IN ('delivered', 'failed')", [c.id, from, to], 5000);
  const delivered = rows.filter((x) => x.status === 'delivered');
  const billed = round2(delivered.reduce((s, x) => s + x.amount, 0));
  const deposits = round2(delivered.reduce((s, x) => s + x.deposit_amount, 0));
  const collected = round2(delivered.reduce((s, x) => s + x.collected, 0));
  const previousDue = round2(one(`SELECT COALESCE(SUM(d.amount + d.deposit_amount) - SUM(d.collected), 0) AS n FROM deliveries d
    JOIN bookings b ON b.id = d.booking_id WHERE b.customer_id = ? AND d.status = 'delivered' AND d.scheduled_date < ?`, c.id, from).n);
  res.json({ customer: c, from, to, rows, billed, deposits, collected, previousDue, due: round2(previousDue + billed + deposits - collected), settings: getSettings() });
});

module.exports = r;
