// Public (no login): catalogue, delivery areas & slots, price quotes, booking + Razorpay payment, tracking, ratings, invoices.
const express = require('express');
const sch = require('../schedule');
const {
  one, all, run, fail, bad, str, intId, round2, cleanPhone, getSettings, fmtDate, rateLimit, setting, esc,
} = require('../util');
const B = require('../booking');
const P = require('../payments');
const razorpay = require('../razorpay');
const { notifyAdmins } = require('../notify');
const { currentUser, currentCustomer } = require('../session');
const { otpConfigured } = require('../messaging');

const r = express.Router();
const PUBLIC_SETTINGS = ['business_name', 'tagline', 'phone', 'email', 'address', 'currency', 'tax_id', 'invoice_note',
  'default_delivery_charge', 'default_min_order', 'same_day_cutoff_minutes', 'referral_discount', 'referral_reward'];

r.get('/settings', (_req, res) => {
  const s = getSettings();
  res.json({ ...Object.fromEntries(PUBLIC_SETTINGS.map((k) => [k, s[k] ?? ''])), areas_restricted: B.areasRestricted(),
    payment_mode: P.mode(), plans: B.FREQUENCIES, otp_enabled: otpConfigured() });
});

r.get('/products', (_req, res) => {
  res.json(all(`SELECT id, name, category, type, unit, price, description, stock, returnable, deposit
    FROM products WHERE active = 1 ORDER BY sort, name`));
});

r.get('/areas/check', (req, res) => {
  const pin = str(req.query.pincode, 10);
  if (!/^\d{4,10}$/.test(pin)) bad('Enter a valid PIN code');
  const a = B.areaFor(pin);
  if (!a) fail(404, `Sorry, we don't deliver to PIN code ${pin} yet`);
  res.json(a);
});

r.get('/slots', (req, res) => {
  const date = sch.isDate(req.query.date) ? req.query.date : sch.today();
  res.json({ date, slots: B.slotsForDate(date) });
});

r.post('/quote', (req, res) => {
  rateLimit(`quote:${req.ip}`, 120, 60e3);
  res.json(B.quote(req.body));
});

// Booking → payment: the booking is saved as "awaiting payment" and the customer is sent to pay the full amount.
r.post('/bookings', async (req, res) => {
  rateLimit(`book:${req.ip}`, 15, 3600e3, 'Too many bookings from this connection. Please call us to book.');
  const id = B.createBooking(B.parseBooking(req.body));
  const b = one('SELECT * FROM bookings WHERE id = ?', id);
  let payUrl = null, payError = null;
  try { payUrl = await P.paymentUrl(b, req); } catch (e) { payError = e.message; }
  res.status(201).json({ booking_no: b.booking_no, tracking_id: b.tracking_id, phone: b.phone, total: b.total_amount, pay_url: payUrl, pay_error: payError });
});

// "Pay now" again (e.g. the customer closed the payment page): booking number + phone.
r.post('/bookings/pay', async (req, res) => {
  rateLimit(`pay:${req.ip}`, 30, 600e3);
  const b = one('SELECT * FROM bookings WHERE booking_no = ? AND phone = ?', str(req.body.booking_no, 20).toUpperCase(), cleanPhone(req.body.phone));
  if (!b) fail(404, 'No booking matches this booking number and phone');
  if (b.payment_status !== 'unpaid') return res.json({ paid: true, tracking_id: b.tracking_id });
  res.json({ paid: false, pay_url: await P.paymentUrl(b, req) });
});

r.post('/track/lookup', (req, res) => {
  rateLimit(`lookup:${req.ip}`, 30, 600e3);
  const b = one('SELECT booking_no, status, tracking_id, payment_status FROM bookings WHERE booking_no = ? AND phone = ?',
    str(req.body.booking_no, 20).toUpperCase(), cleanPhone(req.body.phone));
  if (!b) fail(404, 'No booking matches this booking number and phone');
  res.json(b);
});

// ---------------------------------------------------------------- Razorpay
// Customer is redirected here after paying on Razorpay.
r.get('/payments/razorpay/callback', async (req, res) => {
  const q = req.query;
  const b = q.razorpay_payment_link_id ? P.bookingByLink(String(q.razorpay_payment_link_id)) : null;
  if (!b) return res.redirect('/track?payment=unknown');
  if (q.razorpay_payment_link_status === 'paid' && razorpay.verifyCallback(q)) {
    let amount = b.total_amount;
    try { const link = await razorpay.fetchPaymentLink(b.payment_link_id); amount = (link.amount_paid || link.amount) / 100; } catch { /* keep booking total */ }
    B.markPaid(b.id, { amount, reference: String(q.razorpay_payment_id) });
    return res.redirect(`/track?id=${b.tracking_id}&paid=1`);
  }
  res.redirect(`/track?id=${b.tracking_id}&payment=failed`);
});

// Server-to-server confirmation from Razorpay (covers customers who close the page before the redirect).
r.post('/payments/razorpay/webhook', (req, res) => {
  if (!razorpay.verifyWebhook(req.rawBody, req.get('x-razorpay-signature'))) return res.status(400).json({ error: 'Invalid signature' });
  const ev = req.body;
  if (ev.event === 'payment_link.paid') {
    const link = ev.payload?.payment_link?.entity || {};
    const payment = ev.payload?.payment?.entity || {};
    const b = P.bookingByLink(link.id);
    if (b) B.markPaid(b.id, { amount: (link.amount_paid || payment.amount || 0) / 100 || b.total_amount, reference: payment.id || link.id });
  }
  res.json({ ok: true });
});

// ---------------------------------------------------------------- test payments (only until Razorpay keys are added)
function testBooking(q) {
  if (!P.testMode()) fail(404, 'Not found');
  const b = one('SELECT * FROM bookings WHERE booking_no = ?', str(q.b, 20));
  if (!b || str(q.t, 100) !== P.testToken(b.booking_no)) fail(403, 'Invalid payment link');
  return b;
}
r.get('/payments/test', (req, res) => {
  const b = testBooking(req.query);
  const cur = setting('currency', '₹');
  const amount = b.total_amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  res.type('html').send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test payment</title><link rel="stylesheet" href="/css/style.css"></head><body>
  <div class="login-wrap"><div class="card login-card" style="max-width:440px">
    <div class="alert warn" style="margin-bottom:14px"><strong>Test payment.</strong> Razorpay keys are not set up yet, so no real money is taken.
      Once keys are added, customers see the real Razorpay page (UPI, cards, net banking, wallets) here.</div>
    <h1 style="font-size:1.3rem">${esc(setting('business_name'))}</h1>
    <p class="muted">Booking <strong>${esc(b.booking_no)}</strong> · ${esc(b.name)}</p>
    <div class="stat" style="margin:10px 0 18px"><span class="label">Amount to pay</span><span class="value">${esc(cur)}${amount}</span></div>
    ${b.payment_status === 'unpaid' ? `<button class="btn green block" id="pay">Pay ${esc(cur)}${amount} (test)</button>
      <button class="btn ghost block" id="cancel" style="margin-top:10px">Cancel payment</button>` : '<div class="alert">This booking is already paid.</div>'}
  </div></div>
  <script>
    const go = (outcome) => fetch('/api/payments/test/complete', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ b: ${JSON.stringify(b.booking_no)}, t: ${JSON.stringify(req.query.t)}, outcome }) }).then((r) => r.json()).then((d) => { location.href = d.redirect; });
    document.getElementById('pay')?.addEventListener('click', (e) => { e.target.disabled = true; e.target.textContent = 'Processing…'; go('paid'); });
    document.getElementById('cancel')?.addEventListener('click', () => go('cancelled'));
  </script></body></html>`);
});
r.post('/payments/test/complete', (req, res) => {
  const b = testBooking(req.body);
  if (req.body.outcome === 'paid') {
    B.markPaid(b.id, { amount: b.total_amount, reference: `TEST-${Date.now().toString(36).toUpperCase()}` });
    return res.json({ redirect: `/track?id=${b.tracking_id}&paid=1` });
  }
  res.json({ redirect: `/track?id=${b.tracking_id}&payment=failed` });
});

// ---------------------------------------------------------------- tracking & ratings
function bookingByTid(tid) {
  const b = one(`SELECT b.*, u.name AS agent_name, u.phone AS agent_phone, s.label AS slot_label, s.start_time AS slot_start, s.end_time AS slot_end
    FROM bookings b LEFT JOIN users u ON u.id = b.agent_id LEFT JOIN time_slots s ON s.id = b.slot_id
    WHERE b.tracking_id = ?`, str(tid, 20).toUpperCase());
  if (!b) fail(404, 'No booking found for this tracking ID');
  return b;
}

r.get('/track/:tid', (req, res) => {
  const b = bookingByTid(req.params.tid);
  const items = all('SELECT name, unit, price, quantity FROM booking_items WHERE booking_id = ?', b.id);
  const deliveries = all(`SELECT d.id, d.seq, d.scheduled_date, d.scheduled_time, d.status, d.amount, d.deposit_amount, d.collected,
      d.invoice_no, d.started_at, d.delivered_at, d.note, u.name AS agent_name, u.phone AS agent_phone,
      s.start_time AS slot_start, s.end_time AS slot_end, r.rating, r.comment AS rating_comment
    FROM deliveries d LEFT JOIN users u ON u.id = d.agent_id LEFT JOIN time_slots s ON s.id = d.slot_id
    LEFT JOIN ratings r ON r.delivery_id = d.id WHERE d.booking_id = ? ORDER BY d.scheduled_date, d.seq`, b.id);
  const t = sch.today();
  const active = deliveries.find((d) => d.status === 'out_for_delivery')
    || deliveries.find((d) => d.status === 'scheduled' && d.scheduled_date >= t) || null;
  const containers = all(`SELECT p.name, c.held, c.deposit_units, p.deposit FROM customer_containers c JOIN products p ON p.id = c.product_id
    WHERE c.customer_id = ? AND (c.held > 0 OR c.deposit_units > 0)`, b.customer_id);
  const ownsIt = currentCustomer(req)?.id === b.customer_id;
  for (const k of ['customer_id', 'agent_id', 'id', 'referred_by', 'payment_link_id', 'payment_link_url']) delete b[k];
  res.json({ booking: b, items, active, deliveries, containers, settings: getSettings(), logged_in: ownsIt, payment_mode: P.mode() });
});

r.post('/track/:tid/rate', (req, res) => {
  rateLimit(`rate:${req.ip}`, 30, 3600e3);
  const b = bookingByTid(req.params.tid);
  const d = one("SELECT * FROM deliveries WHERE id = ? AND booking_id = ? AND status = 'delivered'", intId(req.body.delivery_id), b.id);
  if (!d) bad('You can rate a delivery once it has been completed');
  if (one('SELECT 1 FROM ratings WHERE delivery_id = ?', d.id)) bad('You have already rated this delivery — thank you!');
  const rating = Number(req.body.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) bad('Choose 1 to 5 stars');
  const comment = str(req.body.comment, 500);
  run('INSERT INTO ratings (delivery_id, booking_id, customer_id, agent_id, rating, comment) VALUES (?, ?, ?, ?, ?, ?)',
    d.id, b.id, b.customer_id, d.agent_id, rating, comment);
  if (rating <= 2) {
    notifyAdmins(`⚠️ ${rating}★ rating: ${b.booking_no}`, `${b.name} on ${fmtDate(d.scheduled_date)}${comment ? `: "${comment}"` : ''}`, '/admin#ratings');
  }
  res.json({ ok: true });
});

// Invoice for a completed delivery: admin, the delivering agent, the customer (logged in) or anyone with the tracking ID.
r.get('/invoice/:id', (req, res) => {
  const d = one(`SELECT d.*, b.booking_no, b.tracking_id, b.customer_id, b.name, b.phone, b.email, b.address, b.line_no, b.pincode,
      b.frequency, b.payment_method, b.payment_status, b.payment_ref, b.paid_at, b.delivery_charge, b.coupon_code, b.discount, b.discount_scope,
      u.name AS agent_name
    FROM deliveries d JOIN bookings b ON b.id = d.booking_id LEFT JOIN users u ON u.id = d.agent_id WHERE d.id = ?`, intId(req.params.id));
  if (!d) fail(404, 'Invoice not found');
  const user = currentUser(req);
  const allowed = (user && (user.role === 'admin' || user.id === d.agent_id))
    || currentCustomer(req)?.id === d.customer_id
    || (req.query.t && String(req.query.t).toUpperCase() === d.tracking_id);
  if (!allowed) fail(403, 'You do not have access to this invoice');
  if (d.status !== 'delivered') bad('The invoice is generated once the delivery is completed');
  const items = all('SELECT name, unit, price, quantity FROM booking_items WHERE booking_id = ?', d.booking_id);
  const subtotal = round2(items.reduce((s, i) => s + i.price * i.quantity, 0));
  const moves = all(`SELECT p.name, m.delivered, m.collected, m.deposit_units, m.deposit_amount FROM container_moves m
    JOIN products p ON p.id = m.product_id WHERE m.delivery_id = ?`, d.id);
  delete d.customer_id;
  res.json({ delivery: d, items, subtotal, discount: round2(subtotal + d.delivery_charge - d.amount), moves, settings: getSettings() });
});

module.exports = r;
