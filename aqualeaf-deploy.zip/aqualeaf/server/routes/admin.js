// Admin API.
const express = require('express');
const path = require('path');
const fs = require('fs');
const auth = require('../auth');
const sch = require('../schedule');
const { dataDir } = require('../config');
const {
  db, one, all, run, tx, fail, bad, str, intId, round2, localNow, isEmail, isTime, fmtDate, getSettings, FREQ_LABEL,
} = require('../util');
const B = require('../booking');
const { notify } = require('../notify');
const { adminOnly, publicUser } = require('../session');
const P = require('../payments');
const backup = require('../backup');

const r = express.Router();
r.use(adminOnly);

const PRODUCT_TYPES = ['can', 'bottle', 'box', 'jar', 'leafy', 'herb', 'tomato', 'microgreens'];
const SETTING_KEYS = ['business_name', 'tagline', 'phone', 'email', 'address', 'currency', 'tax_id', 'invoice_note',
  'default_delivery_charge', 'default_min_order', 'same_day_cutoff_minutes', 'referral_discount', 'referral_reward'];
const NUMERIC_SETTINGS = ['default_delivery_charge', 'default_min_order', 'same_day_cutoff_minutes', 'referral_discount', 'referral_reward'];
const flag = (v) => (v === false || v === 0 || v === '0' || v === 'off' ? 0 : 1);
const num = (v, label, { min = 0, int = false } = {}) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || (int && !Number.isInteger(n))) bad(`Enter a valid ${label}`);
  return int ? n : round2(n);
};

// ---------------------------------------------------------------- dashboard
r.get('/stats', (_req, res) => {
  const t = sch.today();
  res.json({
    today: t,
    todayDeliveries: one(`SELECT COUNT(*) AS total, COALESCE(SUM(status = 'delivered'), 0) AS delivered,
        COALESCE(SUM(status = 'out_for_delivery'), 0) AS onroute, COALESCE(SUM(status = 'scheduled'), 0) AS scheduled,
        COALESCE(SUM(status = 'failed'), 0) AS failed
      FROM deliveries WHERE scheduled_date = ? AND status != 'cancelled'`, t),
    pendingBookings: one("SELECT COUNT(*) AS n FROM bookings WHERE status = 'pending' AND payment_status IN ('paid', 'cod')").n,
    awaitingPayment: one("SELECT COUNT(*) AS n FROM bookings WHERE status = 'pending' AND payment_status = 'unpaid'").n,
    activeSubscriptions: one("SELECT COUNT(*) AS n FROM bookings WHERE status = 'confirmed' AND frequency != 'once'").n,
    paidToday: one("SELECT COUNT(*) AS n, COALESCE(SUM(paid_amount), 0) AS amount FROM bookings WHERE payment_status IN ('paid', 'refunded', 'partially_refunded') AND date(paid_at) = ?", t),
    month: one(`SELECT COUNT(*) AS n, COALESCE(SUM(paid_amount), 0) AS paid, COALESCE(SUM(refunded_amount), 0) AS refunded FROM bookings
      WHERE payment_status IN ('paid', 'refunded', 'partially_refunded') AND substr(paid_at, 1, 7) = ?`, t.slice(0, 7)),
    monthDelivered: one(`SELECT COUNT(*) AS n FROM deliveries WHERE status = 'delivered' AND substr(scheduled_date, 1, 7) = ?`, t.slice(0, 7)).n,
    toRefund: one(`SELECT COUNT(*) AS n FROM bookings b WHERE b.payment_status = 'paid' AND b.status = 'cancelled'`).n,
    customers: one('SELECT COUNT(*) AS n FROM customers').n,
    cansOut: one('SELECT COALESCE(SUM(held), 0) AS n FROM customer_containers').n,
    rating: one('SELECT ROUND(AVG(rating), 1) AS avg, COUNT(*) AS n FROM ratings'),
    lowStock: all('SELECT id, name, stock FROM products WHERE active = 1 AND stock <= 10 ORDER BY stock'),
    recent: all(`SELECT id, booking_no, name, frequency, status, start_date, amount_per_delivery, total_amount, payment_status, created_at
      FROM bookings ORDER BY id DESC LIMIT 6`),
    last7: all(`SELECT date(paid_at) AS date, COUNT(*) AS bookings, COALESCE(SUM(paid_amount), 0) AS billed FROM bookings
      WHERE paid_at IS NOT NULL AND date(paid_at) BETWEEN ? AND ? GROUP BY date(paid_at)`, sch.addDays(t, -6), t),
  });
});

// ---------------------------------------------------------------- bookings
r.get('/bookings', (req, res) => {
  const w = [], p = [];
  if (req.query.status) { w.push('b.status = ?'); p.push(str(req.query.status, 20)); }
  if (req.query.frequency) { w.push('b.frequency = ?'); p.push(str(req.query.frequency, 20)); }
  if (req.query.q) {
    const q = `%${str(req.query.q, 60)}%`;
    w.push('(b.name LIKE ? OR b.phone LIKE ? OR b.email LIKE ? OR b.booking_no LIKE ? OR b.tracking_id LIKE ? OR b.pincode LIKE ?)');
    p.push(q, q, q, q, q, q);
  }
  res.json(all(`SELECT b.*, u.name AS agent_name, s.start_time AS slot_start, s.end_time AS slot_end,
      (SELECT COUNT(*) FROM deliveries d WHERE d.booking_id = b.id AND d.status = 'delivered') AS delivered_count,
      (SELECT COUNT(*) FROM deliveries d WHERE d.booking_id = b.id AND d.status != 'cancelled') AS delivery_count
    FROM bookings b LEFT JOIN users u ON u.id = b.agent_id LEFT JOIN time_slots s ON s.id = b.slot_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY b.id DESC LIMIT 500`, ...p));
});

r.get('/bookings/:id', (req, res) => {
  const b = one(`SELECT b.*, u.name AS agent_name, s.label AS slot_label, s.start_time AS slot_start, s.end_time AS slot_end,
      rc.name AS referred_by_name FROM bookings b LEFT JOIN users u ON u.id = b.agent_id LEFT JOIN time_slots s ON s.id = b.slot_id
      LEFT JOIN customers rc ON rc.id = b.referred_by WHERE b.id = ?`, intId(req.params.id));
  if (!b) fail(404, 'Booking not found');
  b.items = all('SELECT * FROM booking_items WHERE booking_id = ?', b.id);
  b.deliveries = all(`SELECT d.*, u.name AS agent_name, r.rating FROM deliveries d LEFT JOIN users u ON u.id = d.agent_id
    LEFT JOIN ratings r ON r.delivery_id = d.id WHERE d.booking_id = ? ORDER BY d.scheduled_date, d.seq`, b.id);
  b.refundable = refundable(b);
  res.json(b);
});

// Phone/walk-in bookings: saved as awaiting payment and the customer is sent a Razorpay link (on WhatsApp when set up).
r.post('/bookings', async (req, res) => {
  const data = B.parseBooking(req.body, { admin: true });
  const id = B.createBooking(data);
  const b = one('SELECT * FROM bookings WHERE id = ?', id);
  let payUrl = null, payError = null;
  try { payUrl = await P.paymentUrl(b, req); } catch (e) { payError = e.message; }
  res.status(201).json({ id, booking_no: b.booking_no, tracking_id: b.tracking_id, status: b.status, total: b.total_amount, pay_url: payUrl, pay_error: payError });
});

r.post('/bookings/:id/payment-link', async (req, res) => {
  const b = one('SELECT * FROM bookings WHERE id = ?', intId(req.params.id));
  if (!b) fail(404, 'Booking not found');
  res.json({ pay_url: await P.paymentUrl(b, req, { resend: true }) });
});

// Refunds are issued in the Razorpay dashboard; this records them here so reports and the customer's bills stay correct.
r.post('/bookings/:id/refund', (req, res) => {
  const b = one('SELECT * FROM bookings WHERE id = ?', intId(req.params.id));
  if (!b) fail(404, 'Booking not found');
  if (!['paid', 'partially_refunded'].includes(b.payment_status)) bad('Only paid bookings can be refunded');
  const amount = num(req.body.amount, 'refund amount');
  if (!amount || amount > round2(b.paid_amount - b.refunded_amount)) bad(`Refund must be between ${getSettings().currency}1 and the amount paid`);
  const total = round2(b.refunded_amount + amount);
  run('UPDATE bookings SET refunded_amount = ?, payment_status = ?, notes = TRIM(notes || ?) WHERE id = ?',
    total, total >= b.paid_amount ? 'refunded' : 'partially_refunded', ` [Refund ${getSettings().currency}${amount} ${sch.today()}${req.body.note ? `: ${str(req.body.note, 100)}` : ''}]`, b.id);
  res.json({ ok: true, refunded: total });
});

// Undelivered value of a booking (what the customer should get back if it is cancelled now).
function refundable(b) {
  if (!['paid', 'partially_refunded'].includes(b.payment_status)) return 0;
  if (b.status === 'pending') return round2(b.paid_amount - b.refunded_amount);
  const open = one("SELECT COALESCE(SUM(amount), 0) AS n FROM deliveries WHERE booking_id = ? AND status IN ('scheduled', 'cancelled', 'failed')", b.id).n;
  return round2(Math.max(Math.min(open, b.paid_amount - b.refunded_amount), 0));
}

r.post('/bookings/:id/confirm', (req, res) => {
  res.json({ tracking_id: B.confirmBooking(intId(req.params.id), req.body.agent_id) });
});

r.post('/bookings/:id/assign', (req, res) => {
  const b = one('SELECT * FROM bookings WHERE id = ?', intId(req.params.id));
  if (!b) fail(404, 'Booking not found');
  if (b.status !== 'confirmed') bad('Only confirmed bookings can be reassigned');
  const agent = B.requireAgent(req.body.agent_id);
  tx(() => {
    const previous = all("SELECT DISTINCT agent_id FROM deliveries WHERE booking_id = ? AND status = 'scheduled' AND agent_id != ?", b.id, agent.id)
      .map((x) => x.agent_id);
    run('UPDATE bookings SET agent_id = ? WHERE id = ?', agent.id, b.id);
    const moved = run("UPDATE deliveries SET agent_id = ? WHERE booking_id = ? AND status = 'scheduled'", agent.id, b.id).changes;
    const next = one("SELECT MIN(scheduled_date) AS d FROM deliveries WHERE booking_id = ? AND status = 'scheduled'", b.id).d;
    if (agent.id !== b.agent_id || previous.length) {
      notify([agent.id], `Task assigned to you: ${b.booking_no}`,
        `${b.name}, ${b.address} · ${moved} upcoming deliver${moved === 1 ? 'y' : 'ies'}${next ? ` from ${fmtDate(next)}` : ''}`,
        `/agent${next ? `?date=${next}` : ''}`);
      notify(previous, `Task removed: ${b.booking_no}`, `${b.name}'s upcoming deliveries were reassigned to ${agent.name}`, '/agent');
    }
  });
  res.json({ ok: true });
});

r.post('/bookings/:id/cancel', (req, res) => {
  const b = one('SELECT * FROM bookings WHERE id = ?', intId(req.params.id));
  if (!b) fail(404, 'Booking not found');
  if (b.status === 'cancelled' || b.status === 'completed') bad(`Booking is already ${b.status}`);
  const agents = all("SELECT DISTINCT agent_id FROM deliveries WHERE booking_id = ? AND status IN ('scheduled', 'out_for_delivery')", b.id).map((x) => x.agent_id);
  tx(() => {
    run("UPDATE bookings SET status = 'cancelled' WHERE id = ?", b.id);
    run("UPDATE deliveries SET status = 'cancelled' WHERE booking_id = ? AND status IN ('scheduled', 'out_for_delivery')", b.id);
  });
  notify(agents, `Booking cancelled: ${b.booking_no}`, `${b.name}'s upcoming deliveries were cancelled`, '/agent');
  res.json({ ok: true, refundable: refundable(one('SELECT * FROM bookings WHERE id = ?', b.id)) });
});

// ---------------------------------------------------------------- deliveries
r.get('/deliveries', (req, res) => {
  const w = [], p = [];
  const from = sch.isDate(req.query.from) ? req.query.from : sch.today();
  const to = sch.isDate(req.query.to) ? req.query.to : from;
  w.push('d.scheduled_date BETWEEN ? AND ?'); p.push(from, to);
  if (intId(req.query.agent_id)) { w.push('d.agent_id = ?'); p.push(intId(req.query.agent_id)); }
  if (req.query.status) { w.push('d.status = ?'); p.push(str(req.query.status, 20)); }
  res.json(B.deliveryRows(w.join(' AND '), p));
});

r.patch('/deliveries/:id', (req, res) => {
  let d = B.getDelivery(req.params.id);
  const body = req.body;
  tx(() => {
    if (body.agent_id !== undefined) {
      if (!B.isOpen(d)) bad('Only open deliveries can be reassigned');
      const agent = B.requireAgent(body.agent_id);
      run('UPDATE deliveries SET agent_id = ? WHERE id = ?', agent.id, d.id);
      if (agent.id !== d.agent_id) {
        const b = one('SELECT booking_no, name, address, line_no FROM bookings WHERE id = ?', d.booking_id);
        notify([agent.id], `Delivery assigned: ${b.booking_no}`,
          `${b.name}, ${b.address}${b.line_no ? ` (Line ${b.line_no})` : ''} · ${fmtDate(d.scheduled_date)} at ${d.scheduled_time}`,
          `/agent?date=${d.scheduled_date}`);
        notify([d.agent_id], `Delivery removed: ${b.booking_no}`, `${b.name} on ${fmtDate(d.scheduled_date)} was reassigned to ${agent.name}`,
          `/agent?date=${d.scheduled_date}`);
      }
    }
    if (body.scheduled_date !== undefined || body.scheduled_time !== undefined) {
      if (d.status !== 'scheduled' && body.status !== 'scheduled') bad('Only scheduled deliveries can be rescheduled');
      const date = body.scheduled_date ?? d.scheduled_date;
      const time = body.scheduled_time ?? d.scheduled_time;
      if (!sch.isDate(date)) bad('Invalid date');
      if (!isTime(time)) bad('Invalid time');
      const slot = body.slot_id ? one('SELECT * FROM time_slots WHERE id = ?', intId(body.slot_id)) : null;
      run('UPDATE deliveries SET scheduled_date = ?, scheduled_time = ?, slot_id = ? WHERE id = ?',
        date, slot ? slot.start_time : time, slot ? slot.id : (body.slot_id === null ? null : d.slot_id), d.id);
    }
    if (body.status !== undefined && body.status !== d.status) {
      d = B.getDelivery(d.id);
      switch (body.status) {
        case 'delivered': B.markDelivered(d, { empties: body.empties }); break;
        case 'failed': B.failDelivery(d, body.note || 'Marked failed by admin'); break;
        case 'out_for_delivery': B.startDelivery(d); break;
        case 'cancelled':
          if (!B.isOpen(d)) bad('Only open deliveries can be cancelled');
          run("UPDATE deliveries SET status = 'cancelled', note = 'Cancelled by admin' WHERE id = ?", d.id);
          break;
        case 'scheduled':
          if (d.status === 'delivered') bad('A delivered order cannot be reopened');
          if (one('SELECT status FROM bookings WHERE id = ?', d.booking_id).status === 'cancelled') bad('This booking was cancelled');
          run("UPDATE deliveries SET status = 'scheduled', started_at = NULL, note = '' WHERE id = ?", d.id);
          break;
        default: bad('Invalid status');
      }
    }
    B.refreshBookingStatus(d.booking_id);
  });
  res.json(B.deliveryRows('d.id = ?', [d.id])[0]);
});

// ---------------------------------------------------------------- customers & cans
const CUSTOMER_TOTALS = `
  (SELECT COUNT(*) FROM bookings b WHERE b.customer_id = c.id) AS bookings,
  (SELECT COUNT(*) FROM bookings b WHERE b.customer_id = c.id AND b.status = 'confirmed') AS active_bookings,
  (SELECT COALESCE(SUM(d.amount), 0) FROM deliveries d JOIN bookings b ON b.id = d.booking_id WHERE b.customer_id = c.id AND d.status = 'delivered') AS billed,
  (SELECT COALESCE(SUM(d.deposit_amount), 0) FROM deliveries d JOIN bookings b ON b.id = d.booking_id WHERE b.customer_id = c.id AND d.status = 'delivered') AS deposits,
  (SELECT COALESCE(SUM(d.collected), 0) FROM deliveries d JOIN bookings b ON b.id = d.booking_id WHERE b.customer_id = c.id AND d.status = 'delivered') AS collected,
  (SELECT COALESCE(SUM(held), 0) FROM customer_containers cc WHERE cc.customer_id = c.id) AS cans_held`;

r.get('/customers', (req, res) => {
  const q = req.query.q ? `%${str(req.query.q, 60)}%` : null;
  res.json(all(`SELECT c.*, ${CUSTOMER_TOTALS} FROM customers c
    ${q ? 'WHERE c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.address LIKE ? OR c.pincode LIKE ?' : ''}
    ORDER BY c.name LIMIT 1000`, ...(q ? [q, q, q, q, q] : [])));
});

r.get('/customers/:id', (req, res) => {
  const c = one(`SELECT c.*, ${CUSTOMER_TOTALS} FROM customers c WHERE c.id = ?`, intId(req.params.id));
  if (!c) fail(404, 'Customer not found');
  c.bookingList = all(`SELECT b.id, b.booking_no, b.tracking_id, b.frequency, b.status, b.start_date, b.end_date, b.amount_per_delivery,
      u.name AS agent_name FROM bookings b LEFT JOIN users u ON u.id = b.agent_id WHERE b.customer_id = ? ORDER BY b.id DESC`, c.id);
  c.containers = all(`SELECT p.id AS product_id, p.name, p.deposit, COALESCE(cc.held, 0) AS held, COALESCE(cc.deposit_units, 0) AS deposit_units
    FROM products p LEFT JOIN customer_containers cc ON cc.product_id = p.id AND cc.customer_id = ? WHERE p.returnable = 1 ORDER BY p.sort`, c.id);
  c.moves = all(`SELECT m.*, p.name, u.name AS by_name FROM container_moves m JOIN products p ON p.id = m.product_id
    LEFT JOIN users u ON u.id = m.user_id WHERE m.customer_id = ? ORDER BY m.id DESC LIMIT 30`, c.id);
  c.referred = one('SELECT COUNT(DISTINCT customer_id) AS n FROM bookings WHERE referred_by = ?', c.id).n;
  res.json(c);
});

r.put('/customers/:id', (req, res) => {
  const c = one('SELECT * FROM customers WHERE id = ?', intId(req.params.id));
  if (!c) fail(404, 'Customer not found');
  const name = str(req.body.name, 100), email = str(req.body.email, 120).toLowerCase();
  const address = str(req.body.address, 500), lineNo = str(req.body.line_no, 50), pincode = str(req.body.pincode, 10);
  if (!name) bad('Name is required');
  if (email && !isEmail(email)) bad('Invalid email');
  run('UPDATE customers SET name = ?, email = ?, address = ?, line_no = ?, pincode = ?, updated_at = ? WHERE id = ?',
    name, email, address, lineNo, pincode, localNow(), c.id);
  res.json({ ok: true });
});

// Record empty cans returned (with optional deposit refund), or set an opening balance.
r.post('/customers/:id/containers', (req, res) => {
  const c = one('SELECT * FROM customers WHERE id = ?', intId(req.params.id));
  if (!c) fail(404, 'Customer not found');
  const p = one('SELECT * FROM products WHERE id = ? AND returnable = 1', intId(req.body.product_id));
  if (!p) bad('Choose a returnable product');
  const cc = one('SELECT held, deposit_units FROM customer_containers WHERE customer_id = ? AND product_id = ?', c.id, p.id) || { held: 0, deposit_units: 0 };
  let held, units, note, collected = 0, depUnits = 0, depAmount = 0;
  if (req.body.mode === 'set') {
    held = num(req.body.held, 'number of cans', { int: true });
    units = num(req.body.deposit_units, 'number of deposits', { int: true });
    note = `Balance set by admin (was ${cc.held} cans / ${cc.deposit_units} deposits)`;
    depUnits = units - cc.deposit_units;
  } else {
    collected = num(req.body.returned, 'number of cans returned', { int: true });
    const refund = num(req.body.refund_units ?? 0, 'number of deposits refunded', { int: true });
    if (collected > cc.held) bad(`Customer only has ${cc.held} cans`);
    if (refund > cc.deposit_units) bad(`Only ${cc.deposit_units} deposits are held`);
    held = cc.held - collected;
    units = cc.deposit_units - refund;
    depUnits = -refund;
    depAmount = round2(-refund * p.deposit);
    note = str(req.body.note, 200) || `${collected} returned${refund ? `, ${refund} deposit${refund > 1 ? 's' : ''} refunded` : ''}`;
  }
  tx(() => {
    run(`INSERT INTO customer_containers (customer_id, product_id, held, deposit_units) VALUES (?, ?, ?, ?)
      ON CONFLICT(customer_id, product_id) DO UPDATE SET held = excluded.held, deposit_units = excluded.deposit_units`, c.id, p.id, held, units);
    run(`INSERT INTO container_moves (customer_id, product_id, collected, deposit_units, deposit_amount, note, user_id)
      VALUES (?, ?, ?, ?, ?, ?, ?)`, c.id, p.id, collected, depUnits, depAmount, note, req.user.id);
  });
  res.json({ ok: true, held, deposit_units: units, refund: -depAmount });
});

r.get('/containers', (_req, res) => {
  res.json({
    products: all(`SELECT p.id, p.name, p.deposit, p.stock, COALESCE(SUM(cc.held), 0) AS held, COALESCE(SUM(cc.deposit_units), 0) AS deposit_units
      FROM products p LEFT JOIN customer_containers cc ON cc.product_id = p.id WHERE p.returnable = 1 GROUP BY p.id ORDER BY p.sort`),
    customers: all(`SELECT c.id, c.name, c.phone, c.address, p.name AS product, cc.held, cc.deposit_units, p.deposit
      FROM customer_containers cc JOIN customers c ON c.id = cc.customer_id JOIN products p ON p.id = cc.product_id
      WHERE cc.held > 0 OR cc.deposit_units > 0 ORDER BY cc.held DESC, c.name LIMIT 500`),
  });
});

// ---------------------------------------------------------------- products
function parseProduct(b) {
  const p = {
    name: str(b.name, 100), category: str(b.category, 20), type: str(b.type, 20), unit: str(b.unit, 50),
    price: num(b.price, 'price'), description: str(b.description, 500), stock: num(b.stock ?? 0, 'stock', { int: true }),
    active: flag(b.active), sort: Number(b.sort ?? 0) || 0, returnable: b.returnable ? flag(b.returnable) : 0,
    deposit: num(b.deposit ?? 0, 'deposit'),
  };
  if (!p.name) bad('Product name is required');
  if (!['water', 'hydroponics'].includes(p.category)) bad('Choose a category');
  if (!PRODUCT_TYPES.includes(p.type)) bad('Choose a product type');
  return p;
}
const PRODUCT_COLS = ['name', 'category', 'type', 'unit', 'price', 'description', 'stock', 'active', 'sort', 'returnable', 'deposit'];
r.get('/products', (_req, res) => res.json(all('SELECT * FROM products ORDER BY category DESC, sort, name')));
r.post('/products', (req, res) => {
  const p = parseProduct(req.body);
  const id = run(`INSERT INTO products (${PRODUCT_COLS.join(', ')}) VALUES (${PRODUCT_COLS.map(() => '?').join(', ')})`,
    ...PRODUCT_COLS.map((k) => p[k])).lastInsertRowid;
  res.status(201).json(one('SELECT * FROM products WHERE id = ?', id));
});
r.put('/products/:id', (req, res) => {
  const id = intId(req.params.id);
  if (!one('SELECT 1 FROM products WHERE id = ?', id)) fail(404, 'Product not found');
  const p = parseProduct(req.body);
  run(`UPDATE products SET ${PRODUCT_COLS.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, ...PRODUCT_COLS.map((k) => p[k]), id);
  res.json(one('SELECT * FROM products WHERE id = ?', id));
});

// ---------------------------------------------------------------- service areas & time slots
r.get('/areas', (_req, res) => res.json(all('SELECT * FROM service_areas ORDER BY pincode')));
r.post('/areas', (req, res) => {
  const pin = str(req.body.pincode, 10);
  if (!/^\d{4,10}$/.test(pin)) bad('Enter a valid PIN code');
  const vals = [str(req.body.name, 100), num(req.body.delivery_charge ?? 0, 'delivery charge'), num(req.body.min_order ?? 0, 'minimum order'), flag(req.body.active)];
  const id = intId(req.params.id) || intId(req.body.id);
  try {
    if (id) run('UPDATE service_areas SET pincode = ?, name = ?, delivery_charge = ?, min_order = ?, active = ? WHERE id = ?', pin, ...vals, id);
    else run('INSERT INTO service_areas (pincode, name, delivery_charge, min_order, active) VALUES (?, ?, ?, ?, ?)', pin, ...vals);
  } catch (e) { if (/UNIQUE/.test(e.message)) bad(`PIN code ${pin} is already added`); throw e; }
  res.json({ ok: true });
});
r.delete('/areas/:id', (req, res) => { run('DELETE FROM service_areas WHERE id = ?', intId(req.params.id)); res.json({ ok: true }); });

r.get('/slots', (req, res) => {
  const date = sch.isDate(req.query.date) ? req.query.date : sch.today();
  const usage = Object.fromEntries(B.slotsForDate(date).map((s) => [s.id, s.capacity - s.remaining]));
  res.json(all('SELECT * FROM time_slots ORDER BY sort, start_time').map((s) => ({ ...s, booked: usage[s.id] ?? 0 })));
});
r.post('/slots', (req, res) => {
  const s = { label: str(req.body.label, 50), start: str(req.body.start_time, 5), end: str(req.body.end_time, 5) };
  if (!s.label) bad('Give the slot a name');
  if (!isTime(s.start) || !isTime(s.end) || s.end <= s.start) bad('Enter a valid start and end time');
  const vals = [s.label, s.start, s.end, num(req.body.capacity, 'capacity', { min: 1, int: true }), flag(req.body.active), Number(req.body.sort) || 0];
  const id = intId(req.body.id);
  if (id) run('UPDATE time_slots SET label = ?, start_time = ?, end_time = ?, capacity = ?, active = ?, sort = ? WHERE id = ?', ...vals, id);
  else run('INSERT INTO time_slots (label, start_time, end_time, capacity, active, sort) VALUES (?, ?, ?, ?, ?, ?)', ...vals);
  res.json({ ok: true });
});

// ---------------------------------------------------------------- coupons, referrals, ratings
r.get('/coupons', (_req, res) => {
  res.json(all(`SELECT cp.*, c.name AS customer_name,
      (SELECT COUNT(*) FROM bookings b WHERE b.coupon_code = cp.code AND b.status != 'cancelled') AS uses,
      (SELECT COALESCE(SUM(b.discount), 0) FROM bookings b WHERE b.coupon_code = cp.code AND b.status != 'cancelled') AS discount_given
    FROM coupons cp LEFT JOIN customers c ON c.id = cp.customer_id ORDER BY cp.customer_id IS NOT NULL, cp.id DESC LIMIT 500`));
});
r.post('/coupons', (req, res) => {
  const code = str(req.body.code, 30).toUpperCase().replace(/\s/g, '');
  if (!/^[A-Z0-9_-]{3,30}$/.test(code)) bad('Code must be 3–30 letters or numbers');
  const type = req.body.type === 'percent' ? 'percent' : 'flat';
  const value = num(req.body.value, 'discount value');
  if (!value || (type === 'percent' && value > 100)) bad('Enter a valid discount');
  const validFrom = str(req.body.valid_from, 10) || null, validTo = str(req.body.valid_to, 10) || null;
  if ((validFrom && !sch.isDate(validFrom)) || (validTo && !sch.isDate(validTo))) bad('Invalid dates');
  if (one('SELECT 1 FROM customers WHERE referral_code = ?', code)) bad('That code is a customer referral code — pick another');
  const vals = [code, str(req.body.description, 200), type, value, num(req.body.min_order ?? 0, 'minimum order'), num(req.body.max_discount ?? 0, 'max discount'),
    req.body.scope === 'all' ? 'all' : 'first', validFrom, validTo, num(req.body.usage_limit ?? 0, 'usage limit', { int: true }),
    num(req.body.per_customer_limit ?? 1, 'per-customer limit', { int: true }), flag(req.body.active)];
  const id = intId(req.body.id);
  try {
    if (id) {
      run(`UPDATE coupons SET code = ?, description = ?, type = ?, value = ?, min_order = ?, max_discount = ?, scope = ?, valid_from = ?, valid_to = ?,
        usage_limit = ?, per_customer_limit = ?, active = ? WHERE id = ?`, ...vals, id);
    } else {
      run(`INSERT INTO coupons (code, description, type, value, min_order, max_discount, scope, valid_from, valid_to, usage_limit, per_customer_limit, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, ...vals);
    }
  } catch (e) { if (/UNIQUE/.test(e.message)) bad('This code already exists'); throw e; }
  res.json({ ok: true });
});

r.get('/ratings', (req, res) => {
  const { from, to } = dateRange(req.query);
  res.json({
    summary: one('SELECT ROUND(AVG(rating), 2) AS avg, COUNT(*) AS n, COALESCE(SUM(rating <= 2), 0) AS low FROM ratings WHERE date(created_at) BETWEEN ? AND ?', from, to),
    byAgent: all(`SELECT COALESCE(u.name, '—') AS name, ROUND(AVG(r.rating), 2) AS avg, COUNT(*) AS n FROM ratings r LEFT JOIN users u ON u.id = r.agent_id
      WHERE date(r.created_at) BETWEEN ? AND ? GROUP BY r.agent_id ORDER BY avg DESC`, from, to),
    recent: all(`SELECT r.*, b.booking_no, b.name, u.name AS agent_name, d.scheduled_date FROM ratings r JOIN bookings b ON b.id = r.booking_id
      JOIN deliveries d ON d.id = r.delivery_id LEFT JOIN users u ON u.id = r.agent_id
      WHERE date(r.created_at) BETWEEN ? AND ? ORDER BY r.created_at DESC LIMIT 100`, from, to),
  });
});

// ---------------------------------------------------------------- payments
r.get('/payments', (req, res) => {
  const { from, to } = dateRange(req.query);
  res.json({
    from, to, mode: P.mode(),
    summary: one(`SELECT COUNT(*) AS n, COALESCE(SUM(paid_amount), 0) AS paid, COALESCE(SUM(refunded_amount), 0) AS refunded
      FROM bookings WHERE paid_at IS NOT NULL AND date(paid_at) BETWEEN ? AND ?`, from, to),
    awaiting: all(`SELECT id, booking_no, name, phone, total_amount, created_at FROM bookings
      WHERE payment_status = 'unpaid' AND status = 'pending' ORDER BY id DESC LIMIT 100`),
    toRefund: all(`SELECT id, booking_no, name, phone, paid_amount, refunded_amount FROM bookings
      WHERE payment_status IN ('paid', 'partially_refunded') AND status = 'cancelled' ORDER BY id DESC LIMIT 100`)
      .map((b) => ({ ...b, refundable: refundable({ ...b, status: 'cancelled', payment_status: 'paid' }) })),
    rows: all(`SELECT id, booking_no, name, phone, frequency, total_amount, paid_amount, refunded_amount, payment_status, payment_ref, paid_at
      FROM bookings WHERE paid_at IS NOT NULL AND date(paid_at) BETWEEN ? AND ? ORDER BY paid_at DESC LIMIT 500`, from, to),
  });
});

// ---------------------------------------------------------------- staff
r.get('/users', (_req, res) => {
  const t = sch.today();
  res.json(all(`SELECT u.id, u.name, u.email, u.phone, u.role, u.active, u.must_change_password, u.created_at,
      (SELECT COUNT(*) FROM deliveries d WHERE d.agent_id = u.id AND d.scheduled_date = ? AND d.status != 'cancelled') AS today_total,
      (SELECT COUNT(*) FROM deliveries d WHERE d.agent_id = u.id AND d.scheduled_date = ? AND d.status = 'delivered') AS today_delivered,
      (SELECT COUNT(*) FROM deliveries d WHERE d.agent_id = u.id AND d.status = 'out_for_delivery') AS on_route,
      (SELECT COUNT(*) FROM push_subscriptions ps WHERE ps.user_id = u.id) AS push_devices,
      (SELECT ROUND(AVG(rating), 1) FROM ratings rt WHERE rt.agent_id = u.id) AS rating
    FROM users u ORDER BY u.role, u.name`, t, t));
});

function parseUser(b, isNew) {
  const u = {
    name: str(b.name, 100), email: str(b.email, 120).toLowerCase(), phone: str(b.phone, 20),
    role: b.role === 'admin' ? 'admin' : 'agent', active: flag(b.active), password: String(b.password ?? ''),
  };
  if (!u.name) bad('Name is required');
  if (!isEmail(u.email)) bad('Enter a valid email');
  if ((isNew || u.password) && u.password.length < 8) bad('Password must be at least 8 characters');
  return u;
}
const uniqueEmail = (fn) => {
  try { return fn(); } catch (e) { if (/UNIQUE/.test(e.message)) bad('This email is already in use'); throw e; }
};
// Passwords set by an admin are temporary: the staff member must choose their own at first login.
r.post('/users', (req, res) => {
  const u = parseUser(req.body, true);
  const id = uniqueEmail(() => run(`INSERT INTO users (name, email, phone, password_hash, role, active, must_change_password)
    VALUES (?, ?, ?, ?, ?, ?, 1)`, u.name, u.email, u.phone, auth.hashPassword(u.password), u.role, u.active).lastInsertRowid);
  res.status(201).json(publicUser(one('SELECT * FROM users WHERE id = ?', id)));
});
r.put('/users/:id', (req, res) => {
  const existing = one('SELECT * FROM users WHERE id = ?', intId(req.params.id));
  if (!existing) fail(404, 'User not found');
  const u = parseUser(req.body, false);
  if (existing.id === req.user.id && (!u.active || u.role !== 'admin')) bad('You cannot deactivate or demote your own account');
  uniqueEmail(() => run('UPDATE users SET name = ?, email = ?, phone = ?, role = ?, active = ? WHERE id = ?',
    u.name, u.email, u.phone, u.role, u.active, existing.id));
  if (u.password) run('UPDATE users SET password_hash = ?, must_change_password = ? WHERE id = ?',
    auth.hashPassword(u.password), existing.id === req.user.id ? 0 : 1, existing.id);
  if (!u.active) run('DELETE FROM push_subscriptions WHERE user_id = ?', existing.id);
  res.json(publicUser(one('SELECT * FROM users WHERE id = ?', existing.id)));
});

// ---------------------------------------------------------------- reports & billing
function dateRange(q) {
  const t = sch.today();
  const from = sch.isDate(q.from) ? q.from : `${t.slice(0, 7)}-01`;
  const to = sch.isDate(q.to) ? q.to : t;
  if (to < from) bad('“To” date must be after “From” date');
  return { from, to };
}

const csvCell = (v) => {
  const s = String(v ?? '');
  return /[",\n\r]/.test(s) || /^[=+\-@]/.test(s) ? `"${s.replace(/^([=+\-@])/, "'$1").replace(/"/g, '""')}"` : s;
};

r.get('/reports', (req, res) => {
  const { from, to } = dateRange(req.query);
  if (req.query.format === 'csv') {
    const rows = B.deliveryRows('d.scheduled_date BETWEEN ? AND ?', [from, to], 100000);
    const head = ['Date', 'Time', 'Booking No', 'Tracking ID', 'Customer', 'Phone', 'Email', 'Address', 'Line No', 'PIN', 'Frequency',
      'Items', 'Delivery Person', 'Status', 'Amount', 'Payment', 'Empties Collected', 'Invoice No', 'Rating'];
    const lines = rows.map((x) => [x.scheduled_date, x.scheduled_time, x.booking_no, x.tracking_id, x.name, x.phone, x.email, x.address,
      x.line_no, x.pincode, FREQ_LABEL[x.frequency], x.items.map((i) => `${i.name} x${i.quantity}`).join('; '), x.agent_name, x.status, x.amount,
      x.payment_status, x.empties_collected, x.invoice_no, x.rating].map(csvCell).join(','));
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="deliveries_${from}_to_${to}.csv"`);
    return res.send('﻿' + [head.join(','), ...lines].join('\r\n'));
  }
  const range = 'd.scheduled_date BETWEEN ? AND ?';
  res.json({
    from, to,
    summary: one(`SELECT COUNT(*) AS total, COALESCE(SUM(status = 'delivered'), 0) AS delivered, COALESCE(SUM(status = 'failed'), 0) AS failed,
        COALESCE(SUM(status = 'cancelled'), 0) AS cancelled, COALESCE(SUM(status IN ('scheduled', 'out_for_delivery')), 0) AS pending,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN amount END), 0) AS billed,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN deposit_amount END), 0) AS deposits,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN collected END), 0) AS collected,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN empties_collected END), 0) AS empties
      FROM deliveries d WHERE ${range}`, from, to),
    payments: one(`SELECT COUNT(*) AS n, COALESCE(SUM(paid_amount), 0) AS paid, COALESCE(SUM(refunded_amount), 0) AS refunded
      FROM bookings WHERE paid_at IS NOT NULL AND date(paid_at) BETWEEN ? AND ?`, from, to),
    newBookings: one('SELECT COUNT(*) AS n FROM bookings WHERE date(created_at) BETWEEN ? AND ?', from, to).n,
    newCustomers: one('SELECT COUNT(*) AS n FROM customers WHERE date(created_at) BETWEEN ? AND ?', from, to).n,
    discounts: one(`SELECT COALESCE(SUM(b.amount_per_delivery - d.amount), 0) AS n FROM deliveries d JOIN bookings b ON b.id = d.booking_id
      WHERE ${range} AND d.status = 'delivered'`, from, to).n,
    rating: one('SELECT ROUND(AVG(rating), 2) AS avg, COUNT(*) AS n FROM ratings r JOIN deliveries d ON d.id = r.delivery_id WHERE ' + range, from, to),
    byProduct: all(`SELECT bi.name, SUM(bi.quantity) AS quantity, SUM(bi.quantity * bi.price) AS revenue
      FROM deliveries d JOIN booking_items bi ON bi.booking_id = d.booking_id
      WHERE ${range} AND d.status = 'delivered' GROUP BY bi.name ORDER BY revenue DESC`, from, to),
    byAgent: all(`SELECT COALESCE(u.name, 'Unassigned') AS name, COUNT(*) AS total, COALESCE(SUM(d.status = 'delivered'), 0) AS delivered,
        COALESCE(SUM(d.status = 'failed'), 0) AS failed, COALESCE(SUM(CASE WHEN d.status = 'delivered' THEN d.collected END), 0) AS collected,
        (SELECT ROUND(AVG(rt.rating), 1) FROM ratings rt JOIN deliveries d2 ON d2.id = rt.delivery_id
          WHERE rt.agent_id = d.agent_id AND d2.scheduled_date BETWEEN ? AND ?) AS rating
      FROM deliveries d LEFT JOIN users u ON u.id = d.agent_id WHERE ${range} AND d.status != 'cancelled'
      GROUP BY d.agent_id ORDER BY delivered DESC`, from, to, from, to),
    byFrequency: all(`SELECT b.frequency, COUNT(DISTINCT b.id) AS bookings, COALESCE(SUM(d.status = 'delivered'), 0) AS delivered,
        COALESCE(SUM(CASE WHEN d.status = 'delivered' THEN d.amount END), 0) AS billed
      FROM deliveries d JOIN bookings b ON b.id = d.booking_id WHERE ${range} GROUP BY b.frequency ORDER BY billed DESC`, from, to),
    byArea: all(`SELECT COALESCE(NULLIF(b.pincode, ''), '—') AS pincode, COALESCE(a.name, '') AS area, COUNT(*) AS delivered,
        COALESCE(SUM(d.amount), 0) AS billed FROM deliveries d JOIN bookings b ON b.id = d.booking_id
        LEFT JOIN service_areas a ON a.pincode = b.pincode WHERE ${range} AND d.status = 'delivered' GROUP BY b.pincode ORDER BY billed DESC`, from, to),
    daily: all(`SELECT scheduled_date AS date, COUNT(*) AS total, COALESCE(SUM(status = 'delivered'), 0) AS delivered,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN amount END), 0) AS billed,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN collected END), 0) AS collected
      FROM deliveries d WHERE ${range} AND status != 'cancelled' GROUP BY scheduled_date ORDER BY scheduled_date`, from, to),
  });
});

r.get('/billing/statement', (req, res) => {
  const c = one('SELECT * FROM customers WHERE id = ?', intId(req.query.customer_id));
  if (!c) fail(404, 'Choose a customer');
  const { from, to } = dateRange(req.query);
  const rows = B.deliveryRows("b.customer_id = ? AND d.scheduled_date BETWEEN ? AND ? AND d.status IN ('delivered', 'failed')", [c.id, from, to], 5000);
  const delivered = rows.filter((x) => x.status === 'delivered');
  const billed = round2(delivered.reduce((s, x) => s + x.amount, 0));
  const deposits = round2(delivered.reduce((s, x) => s + x.deposit_amount, 0));
  const collected = round2(delivered.reduce((s, x) => s + x.collected, 0));
  const previousDue = round2(one(`SELECT COALESCE(SUM(d.amount + d.deposit_amount) - SUM(d.collected), 0) AS n FROM deliveries d
    JOIN bookings b ON b.id = d.booking_id WHERE b.customer_id = ? AND d.status = 'delivered' AND d.scheduled_date < ?`, c.id, from).n);
  res.json({ customer: c, from, to, rows, billed, deposits, collected, previousDue, due: round2(previousDue + billed + deposits - collected), settings: getSettings() });
});

// ---------------------------------------------------------------- settings & backups
r.put('/settings', (req, res) => {
  const up = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  tx(() => {
    for (const k of SETTING_KEYS) {
      if (req.body[k] === undefined) continue;
      const v = NUMERIC_SETTINGS.includes(k) ? String(num(req.body[k] || 0, k.replaceAll('_', ' '))) : str(req.body[k], 500);
      up.run(k, v);
    }
  });
  res.json(getSettings());
});

r.get('/backups', (_req, res) => res.json({ dir: backup.backupDir, files: backup.listBackups() }));
r.get('/backup/download', (_req, res) => {
  const file = path.join(dataDir, `download-${Date.now()}.db`);
  backup.backupTo(file);
  res.download(file, `aqualeaf-backup-${sch.today()}.db`, () => fs.unlink(file, () => {}));
});

module.exports = r;
