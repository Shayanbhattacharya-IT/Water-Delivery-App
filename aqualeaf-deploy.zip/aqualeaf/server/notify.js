// Staff notifications: in-app bell + Web Push + WhatsApp (to the staff member's phone, when configured).
const fs = require('fs');
const path = require('path');
const webpush = require('web-push');
const { dataDir } = require('./config');
const { db, all, one, run, setting, localNow } = require('./util');
const wa = require('./whatsapp');

// ---------------------------------------------------------------- Web Push (VAPID)
function loadVapid() {
  if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    return { publicKey: process.env.VAPID_PUBLIC_KEY, privateKey: process.env.VAPID_PRIVATE_KEY };
  }
  const file = path.join(dataDir, 'vapid.json');
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(webpush.generateVAPIDKeys()), { mode: 0o600 });
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}
const vapid = loadVapid();
const vapidSubject = () => process.env.VAPID_SUBJECT || `mailto:${setting('email', 'admin@example.com')}`;

async function pushToUser(userId, payload) {
  const subs = all('SELECT * FROM push_subscriptions WHERE user_id = ?', userId);
  await Promise.all(subs.map(async (s) => {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
        { TTL: 6 * 3600, urgency: 'high', vapidDetails: { subject: vapidSubject(), publicKey: vapid.publicKey, privateKey: vapid.privateKey } },
      );
    } catch (e) {
      // 404/410 = subscription expired or the user turned notifications off.
      if (e.statusCode === 404 || e.statusCode === 410) run('DELETE FROM push_subscriptions WHERE id = ?', s.id);
      else console.warn(`[push] failed for user ${userId}: ${e.statusCode || ''} ${e.message}`);
    }
  }));
}

// ---------------------------------------------------------------- staff notifications
function notify(userIds, title, body = '', link = '') {
  const ins = db.prepare('INSERT INTO notifications (user_id, title, body, link, created_at) VALUES (?, ?, ?, ?, ?)');
  const ids = [...new Set(userIds)].filter(Boolean);
  for (const id of ids) {
    const n = ins.run(id, title, body, link, localNow());
    const phone = wa.configured() ? one('SELECT phone FROM users WHERE id = ? AND active = 1', id)?.phone : null;
    // Push / WhatsApp go out after the current request finishes; failures never break the request.
    setImmediate(() => {
      pushToUser(id, { id: Number(n.lastInsertRowid), title, body, url: link || '/' }).catch(() => {});
      if (phone) wa.sendTemplate(phone, 'staff_alert', [title, body]).catch((e) => console.warn(`[whatsapp] staff alert: ${e.message}`));
    });
  }
}
const notifyAdmins = (title, body, link) =>
  notify(all("SELECT id FROM users WHERE role = 'admin' AND active = 1").map((u) => u.id), title, body, link);

module.exports = { notify, notifyAdmins, vapidPublicKey: vapid.publicKey };
