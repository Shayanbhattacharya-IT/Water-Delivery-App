// Booking domain: pricing (areas, slots, coupons, referrals), prepaid booking lifecycle, deliveries and returnable cans.
const crypto = require('crypto');
const sch = require('./schedule');
const {
  one, all, run, tx, fail, bad, str, intId, round2, localNow, cleanPhone, isEmail, isTime, FREQ_LABEL, fmtDate,
  setting, numSetting, randomCode,
} = require('./util');
const { notify, notifyAdmins } = require('./notify');
const { sendCustomer } = require('./messaging');

// Plans customers can book. Older bookings may still carry weekly/monthly/yearly and keep working.
const FREQUENCIES = ['once', 'alternate', 'daily'];
const STEP_DAYS = { once: 0, alternate: 2, daily: 1 };
const MAX_DELIVERIES = 366;
const cur = () => setting('currency', '₹');
const publicUrl = () => (process.env.PUBLIC_URL || require('./config').runtimeBaseUrl || '').replace(/\/$/, '');
const inr = (n) => `${cur()}${Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

// ---------------------------------------------------------------- service areas
const areasRestricted = () => one('SELECT COUNT(*) AS n FROM service_areas WHERE active = 1').n > 0;

// Delivery terms for a PIN code, or null when we don't deliver there.
function areaFor(pincode) {
  if (!areasRestricted()) {
    return { restricted: false, name: '', delivery_charge: numSetting('default_delivery_charge'), min_order: numSetting('default_min_order') };
  }
  const a = one('SELECT * FROM service_areas WHERE pincode = ? AND active = 1', pincode);
  return a ? { restricted: true, name: a.name, delivery_charge: a.delivery_charge, min_order: a.min_order } : null;
}

// ---------------------------------------------------------------- time slots
const activeSlots = () => all('SELECT * FROM time_slots WHERE active = 1 ORDER BY sort, start_time');
const toMinutes = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const nowMinutes = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
const slotUsage = (slotId, date) => one(`SELECT COUNT(*) AS n FROM deliveries WHERE slot_id = ? AND scheduled_date = ?
  AND status IN ('scheduled', 'out_for_delivery', 'delivered')`, slotId, date).n;
const tooLateToday = (slot, date) => date === sch.today() && nowMinutes() + numSetting('same_day_cutoff_minutes', 60) >= toMinutes(slot.start_time);

function slotsForDate(date) {
  return activeSlots().map((s) => {
    const remaining = Math.max(s.capacity - slotUsage(s.id, date), 0);
    const late = tooLateToday(s, date);
    return { id: s.id, label: s.label, start_time: s.start_time, end_time: s.end_time, capacity: s.capacity, remaining,
      available: remaining > 0 && !late, reason: late ? 'Too late for today' : remaining ? '' : 'Full' };
  });
}

// ---------------------------------------------------------------- coupons & referrals
const couponUses = (code, customerId = null) => one(`SELECT COUNT(*) AS n FROM bookings WHERE coupon_code = ? AND status != 'cancelled'
  ${customerId ? 'AND customer_id = ?' : ''}`, code, ...(customerId ? [customerId] : [])).n;

function applyCode(rawCode, phone, subtotal) {
  const code = str(rawCode, 30).toUpperCase().replace(/\s/g, '');
  if (!code) return null;
  const customer = phone ? one('SELECT * FROM customers WHERE phone = ?', phone) : null;
  const c = one('SELECT * FROM coupons WHERE code = ? AND active = 1', code);
  if (c) {
    const t = sch.today();
    if (c.valid_from && t < c.valid_from) bad('This coupon is not active yet');
    if (c.valid_to && t > c.valid_to) bad('This coupon has expired');
    if (c.customer_id && (!customer || customer.id !== c.customer_id)) bad('This coupon belongs to another customer — check the phone number');
    if (c.usage_limit && couponUses(code) >= c.usage_limit) bad('This coupon has been fully used');
    if (c.per_customer_limit && customer && couponUses(code, customer.id) >= c.per_customer_limit) bad('You have already used this coupon');
    if (subtotal < c.min_order) bad(`Add items worth ${cur()}${c.min_order} or more to use this coupon`);
    let discount = c.type === 'percent' ? (subtotal * c.value) / 100 : c.value;
    if (c.max_discount > 0) discount = Math.min(discount, c.max_discount);
    discount = round2(Math.min(discount, subtotal));
    const label = c.type === 'percent' ? `${c.value}% off` : `${cur()}${c.value} off`;
    return { code, discount, scope: c.scope, referred_by: null,
      description: c.description || `${label} ${c.scope === 'all' ? 'every delivery' : 'your first delivery'}` };
  }
  const ref = one('SELECT * FROM customers WHERE referral_code = ?', code);
  if (ref) {
    if (ref.phone === phone) bad("You can't use your own referral code");
    if (customer && one("SELECT 1 FROM bookings WHERE customer_id = ? AND payment_status != 'unpaid' LIMIT 1", customer.id)) {
      bad('Referral codes are for first-time customers only');
    }
    const discount = round2(Math.min(numSetting('referral_discount', 50), subtotal));
    return { code, discount, scope: 'first', referred_by: ref.id,
      description: `Referred by ${ref.name.split(' ')[0]} — ${cur()}${discount} off your first delivery` };
  }
  bad('Invalid coupon or referral code');
}

function newReferralCode(name) {
  const prefix = (String(name).toUpperCase().replace(/[^A-Z]/g, '') + 'AQUA').slice(0, 4);
  for (;;) {
    const code = prefix + randomCode(4, '23456789ABCDEFGHJKMNPQRSTUVWXYZ');
    if (!one('SELECT 1 FROM customers WHERE referral_code = ?', code) && !one('SELECT 1 FROM coupons WHERE code = ?', code)) return code;
  }
}
// Back-fill referral codes for customers created before referrals existed.
for (const c of all('SELECT id, name FROM customers WHERE referral_code IS NULL')) {
  run('UPDATE customers SET referral_code = ? WHERE id = ?', newReferralCode(c.name), c.id);
}

// ---------------------------------------------------------------- schedule helpers
// `count` delivery dates for a plan starting at `start`.
function planDates(frequency, start, count) {
  const step = STEP_DAYS[frequency];
  if (step === undefined) return sch.occurrences(frequency, start, sch.addMonths(start, 120)).slice(0, count); // legacy plans
  return Array.from({ length: frequency === 'once' ? 1 : count }, (_, i) => sch.addDays(start, i * step));
}
const countDeliveries = (frequency, start, end) => sch.occurrences(frequency, start, end).length;

// ---------------------------------------------------------------- pricing
function parseItems(items) {
  if (!Array.isArray(items) || items.length === 0) bad('Add at least one product');
  const qty = new Map();
  for (const it of items) {
    const pid = intId(it?.product_id);
    const q = Number(it?.quantity);
    if (!pid) bad('Invalid product in cart');
    if (!Number.isInteger(q) || q < 1 || q > 999) bad('Quantity must be between 1 and 999');
    qty.set(pid, Math.min((qty.get(pid) || 0) + q, 999));
  }
  return [...qty].map(([pid, q]) => {
    const p = one('SELECT * FROM products WHERE id = ? AND active = 1', pid);
    if (!p) bad('A product in your cart is no longer available');
    return { product_id: p.id, name: p.name, unit: p.unit, price: p.price, quantity: q, returnable: p.returnable, deposit: p.deposit };
  });
}

// Refundable deposit units for returnable cans the customer will newly hold (a 1-for-1 swap needs no new deposit).
function depositsFor(customerId, lines) {
  return lines.filter((l) => l.returnable && l.deposit > 0).map((l) => {
    const cc = customerId ? one('SELECT held, deposit_units FROM customer_containers WHERE customer_id = ? AND product_id = ?', customerId, l.product_id) : null;
    const held = cc?.held || 0, units = cc?.deposit_units || 0;
    const add = Math.max(held + l.quantity - Math.min(l.quantity, held) - units, 0);
    return { product_id: l.product_id, name: l.name, units: add, per_unit: l.deposit, amount: round2(add * l.deposit) };
  });
}

// Price a cart for a PIN code (+ optional coupon, + number of deliveries for the upfront total).
function quote({ items, pincode, coupon_code: couponCode, phone, deliveries = 1 }) {
  const lines = parseItems(items);
  const subtotal = round2(lines.reduce((s, i) => s + i.price * i.quantity, 0));
  const pin = str(pincode, 10);
  if (!/^\d{4,10}$/.test(pin)) bad('Enter a valid PIN code');
  const area = areaFor(pin);
  if (!area) bad(`Sorry, we don't deliver to PIN code ${pin} yet`);
  if (subtotal < area.min_order) bad(`Minimum order for your area is ${cur()}${area.min_order} per delivery (you have ${cur()}${subtotal})`);
  const coupon = applyCode(couponCode, cleanPhone(phone), subtotal);
  const customer = phone ? one('SELECT id FROM customers WHERE phone = ?', cleanPhone(phone)) : null;
  const deposits = depositsFor(customer?.id, lines);
  const n = Math.max(1, Math.min(Number(deliveries) || 1, MAX_DELIVERIES));
  const perDelivery = round2(subtotal + area.delivery_charge);
  const discountTotal = coupon ? round2(coupon.scope === 'all' ? coupon.discount * n : coupon.discount) : 0;
  const deposit = round2(deposits.reduce((s, d) => s + d.amount, 0));
  return {
    items: lines, subtotal, pincode: pin, area_name: area.name, delivery_charge: round2(area.delivery_charge), min_order: area.min_order,
    coupon, per_delivery: perDelivery, deliveries: n, discount_total: discountTotal, deposit, deposits,
    total: round2(perDelivery * n - discountTotal + deposit),
  };
}

// ---------------------------------------------------------------- booking input
function parseBooking(b, { admin = false } = {}) {
  const d = {
    name: str(b.name, 100), phone: cleanPhone(b.phone), email: str(b.email, 120).toLowerCase(), address: str(b.address, 500),
    line_no: str(b.line_no, 50), frequency: str(b.frequency, 20), start_date: str(b.start_date, 10), end_date: str(b.end_date, 10),
    delivery_time: str(b.delivery_time, 5), notes: str(b.notes, 500), slot_id: null,
  };
  if (!d.name) bad('Customer name is required');
  if (!/^\+?\d{10,15}$/.test(d.phone)) bad('Enter a valid contact number (10–15 digits)');
  if (!isEmail(d.email)) bad('Enter a valid email address');
  if (d.address.length < 5) bad('Delivery address is required');
  if (!FREQUENCIES.includes(d.frequency)) bad('Choose a delivery plan: one time, alternate days or daily');
  if (!sch.isDate(d.start_date)) bad('Choose a delivery date');
  if (d.start_date < sch.today()) bad('Delivery date cannot be in the past');
  if (d.frequency === 'once') d.end_date = d.start_date;
  else {
    if (!d.end_date) d.end_date = sch.defaultEndDate(d.frequency, d.start_date);
    if (!sch.isDate(d.end_date) || d.end_date < d.start_date) bad('End date must be on or after the start date');
  }
  const dates = sch.occurrences(d.frequency, d.start_date, d.end_date);
  if (dates.length > MAX_DELIVERIES) bad(`Schedule is too long — choose an earlier end date (max ${MAX_DELIVERIES} deliveries)`);

  // Time slot (when slots are configured) — otherwise a free delivery time.
  const slots = activeSlots();
  if (slots.length && (b.slot_id || !admin)) {
    const slot = slots.find((s) => s.id === intId(b.slot_id));
    if (!slot) bad('Choose a delivery time slot');
    if (!admin && tooLateToday(slot, d.start_date)) bad(`It's too late to book the ${slot.label} slot for today — choose a later slot or another day`);
    if (!admin || !b.override_capacity) {
      const full = dates.find((dt) => slotUsage(slot.id, dt) >= slot.capacity);
      if (full) bad(`The ${slot.label} slot (${slot.start_time}–${slot.end_time}) is full on ${fmtDate(full)} — please choose another slot or date`);
    }
    d.slot_id = slot.id;
    d.delivery_time = slot.start_time;
  } else if (!isTime(d.delivery_time)) bad('Choose a delivery time');

  const q = quote({ items: b.items, pincode: b.pincode, coupon_code: b.coupon_code, phone: d.phone, deliveries: dates.length });
  Object.assign(d, {
    items: q.items, pincode: q.pincode, delivery_charge: q.delivery_charge, amount: q.per_delivery,
    coupon_code: q.coupon?.code || '', discount: q.coupon?.discount || 0, discount_scope: q.coupon?.scope || 'first',
    referred_by: q.coupon?.referred_by || null, total: q.total, deposit: q.deposit, deliveries: dates.length,
  });
  return d;
}

// ---------------------------------------------------------------- booking lifecycle
function requireAgent(agentId) {
  const a = one("SELECT * FROM users WHERE id = ? AND role = 'agent' AND active = 1", intId(agentId));
  if (!a) bad('Choose an active delivery person');
  return a;
}

function newTrackingId() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    const t = 'TRK' + Array.from(crypto.randomBytes(8), (x) => A[x % 32]).join('');
    if (!one('SELECT 1 FROM bookings WHERE tracking_id = ?', t)) return t;
  }
}

function slotText(b) {
  const s = b.slot_id ? one('SELECT label, start_time, end_time FROM time_slots WHERE id = ?', b.slot_id) : null;
  return s ? `${s.start_time}–${s.end_time}` : b.delivery_time;
}

const isPaid = (b) => b.payment_status === 'paid' || b.payment_status === 'cod';

function confirmBooking(id, agentId) {
  return tx(() => {
    const b = one('SELECT * FROM bookings WHERE id = ?', id);
    if (!b) fail(404, 'Booking not found');
    if (b.status !== 'pending') bad('Only pending bookings can be confirmed');
    if (!isPaid(b)) bad('This booking has not been paid yet — it can be confirmed once the customer completes the Razorpay payment');
    const agent = requireAgent(agentId);
    // The customer paid for a fixed number of deliveries; if the start date has passed, the same count starts today.
    const count = countDeliveries(b.frequency, b.start_date, b.end_date);
    const start = b.start_date >= sch.today() ? b.start_date : sch.today();
    const dates = planDates(b.frequency, start, count);
    if (!dates.length) bad('This booking has no delivery dates');
    dates.forEach((dt, i) => {
      const discount = b.discount_scope === 'all' || i === 0 ? b.discount : 0;
      run(`INSERT INTO deliveries (booking_id, seq, scheduled_date, scheduled_time, slot_id, agent_id, amount) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        id, i + 1, dt, b.delivery_time, b.slot_id, agent.id, round2(Math.max(b.amount_per_delivery - discount, 0)));
    });
    const tid = b.tracking_id || newTrackingId();
    run("UPDATE bookings SET status = 'confirmed', agent_id = ?, tracking_id = ?, confirmed_at = ?, start_date = ?, end_date = ? WHERE id = ?",
      agent.id, tid, localNow(), dates[0], dates[dates.length - 1], id);
    notify([agent.id], `New task assigned: ${b.booking_no}`,
      `${b.name}, ${b.address}${b.line_no ? ` (Line ${b.line_no})` : ''} · ${FREQ_LABEL[b.frequency]}, ${dates.length} deliver${dates.length === 1 ? 'y' : 'ies'} from ${fmtDate(dates[0])} at ${slotText(b)}`,
      `/agent?date=${dates[0]}`);
    return tid;
  });
}

function createBooking(d, { agentId = null, paymentStatus = 'unpaid' } = {}) {
  return tx(() => {
    const c = one('SELECT id FROM customers WHERE phone = ?', d.phone);
    let customerId;
    if (c) {
      run('UPDATE customers SET name = ?, email = ?, address = ?, line_no = ?, pincode = ?, updated_at = ? WHERE id = ?',
        d.name, d.email, d.address, d.line_no, d.pincode, localNow(), c.id);
      customerId = c.id;
    } else {
      customerId = Number(run('INSERT INTO customers (name, phone, email, address, line_no, pincode, referral_code) VALUES (?, ?, ?, ?, ?, ?, ?)',
        d.name, d.phone, d.email, d.address, d.line_no, d.pincode, newReferralCode(d.name)).lastInsertRowid);
    }
    const id = Number(run(`INSERT INTO bookings (customer_id, name, phone, email, address, line_no, pincode, frequency, start_date, end_date,
        delivery_time, slot_id, amount_per_delivery, delivery_charge, coupon_code, discount, discount_scope, referred_by, notes,
        payment_method, payment_status, total_amount, deposit_amount, tracking_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Razorpay', ?, ?, ?, ?)`,
      customerId, d.name, d.phone, d.email, d.address, d.line_no, d.pincode, d.frequency, d.start_date, d.end_date,
      d.delivery_time, d.slot_id, d.amount, d.delivery_charge, d.coupon_code, d.discount, d.discount_scope, d.referred_by, d.notes,
      paymentStatus, d.total, d.deposit, newTrackingId()).lastInsertRowid);
    run('UPDATE bookings SET booking_no = ? WHERE id = ?', `BK${String(id).padStart(6, '0')}`, id);
    for (const it of d.items) {
      run('INSERT INTO booking_items (booking_id, product_id, name, unit, price, quantity) VALUES (?, ?, ?, ?, ?, ?)',
        id, it.product_id, it.name, it.unit, it.price, it.quantity);
    }
    if (agentId && paymentStatus !== 'unpaid') confirmBooking(id, agentId);
    return id;
  });
}

// Payment received (Razorpay link paid, or test payment): mark paid, credit can deposits, tell admins + customer.
function markPaid(bookingId, { amount, reference }) {
  const result = tx(() => {
    const b = one('SELECT * FROM bookings WHERE id = ?', bookingId);
    if (!b) fail(404, 'Booking not found');
    if (b.payment_status === 'paid') return { already: true, b };
    run("UPDATE bookings SET payment_status = 'paid', paid_amount = ?, payment_ref = ?, paid_at = ? WHERE id = ?",
      round2(amount ?? b.total_amount), str(reference, 100), localNow(), b.id);
    // The deposit for new cans was part of the payment, so record those deposits now.
    const lines = all(`SELECT bi.product_id, bi.name, bi.quantity, p.returnable, p.deposit FROM booking_items bi
      JOIN products p ON p.id = bi.product_id WHERE bi.booking_id = ?`, b.id);
    for (const dep of depositsFor(b.customer_id, lines)) {
      if (!dep.units) continue;
      run(`INSERT INTO customer_containers (customer_id, product_id, held, deposit_units) VALUES (?, ?, 0, ?)
        ON CONFLICT(customer_id, product_id) DO UPDATE SET deposit_units = deposit_units + excluded.deposit_units`, b.customer_id, dep.product_id, dep.units);
      run(`INSERT INTO container_moves (customer_id, product_id, deposit_units, deposit_amount, note) VALUES (?, ?, ?, ?, ?)`,
        b.customer_id, dep.product_id, dep.units, dep.amount, `Deposit paid online with ${b.booking_no}`);
    }
    return { already: false, b };
  });
  if (!result.already) {
    const b = result.b;
    notifyAdmins(`New paid booking ${b.booking_no}`,
      `${b.name} (${b.phone}) · ${FREQ_LABEL[b.frequency]} from ${fmtDate(b.start_date)} at ${slotText(b)} · paid ${inr(amount ?? b.total_amount)} — confirm & assign a delivery person`,
      '/admin#bookings?status=pending');
    sendCustomer('booking_confirmed', b.phone, [b.name.split(' ')[0], b.booking_no, inr(amount ?? b.total_amount),
      `${FREQ_LABEL[b.frequency]} from ${fmtDate(b.start_date)}, ${slotText(b)}`, `${publicUrl()}/track?id=${b.tracking_id}`]);
  }
  return result;
}

function refreshBookingStatus(bookingId) {
  const open = one("SELECT COUNT(*) AS n FROM deliveries WHERE booking_id = ? AND status IN ('scheduled', 'out_for_delivery')", bookingId).n;
  const b = one('SELECT status FROM bookings WHERE id = ?', bookingId);
  if (b.status === 'confirmed' && open === 0) run("UPDATE bookings SET status = 'completed' WHERE id = ?", bookingId);
  else if (b.status === 'completed' && open > 0) run("UPDATE bookings SET status = 'confirmed' WHERE id = ?", bookingId);
}

// Prepaid plans: a skipped/paused delivery moves to the end of the plan instead of being lost.
function moveToEnd(d, note) {
  const b = one('SELECT * FROM bookings WHERE id = ?', d.booking_id);
  const step = STEP_DAYS[b.frequency] || 1;
  const last = one("SELECT MAX(scheduled_date) AS d FROM deliveries WHERE booking_id = ? AND status IN ('scheduled', 'out_for_delivery', 'delivered')", b.id).d;
  const newDate = sch.addDays(last > d.scheduled_date ? last : d.scheduled_date, step);
  run("UPDATE deliveries SET scheduled_date = ?, note = ? WHERE id = ?", newDate, note, d.id);
  run('UPDATE bookings SET end_date = ? WHERE id = ? AND end_date < ?', newDate, b.id, newDate);
  return newDate;
}

// ---------------------------------------------------------------- deliveries
function getDelivery(id) {
  const d = one('SELECT * FROM deliveries WHERE id = ?', intId(id));
  if (!d) fail(404, 'Delivery not found');
  return d;
}
const isOpen = (d) => d.status === 'scheduled' || d.status === 'out_for_delivery';

// Returnable containers for a delivery: what to hand over, empties expected back, and any deposit still uncovered.
// `empties` maps product_id → empties actually collected (defaults to a 1-for-1 swap).
function containerPlan(d, empties = {}) {
  const b = one('SELECT customer_id FROM bookings WHERE id = ?', d.booking_id);
  const items = all(`SELECT bi.product_id, bi.name, bi.quantity, p.deposit FROM booking_items bi JOIN products p ON p.id = bi.product_id
    WHERE bi.booking_id = ? AND p.returnable = 1`, d.booking_id);
  return items.map((it) => {
    const cc = one('SELECT held, deposit_units FROM customer_containers WHERE customer_id = ? AND product_id = ?', b.customer_id, it.product_id)
      || { held: 0, deposit_units: 0 };
    const expected = Math.min(it.quantity, cc.held);
    const raw = empties?.[it.product_id];
    const collected = raw === undefined || raw === null || raw === '' ? expected : Number(raw);
    if (!Number.isInteger(collected) || collected < 0 || collected > 999) bad(`Enter how many empty ${it.name} were collected`);
    const newHeld = Math.max(cc.held + it.quantity - collected, 0);
    const addUnits = Math.max(newHeld - cc.deposit_units, 0);
    return { product_id: it.product_id, name: it.name, delivered: it.quantity, held: cc.held, deposit_units: cc.deposit_units,
      expected, collected, new_held: newHeld, add_units: addUnits, per_unit: it.deposit, deposit_amount: round2(addUnits * it.deposit) };
  });
}

function rewardReferrer(bookingId) {
  const b = one('SELECT customer_id, referred_by, name FROM bookings WHERE id = ?', bookingId);
  if (!b.referred_by) return;
  const delivered = one(`SELECT COUNT(*) AS n FROM deliveries d JOIN bookings bk ON bk.id = d.booking_id
    WHERE bk.customer_id = ? AND d.status = 'delivered'`, b.customer_id).n;
  if (delivered !== 1) return; // only on the referred customer's very first completed delivery
  const reward = numSetting('referral_reward', 50);
  if (reward <= 0 || !one('SELECT 1 FROM customers WHERE id = ?', b.referred_by)) return;
  run(`INSERT INTO coupons (code, description, type, value, scope, usage_limit, per_customer_limit, customer_id)
    VALUES (?, ?, 'flat', ?, 'first', 1, 1, ?)`, `REF${randomCode(6)}`, `Referral reward — thanks for referring ${b.name.split(' ')[0]}!`, reward, b.referred_by);
}

// Bookings are prepaid, so a delivery is simply confirmed; any can deposit not covered upfront is noted (and shown as due).
function markDelivered(d, { empties } = {}) {
  if (!isOpen(d)) bad(`This delivery is already ${d.status.replaceAll('_', ' ')}`);
  tx(() => {
    const plan = containerPlan(d, empties);
    const deposit = round2(plan.reduce((s, p) => s + p.deposit_amount, 0));
    const b = one('SELECT customer_id, phone, name, booking_no, tracking_id FROM bookings WHERE id = ?', d.booking_id);
    const now = localNow();
    run(`UPDATE deliveries SET status = 'delivered', collected = ?, deposit_amount = ?, empties_collected = ?, delivered_at = ?,
        started_at = COALESCE(started_at, ?), invoice_no = ? WHERE id = ?`,
      d.amount, deposit, plan.reduce((s, p) => s + p.collected, 0), now, now,
      `INV-${sch.today().slice(0, 7).replace('-', '')}-${String(d.id).padStart(6, '0')}`, d.id);
    for (const p of plan) {
      run(`INSERT INTO customer_containers (customer_id, product_id, held, deposit_units) VALUES (?, ?, ?, ?)
        ON CONFLICT(customer_id, product_id) DO UPDATE SET held = excluded.held, deposit_units = excluded.deposit_units`,
        b.customer_id, p.product_id, p.new_held, p.deposit_units + p.add_units);
      run(`INSERT INTO container_moves (customer_id, product_id, delivery_id, delivered, collected, deposit_units, deposit_amount, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, b.customer_id, p.product_id, d.id, p.delivered, p.collected, p.add_units, p.deposit_amount, d.agent_id);
    }
    for (const it of all('SELECT product_id, quantity FROM booking_items WHERE booking_id = ?', d.booking_id)) {
      run('UPDATE products SET stock = MAX(stock - ?, 0) WHERE id = ?', it.quantity, it.product_id);
    }
    refreshBookingStatus(d.booking_id);
    rewardReferrer(d.booking_id);
    sendCustomer('delivered', b.phone, [b.name.split(' ')[0], b.booking_no, `${publicUrl()}/invoice?id=${d.id}&t=${b.tracking_id}`]);
  });
}

function startDelivery(d) {
  if (d.status !== 'scheduled') bad('Only scheduled deliveries can be started');
  if (d.scheduled_date > sch.today()) bad('This delivery is scheduled for a later date');
  run("UPDATE deliveries SET status = 'out_for_delivery', started_at = ? WHERE id = ?", localNow(), d.id);
  const b = one('SELECT phone, name, booking_no FROM bookings WHERE id = ?', d.booking_id);
  const agent = one('SELECT name, phone FROM users WHERE id = ?', d.agent_id);
  sendCustomer('out_for_delivery', b.phone, [b.name.split(' ')[0], b.booking_no, agent?.name || 'our delivery person', agent?.phone || setting('phone')]);
}

function failDelivery(d, note, { alertAdmins = false } = {}) {
  if (!isOpen(d)) bad(`This delivery is already ${d.status.replaceAll('_', ' ')}`);
  tx(() => {
    run("UPDATE deliveries SET status = 'failed', note = ? WHERE id = ?", str(note, 300), d.id);
    refreshBookingStatus(d.booking_id);
    if (alertAdmins) {
      const b = one('SELECT booking_no, name FROM bookings WHERE id = ?', d.booking_id);
      const agent = one('SELECT name FROM users WHERE id = ?', d.agent_id);
      notifyAdmins(`Not delivered: ${b.booking_no}`, `${b.name} · ${fmtDate(d.scheduled_date)} · ${agent?.name || 'Agent'}: ${note} — reschedule it (already paid)`, '/admin#deliveries');
    }
  });
}

// Deliveries joined with booking/customer details, slot, rating and items.
function deliveryRows(where, params, limit = 1000) {
  const rows = all(`SELECT d.*, b.booking_no, b.tracking_id, b.customer_id, b.name, b.phone, b.email, b.address, b.line_no, b.pincode,
      b.frequency, b.notes AS booking_notes, b.payment_status, u.name AS agent_name, s.label AS slot_label, s.start_time AS slot_start,
      s.end_time AS slot_end, r.rating, r.comment AS rating_comment
    FROM deliveries d JOIN bookings b ON b.id = d.booking_id LEFT JOIN users u ON u.id = d.agent_id
    LEFT JOIN time_slots s ON s.id = d.slot_id LEFT JOIN ratings r ON r.delivery_id = d.id
    WHERE ${where} ORDER BY d.scheduled_date, d.scheduled_time, d.id LIMIT ${Number(limit)}`, ...params);
  const ids = [...new Set(rows.map((r) => r.booking_id))];
  const items = ids.length
    ? all(`SELECT booking_id, name, unit, price, quantity FROM booking_items WHERE booking_id IN (${ids.map(() => '?').join(',')})`, ...ids)
    : [];
  for (const r of rows) r.items = items.filter((i) => i.booking_id === r.booking_id);
  return rows;
}

// Moves recorded for a delivered order (for invoices / agent history).
const deliveryMoves = (deliveryId) => all(`SELECT m.*, p.name FROM container_moves m JOIN products p ON p.id = m.product_id
  WHERE m.delivery_id = ?`, deliveryId);

module.exports = {
  FREQUENCIES, MAX_DELIVERIES, areaFor, areasRestricted, activeSlots, slotsForDate, applyCode, quote, parseBooking, requireAgent,
  confirmBooking, createBooking, markPaid, isPaid, refreshBookingStatus, moveToEnd, getDelivery, isOpen, containerPlan, markDelivered,
  startDelivery, failDelivery, deliveryRows, deliveryMoves, newReferralCode, slotText, planDates, publicUrl,
};
