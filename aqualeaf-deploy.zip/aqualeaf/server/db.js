// SQLite database (Node's built-in node:sqlite), schema and first-run seed data.
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { dataDir } = require('./config');
const { hashPassword } = require('./auth');

const db = new DatabaseSync(path.join(dataDir, 'aqualeaf.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'agent')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  line_no TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('water', 'hydroponics')),
  type TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT '',
  price REAL NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  stock INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY,
  booking_no TEXT UNIQUE,
  tracking_id TEXT UNIQUE,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  address TEXT NOT NULL,
  line_no TEXT NOT NULL DEFAULT '',
  frequency TEXT NOT NULL CHECK (frequency IN ('once', 'alternate', 'daily', 'weekly', 'monthly', 'yearly')),
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  delivery_time TEXT NOT NULL,
  agent_id INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  payment_method TEXT NOT NULL DEFAULT 'COD',
  amount_per_delivery REAL NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
  confirmed_at TEXT
);

CREATE TABLE IF NOT EXISTS booking_items (
  id INTEGER PRIMARY KEY,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  name TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT '',
  price REAL NOT NULL,
  quantity INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS deliveries (
  id INTEGER PRIMARY KEY,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL,
  scheduled_date TEXT NOT NULL,
  scheduled_time TEXT NOT NULL,
  agent_id INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'out_for_delivery', 'delivered', 'failed', 'cancelled')),
  amount REAL NOT NULL,
  collected REAL NOT NULL DEFAULT 0,
  invoice_no TEXT UNIQUE,
  started_at TEXT,
  delivered_at TEXT,
  note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_deliveries_date ON deliveries(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_deliveries_agent ON deliveries(agent_id, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_deliveries_booking ON deliveries(booking_id);

CREATE TABLE IF NOT EXISTS agent_locations (
  agent_id INTEGER PRIMARY KEY REFERENCES users(id),
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  accuracy REAL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  link TEXT NOT NULL DEFAULT '',
  read_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, id);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

// ---- v2 schema: areas & slots, cans, coupons/referrals, ratings, customer login, push, cash handover.
db.exec(`
CREATE TABLE IF NOT EXISTS service_areas (
  id INTEGER PRIMARY KEY,
  pincode TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL DEFAULT '',
  delivery_charge REAL NOT NULL DEFAULT 0,
  min_order REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS time_slots (
  id INTEGER PRIMARY KEY,
  label TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 20,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS customer_containers (
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  held INTEGER NOT NULL DEFAULT 0,
  deposit_units INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (customer_id, product_id)
);

CREATE TABLE IF NOT EXISTS container_moves (
  id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  delivery_id INTEGER REFERENCES deliveries(id),
  delivered INTEGER NOT NULL DEFAULT 0,
  collected INTEGER NOT NULL DEFAULT 0,
  deposit_units INTEGER NOT NULL DEFAULT 0,
  deposit_amount REAL NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  user_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_container_moves_customer ON container_moves(customer_id);

CREATE TABLE IF NOT EXISTS coupons (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL CHECK (type IN ('percent', 'flat')),
  value REAL NOT NULL,
  min_order REAL NOT NULL DEFAULT 0,
  max_discount REAL NOT NULL DEFAULT 0,
  scope TEXT NOT NULL DEFAULT 'first' CHECK (scope IN ('first', 'all')),
  valid_from TEXT,
  valid_to TEXT,
  usage_limit INTEGER NOT NULL DEFAULT 0,
  per_customer_limit INTEGER NOT NULL DEFAULT 1,
  customer_id INTEGER REFERENCES customers(id),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS ratings (
  delivery_id INTEGER PRIMARY KEY REFERENCES deliveries(id),
  booking_id INTEGER NOT NULL REFERENCES bookings(id),
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  agent_id INTEGER REFERENCES users(id),
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS otp_codes (
  phone TEXT PRIMARY KEY,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  sent_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS cash_handovers (
  id INTEGER PRIMARY KEY,
  agent_id INTEGER NOT NULL REFERENCES users(id),
  date TEXT NOT NULL,
  amount REAL NOT NULL,
  received_by INTEGER REFERENCES users(id),
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_cash_handovers_agent ON cash_handovers(agent_id, date);
`);

// Adds a column if it isn't there yet; returns true when it was just added.
function addColumn(table, column, definition) {
  const exists = db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column);
  if (!exists) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  return !exists;
}

if (addColumn('products', 'returnable', 'INTEGER NOT NULL DEFAULT 0')) {
  addColumn('products', 'deposit', 'REAL NOT NULL DEFAULT 0');
  db.exec("UPDATE products SET returnable = 1, deposit = 150 WHERE type = 'can'");
  db.exec("UPDATE products SET returnable = 1, deposit = 200 WHERE type = 'jar' AND name LIKE '15L%'");
}
addColumn('products', 'deposit', 'REAL NOT NULL DEFAULT 0');
addColumn('customers', 'pincode', "TEXT NOT NULL DEFAULT ''");
addColumn('customers', 'referral_code', 'TEXT');
addColumn('bookings', 'pincode', "TEXT NOT NULL DEFAULT ''");
addColumn('bookings', 'slot_id', 'INTEGER REFERENCES time_slots(id)');
addColumn('bookings', 'delivery_charge', 'REAL NOT NULL DEFAULT 0');
addColumn('bookings', 'coupon_code', "TEXT NOT NULL DEFAULT ''");
addColumn('bookings', 'discount', 'REAL NOT NULL DEFAULT 0');
addColumn('bookings', 'discount_scope', "TEXT NOT NULL DEFAULT 'first'");
addColumn('bookings', 'referred_by', 'INTEGER REFERENCES customers(id)');
addColumn('deliveries', 'slot_id', 'INTEGER REFERENCES time_slots(id)');
addColumn('deliveries', 'deposit_amount', 'REAL NOT NULL DEFAULT 0');
addColumn('deliveries', 'empties_collected', 'INTEGER NOT NULL DEFAULT 0');
const freshMustChange = addColumn('users', 'must_change_password', 'INTEGER NOT NULL DEFAULT 0');
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_referral ON customers(referral_code)');

// ---- v3: online payment (Razorpay, paid in full at booking) replaces cash on delivery.
// payment_status: unpaid → paid (→ refunded / partially_refunded); 'cod' marks bookings made before online payment.
if (addColumn('bookings', 'payment_status', "TEXT NOT NULL DEFAULT 'unpaid'")) {
  db.exec("UPDATE bookings SET payment_status = 'cod' WHERE payment_method = 'COD'");
}
addColumn('bookings', 'total_amount', 'REAL NOT NULL DEFAULT 0');
addColumn('bookings', 'deposit_amount', 'REAL NOT NULL DEFAULT 0');
addColumn('bookings', 'paid_amount', 'REAL NOT NULL DEFAULT 0');
addColumn('bookings', 'refunded_amount', 'REAL NOT NULL DEFAULT 0');
addColumn('bookings', 'payment_link_id', 'TEXT');
addColumn('bookings', 'payment_link_url', 'TEXT');
addColumn('bookings', 'payment_ref', 'TEXT');
addColumn('bookings', 'paid_at', 'TEXT');
db.exec('CREATE INDEX IF NOT EXISTS idx_bookings_payment_link ON bookings(payment_link_id)');

// ---- v3: water only (hydroponic products are hidden, not deleted, so past orders and reports stay intact).
db.exec("UPDATE products SET active = 0 WHERE category = 'hydroponics' AND active = 1");
db.exec(`UPDATE settings SET value = 'Pure drinking water, delivered to your door'
  WHERE key = 'tagline' AND value = 'Pure water & fresh hydroponic greens, delivered'`);
db.exec(`UPDATE settings SET value = 'Thank you for choosing us! Paid online via Razorpay.'
  WHERE key = 'invoice_note' AND value = 'Thank you for choosing us! Payment: Cash on Delivery.'`);

// Existing installs: flag accounts still using the demo passwords so they must change them.
if (freshMustChange) {
  const { verifyPassword } = require('./auth');
  for (const u of db.prepare('SELECT id, password_hash FROM users').all()) {
    if (verifyPassword('admin123', u.password_hash) || verifyPassword('agent123', u.password_hash)) {
      db.prepare('UPDATE users SET must_change_password = 1 WHERE id = ?').run(u.id);
    }
  }
}

if (db.prepare('SELECT COUNT(*) AS n FROM time_slots').get().n === 0) {
  const addSlot = db.prepare('INSERT INTO time_slots (label, start_time, end_time, capacity, sort) VALUES (?, ?, ?, ?, ?)');
  [['Early morning', '06:00', '08:00'], ['Morning', '08:00', '10:00'], ['Late morning', '10:00', '12:00'],
    ['Afternoon', '14:00', '16:00'], ['Evening', '16:00', '18:00'], ['Night', '18:00', '20:00']]
    .forEach(([label, s, e], i) => addSlot.run(label, s, e, 25, i));
}

const DEFAULT_SETTINGS = {
  business_name: 'AquaLeaf',
  tagline: 'Pure drinking water, delivered to your door',
  phone: '+91 98765 43210',
  email: 'hello@aqualeaf.example',
  address: '12 Green Park Road, Kolkata 700001',
  currency: '₹',
  tax_id: '',
  invoice_note: 'Thank you for choosing us! Paid online via Razorpay.',
  default_delivery_charge: '0',
  default_min_order: '0',
  same_day_cutoff_minutes: '60',
  referral_discount: '50',
  referral_reward: '50',
};
const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) insertSetting.run(k, v);

// First run: create demo staff and catalogue. Change these passwords after first login.
if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n === 0) {
  const addUser = db.prepare('INSERT INTO users (name, email, phone, password_hash, role, must_change_password) VALUES (?, ?, ?, ?, ?, 1)');
  addUser.run('Store Admin', 'admin@aqualeaf.local', '9000000001', hashPassword('admin123'), 'admin');
  addUser.run('Ravi Kumar', 'ravi@aqualeaf.local', '9000000002', hashPassword('agent123'), 'agent');
  addUser.run('Sunil Das', 'sunil@aqualeaf.local', '9000000003', hashPassword('agent123'), 'agent');
}

if (db.prepare('SELECT COUNT(*) AS n FROM products').get().n === 0) {
  const addProduct = db.prepare(
    'INSERT INTO products (name, category, type, unit, price, description, stock, sort, returnable, deposit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0)'
  );
  [
    ['20L Water Can', 'water', 'can', '20 litre can', 60, 'RO + UV purified drinking water in a returnable, sealed 20 litre can.', 200, 1],
    ['Water Bottles 1L (Pack of 12)', 'water', 'bottle', '12 × 1 litre', 180, 'Sealed 1 litre mineral-enriched bottles — ideal for travel and offices.', 150, 2],
    ['Water Bottles 500ml (Pack of 24)', 'water', 'bottle', '24 × 500 ml', 220, 'Handy half-litre bottles for events, meetings and lunch boxes.', 120, 3],
    ['10L Water Box', 'water', 'box', '10 litre box', 90, 'Stackable dispenser box with a built-in tap. Fits on any shelf.', 80, 4],
    ['15L Cool Jar', 'water', 'jar', '15 litre jar', 70, 'Insulated jar with tap that keeps water cool for hours.', 100, 5],
    ['5L Water Jar', 'water', 'jar', '5 litre jar', 45, 'Easy-carry 5 litre jar with handle for small families.', 140, 6],
  ].forEach((p) => addProduct.run(...p));
  db.exec("UPDATE products SET returnable = 1, deposit = 150 WHERE type = 'can'");
  db.exec("UPDATE products SET returnable = 1, deposit = 200 WHERE type = 'jar' AND name LIKE '15L%'");
}

module.exports = db;
