// Password hashing (scrypt) and HMAC-signed session cookies. No external deps.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { dataDir } = require('./config');

const SESSION_DAYS = 7;

function loadSecret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  const file = path.join(dataDir, 'session.secret');
  if (!fs.existsSync(file)) fs.writeFileSync(file, crypto.randomBytes(48).toString('hex'), { mode: 0o600 });
  return fs.readFileSync(file, 'utf8').trim();
}
const SECRET = loadSecret();

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [alg, saltHex, hashHex] = String(stored || '').split('$');
  if (alg !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(String(password), Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

const sign = (data) => crypto.createHmac('sha256', SECRET).update(data).digest('base64url');

function createToken(data, days = SESSION_DAYS) {
  const payload = Buffer.from(JSON.stringify({ ...data, exp: Date.now() + days * 864e5 })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

function verifyToken(token) {
  if (!token || typeof token !== 'string') return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expected = sign(payload);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return data.exp > Date.now() ? data : null;
  } catch {
    return null;
  }
}

function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

// Staff use the `sid` cookie; customers (OTP login) use `cid`, so both can be logged in on one device.
const CUSTOMER_DAYS = 30;
const flags = (secure) => `HttpOnly; SameSite=Lax; Path=/${secure ? '; Secure' : ''}`;
const sessionCookie = (userId, secure = false) =>
  `sid=${createToken({ uid: userId })}; ${flags(secure)}; Max-Age=${SESSION_DAYS * 86400}`;
const clearCookie = (secure = false) => `sid=; ${flags(secure)}; Max-Age=0`;
const customerCookie = (customerId, secure = false) =>
  `cid=${createToken({ cust: customerId }, CUSTOMER_DAYS)}; ${flags(secure)}; Max-Age=${CUSTOMER_DAYS * 86400}`;
const clearCustomerCookie = (secure = false) => `cid=; ${flags(secure)}; Max-Age=0`;

module.exports = {
  hashPassword, verifyPassword, verifyToken, parseCookies, sessionCookie, clearCookie, customerCookie, clearCustomerCookie, sign,
};
