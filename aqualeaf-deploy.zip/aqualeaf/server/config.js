const path = require('path');
const fs = require('fs');

// All dates/times are business-local (India by default) — set before anything uses Date.
process.env.TZ = process.env.APP_TZ || process.env.TZ || 'Asia/Kolkata';

const onVercel = !!process.env.VERCEL;
// On Vercel only /tmp is writable (used for scratch files, never for real data).
const dataDir = process.env.DATA_DIR || (onVercel ? '/tmp/aqualeaf' : path.join(__dirname, '..', 'data'));
fs.mkdirSync(dataDir, { recursive: true });

// Turso / libSQL in the cloud, or a local SQLite file (same code either way).
const dbUrl = process.env.TURSO_DATABASE_URL || process.env.LIBSQL_URL || process.env.DATABASE_URL
  || `file:${path.join(dataDir, 'aqualeaf.db').replace(/\\/g, '/')}`;

module.exports = {
  dataDir,
  port: Number(process.env.PORT) || 3000,
  onVercel,
  dbUrl,
  dbAuthToken: process.env.TURSO_AUTH_TOKEN || process.env.LIBSQL_AUTH_TOKEN || undefined,
  isFileDb: dbUrl.startsWith('file:'),
  // Portfolio/demo deployments: auto-load demo data and show login codes on screen.
  demoMode: process.env.DEMO_MODE === '1',
  // The site's own address as seen in requests — used for links in messages when PUBLIC_URL isn't set.
  runtimeBaseUrl: '',
};
