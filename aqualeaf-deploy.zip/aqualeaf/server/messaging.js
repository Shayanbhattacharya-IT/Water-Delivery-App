// Messages to customers: WhatsApp (preferred) → SMS (fallback) → server console (local testing).
const wa = require('./whatsapp');

// ---------------------------------------------------------------- SMS (optional fallback)
//   SMS_PROVIDER=twilio  TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM
//   SMS_PROVIDER=msg91   MSG91_AUTH_KEY, MSG91_OTP_TEMPLATE_ID, MSG91_TEMPLATE_ID (India needs DLT templates)
const smsProvider = () => (process.env.SMS_PROVIDER || '').toLowerCase();
const smsConfigured = () => ['twilio', 'msg91'].includes(smsProvider());

function e164(phone) {
  const digits = String(phone).replace(/[^\d]/g, '');
  const cc = process.env.SMS_COUNTRY_CODE || '91';
  return String(phone).startsWith('+') ? `+${digits}` : digits.length === 10 ? `+${cc}${digits}` : `+${digits}`;
}

async function sendSms(phone, text, { otp } = {}) {
  const to = e164(phone);
  if (smsProvider() === 'twilio') {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${Buffer.from(`${sid}:${process.env.TWILIO_AUTH_TOKEN}`).toString('base64')}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({ To: to, From: process.env.TWILIO_FROM, Body: text }),
    });
    if (!res.ok) throw new Error(`Twilio error ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return true;
  }
  if (smsProvider() === 'msg91') {
    const mobile = to.replace('+', '');
    const res = otp
      ? await fetch(`https://control.msg91.com/api/v5/otp?${new URLSearchParams({ template_id: process.env.MSG91_OTP_TEMPLATE_ID, mobile, otp })}`, {
        method: 'POST', headers: { authkey: process.env.MSG91_AUTH_KEY },
      })
      : await fetch('https://control.msg91.com/api/v5/flow/', {
        method: 'POST',
        headers: { authkey: process.env.MSG91_AUTH_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ template_id: process.env.MSG91_TEMPLATE_ID, recipients: [{ mobiles: mobile, message: text }] }),
      });
    if (!res.ok) throw new Error(`MSG91 error ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return true;
  }
  console.log(`[sms:console] to ${to}: ${text}`);
  return false;
}

// ---------------------------------------------------------------- customer messages
// kind → WhatsApp template key + plain-text fallback for SMS.
const KINDS = {
  booking_confirmed: (p) => `Hi ${p[0]}, booking ${p[1]} is confirmed & paid (${p[2]}). ${p[3]}. Track: ${p[4]}`,
  payment_link: (p) => `Hi ${p[0]}, please pay ${p[1]} for booking ${p[2]}: ${p[3]}`,
  out_for_delivery: (p) => `Hi ${p[0]}, your delivery ${p[1]} is on the way with ${p[2]} (${p[3]}).`,
  delivered: (p) => `Hi ${p[0]}, delivered (${p[1]}). Your bill: ${p[2]}`,
};

// Fire-and-forget: never delays or breaks the request that triggered it.
function sendCustomer(kind, phone, params) {
  setImmediate(async () => {
    try {
      if (wa.configured()) await wa.sendTemplate(phone, kind, params);
      else if (smsConfigured()) await sendSms(phone, KINDS[kind](params));
      else await wa.sendTemplate(phone, kind, params); // logs to console
    } catch (e) {
      console.warn(`[message] ${kind} to ${phone} failed: ${e.message}`);
    }
  });
}

// Login code: WhatsApp → SMS. Returns the channel used, or null when none is configured (local testing).
async function sendOtp(phone, code, businessName) {
  if (wa.configured()) { await wa.sendTemplate(phone, 'login_code', [code], { otpButton: code }); return 'whatsapp'; }
  if (smsConfigured()) { await sendSms(phone, `${businessName}: your login code is ${code}. It is valid for 10 minutes. Do not share it.`, { otp: code }); return 'sms'; }
  return null;
}
const otpConfigured = () => wa.configured() || smsConfigured();

module.exports = { sendCustomer, sendOtp, otpConfigured, sendSms };
