// Who is making the request: staff (admin / agent) via `sid`, customer via `cid`.
const auth = require('./auth');
const { one } = require('./util');

function currentUser(req) {
  const s = auth.verifyToken(auth.parseCookies(req.headers.cookie).sid);
  if (!s?.uid) return null;
  const u = one('SELECT * FROM users WHERE id = ?', s.uid);
  return u && u.active ? u : null;
}

function currentCustomer(req) {
  const s = auth.verifyToken(auth.parseCookies(req.headers.cookie).cid);
  if (!s?.cust) return null;
  return one('SELECT * FROM customers WHERE id = ?', s.cust) || null;
}

// Staff accounts still on a demo / reset password may only use the auth endpoints until they change it.
function requireRole(roles, { allowPasswordChange = false } = {}) {
  return (req, res, next) => {
    const u = currentUser(req);
    if (!u) return res.status(401).json({ error: 'Please log in' });
    if (!roles.includes(u.role)) return res.status(403).json({ error: 'You do not have access to this page' });
    if (u.must_change_password && !allowPasswordChange) {
      return res.status(403).json({ error: 'Please change your password first', code: 'change_password' });
    }
    req.user = u;
    next();
  };
}

function requireCustomer(req, res, next) {
  const c = currentCustomer(req);
  if (!c) return res.status(401).json({ error: 'Please log in with your phone number' });
  req.customer = c;
  next();
}

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role, active: u.active,
  must_change_password: !!u.must_change_password });

module.exports = {
  currentUser, currentCustomer, requireRole, requireCustomer, publicUser,
  adminOnly: requireRole(['admin']),
  agentOnly: requireRole(['agent']),
  staff: requireRole(['admin', 'agent']),
  staffAllowStale: requireRole(['admin', 'agent'], { allowPasswordChange: true }),
};
