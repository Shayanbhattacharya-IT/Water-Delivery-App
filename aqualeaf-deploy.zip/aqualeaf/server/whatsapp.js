// WhatsApp Business messages through the official Meta WhatsApp Cloud API (template messages).
// Configure with WHATSAPP_TOKEN and WHATSAPP_PHONE_NUMBER_ID (and optionally WHATSAPP_LANG, default "en").
// Template names can be overridden with WHATSAPP_TPL_<KEY>; see WHATSAPP-SETUP.md for the exact template texts.
const TEMPLATES = {
  booking_confirmed: 'aq_booking_confirmed', // {{1}} name {{2}} booking no {{3}} amount paid {{4}} schedule {{5}} tracking link
  payment_link: 'aq_payment_link', //         {{1}} name {{2}} amount {{3}} booking no {{4}} payment link
  out_for_delivery: 'aq_out_for_delivery', // {{1}} name {{2}} booking no {{3}} delivery person {{4}} their phone
  delivered: 'aq_delivered', //               {{1}} name {{2}} booking no {{3}} invoice link
  login_code: 'aq_login_code', //             authentication template: {{1}} code (+ copy-code button)
  staff_alert: 'aq_staff_alert', //           {{1}} title {{2}} details
};

const configured = () => !!(process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID);
const templateName = (key) => process.env[`WHATSAPP_TPL_${key.toUpperCase()}`] || TEMPLATES[key];

function waNumber(phone) {
  const digits = String(phone).replace(/[^\d]/g, '');
  return digits.length === 10 ? `${process.env.SMS_COUNTRY_CODE || '91'}${digits}` : digits;
}

// WhatsApp rejects template parameters containing newlines/tabs or 4+ consecutive spaces.
const clean = (v) => String(v ?? '').replace(/[\n\t]+/g, ' ').replace(/ {4,}/g, '   ').slice(0, 1000) || '-';

async function sendTemplate(phone, key, params = [], { otpButton } = {}) {
  const components = [{ type: 'body', parameters: params.map((p) => ({ type: 'text', text: clean(p) })) }];
  if (otpButton) components.push({ type: 'button', sub_type: 'url', index: '0', parameters: [{ type: 'text', text: clean(otpButton) }] });
  if (!configured()) {
    console.log(`[whatsapp:console] to ${waNumber(phone)} ${templateName(key)}: ${params.map(clean).join(' | ')}`);
    return false;
  }
  const res = await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION || 'v21.0'}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.WHATSAPP_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp', to: waNumber(phone), type: 'template',
      template: { name: templateName(key), language: { code: process.env.WHATSAPP_LANG || 'en' }, components },
    }),
  });
  if (!res.ok) throw new Error(`WhatsApp ${templateName(key)}: ${res.status} ${(await res.text()).slice(0, 200)}`);
  return true;
}

module.exports = { configured, sendTemplate };
