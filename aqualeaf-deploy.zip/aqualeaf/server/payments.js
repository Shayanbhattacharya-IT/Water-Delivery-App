// Getting a booking paid: a Razorpay payment link, or — until Razorpay keys are configured — a built-in test payment page.
const auth = require('./auth');
const { one, run, bad, fail, setting, FREQ_LABEL, fmtDate } = require('./util');
const razorpay = require('./razorpay');
const { demoMode } = require('./config');
const { sendCustomer } = require('./messaging');

const testMode = () => !razorpay.configured()
  && (process.env.NODE_ENV !== 'production' || demoMode || process.env.ALLOW_TEST_PAYMENTS === '1');
const mode = () => (razorpay.configured() ? (razorpay.isTestKey() ? 'razorpay-test' : 'razorpay') : testMode() ? 'test' : 'off');
const testToken = (bookingNo) => auth.sign(`testpay:${bookingNo}`);

const baseUrl = (req) => (process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');

// Returns the URL the customer should open to pay this booking (creating a Razorpay link when needed).
async function paymentUrl(b, req, { resend = false } = {}) {
  if (b.payment_status !== 'unpaid') bad('This booking is already paid');
  if (b.status === 'cancelled') bad('This booking was cancelled');
  let url;
  if (razorpay.configured()) {
    if (b.payment_link_url && !resend) return b.payment_link_url;
    const link = await razorpay.createPaymentLink({
      amount: b.total_amount,
      reference: `${b.booking_no}-${Date.now().toString(36)}`,
      description: `${setting('business_name')} booking ${b.booking_no} · ${FREQ_LABEL[b.frequency]} from ${fmtDate(b.start_date)}`,
      customer: { name: b.name, phone: b.phone, email: b.email },
      callbackUrl: `${baseUrl(req)}/api/payments/razorpay/callback`,
      notes: { booking_no: b.booking_no },
    });
    run('UPDATE bookings SET payment_link_id = ?, payment_link_url = ? WHERE id = ?', link.id, link.url, b.id);
    url = link.url;
  } else if (testMode()) {
    url = `${baseUrl(req)}/api/payments/test?${new URLSearchParams({ b: b.booking_no, t: testToken(b.booking_no) })}`;
  } else {
    fail(503, 'Online payment is not set up yet. Please contact us to complete your booking.');
  }
  sendCustomer('payment_link', b.phone, [b.name.split(' ')[0],
    `${setting('currency')}${Number(b.total_amount).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`, b.booking_no, url]);
  return url;
}

const bookingByLink = (linkId) => one('SELECT * FROM bookings WHERE payment_link_id = ?', linkId);

module.exports = { mode, testMode, testToken, paymentUrl, bookingByLink, baseUrl };
