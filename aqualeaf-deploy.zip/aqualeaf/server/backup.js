// Daily database backups (SQLite VACUUM INTO) with retention, plus on-demand backup files.
const fs = require('fs');
const path = require('path');
const { dataDir } = require('./config');
const { db } = require('./util');
const sch = require('./schedule');

const backupDir = process.env.BACKUP_DIR || path.join(dataDir, 'backups');
const KEEP = Number(process.env.BACKUP_KEEP_DAYS) || 14;

function backupTo(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (fs.existsSync(file)) fs.unlinkSync(file);
  db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  return file;
}

function dailyBackup() {
  try {
    const file = path.join(backupDir, `aqualeaf-${sch.today()}.db`);
    if (fs.existsSync(file)) return;
    backupTo(file);
    const old = fs.readdirSync(backupDir).filter((f) => /^aqualeaf-\d{4}-\d{2}-\d{2}\.db$/.test(f)).sort().reverse().slice(KEEP);
    for (const f of old) fs.unlinkSync(path.join(backupDir, f));
    console.log(`[backup] saved ${file}`);
  } catch (e) {
    console.error(`[backup] failed: ${e.message}`);
  }
}

function startBackups() {
  setTimeout(dailyBackup, 15e3).unref();
  setInterval(dailyBackup, 3600e3).unref();
}

const listBackups = () => (fs.existsSync(backupDir)
  ? fs.readdirSync(backupDir).filter((f) => f.endsWith('.db')).sort().reverse()
    .map((f) => ({ file: f, size: fs.statSync(path.join(backupDir, f)).size }))
  : []);

module.exports = { backupDir, backupTo, startBackups, listBackups };
