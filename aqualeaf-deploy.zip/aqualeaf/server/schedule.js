// Date helpers and recurring-delivery schedule generation.
// All dates are 'YYYY-MM-DD' strings; arithmetic is done in UTC to avoid DST drift.

const pad = (n) => String(n).padStart(2, '0');
const fmt = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
const parse = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
};

const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && fmt(parse(s)) === s;

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function addDays(s, n) {
  const d = parse(s);
  d.setUTCDate(d.getUTCDate() + n);
  return fmt(d);
}

// Adds months, clamping the day (e.g. 31 Jan + 1 month = 28/29 Feb).
function addMonths(s, n) {
  const [y, m, d] = s.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1 + n, 1));
  const daysInMonth = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
  t.setUTCDate(Math.min(d, daysInMonth));
  return fmt(t);
}

function nth(frequency, start, i) {
  switch (frequency) {
    case 'once': return i === 0 ? start : null;
    case 'daily': return addDays(start, i);
    case 'alternate': return addDays(start, 2 * i);
    case 'weekly': return addDays(start, 7 * i);
    case 'monthly': return addMonths(start, i);
    case 'yearly': return addMonths(start, 12 * i);
    default: return null;
  }
}

function occurrences(frequency, start, end, max = 400) {
  const out = [];
  for (let i = 0; out.length <= max; i++) {
    const d = nth(frequency, start, i);
    if (!d || d > end) break;
    out.push(d);
  }
  return out;
}

function defaultEndDate(frequency, start) {
  switch (frequency) {
    case 'daily':
    case 'alternate': return addDays(start, 29);
    case 'weekly': return addDays(start, 7 * 11);
    case 'monthly': return addMonths(start, 11);
    case 'yearly': return addMonths(start, 24);
    default: return start;
  }
}

module.exports = { isDate, today, addDays, addMonths, occurrences, defaultEndDate };
