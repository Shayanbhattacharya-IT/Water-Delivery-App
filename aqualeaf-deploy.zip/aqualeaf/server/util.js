// Shared DB helpers, validation helpers and errors used by every route module.
const db = require('./db');

const one = (sql, ...p) => db.prepare(sql).get(...p);
const all = (sql, ...p) => db.prepare(sql).all(...p);
const run = (sql, ...p) => db.prepare(sql).run(...p);

let txDepth = 0;
function tx(fn) {
  if (txDepth > 0) return fn();
  db.exec('BEGIN');
  txDepth++;
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    txDepth--;
  }
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const fail = (status, message) => { throw new HttpError(status, message); };
const bad = (message) => fail(400, message);

const str = (v, max = 200) => String(v ?? '').trim().slice(0, max);
const intId = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };
const round2 = (n) => Math.round(Number(n) * 100) / 100;
const nowIso = () => new Date().toISOString();
const localNow = () => one("SELECT datetime('now', 'localtime') AS t").t;
const cleanPhone = (v) => str(v, 20).replace(/[\s()-]/g, '');
const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isTime = (v) => /^([01]\d|2[0-3]):[0-5]\d$/.test(v);

const FREQ_LABEL = { once: 'One time', alternate: 'Alternate days', daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', yearly: 'Yearly' };
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const fmtDate = (s) => { const [y, m, d] = s.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y}`; };

const getSettings = () => Object.fromEntries(all('SELECT key, value FROM settings').map((r) => [r.key, r.value]));
const setting = (key, fallback = '') => one('SELECT value FROM settings WHERE key = ?', key)?.value ?? fallback;
const numSetting = (key, fallback = 0) => { const n = Number(setting(key, fallback)); return Number.isFinite(n) ? n : fallback; };

// Simple in-memory fixed-window rate limiter (per process).
const buckets = new Map();
function rateLimit(key, max, windowMs, message = 'Too many requests. Please wait a little and try again.') {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now - b.start > windowMs) { b = { start: now, count: 0 }; buckets.set(key, b); }
  b.count++;
  if (b.count > max) fail(429, message);
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (now - b.start > 6 * 3600e3) buckets.delete(k); }, 3600e3).unref();

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const randomCode = (len, alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789') =>
  Array.from(require('crypto').randomBytes(len), (x) => alphabet[x % alphabet.length]).join('');

module.exports = {
  db, one, all, run, tx, HttpError, fail, bad, str, intId, round2, nowIso, localNow, cleanPhone, isEmail, isTime,
  FREQ_LABEL, fmtDate, getSettings, setting, numSetting, rateLimit, randomCode, esc,
};
