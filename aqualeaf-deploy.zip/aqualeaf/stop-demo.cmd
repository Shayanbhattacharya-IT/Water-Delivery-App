@echo off
rem Double-click to stop the client demo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-demo.ps1"
pause
